import process from 'node:process';globalThis._importMeta_=globalThis._importMeta_||{url:"file:///_entry.js",env:process.env};import { readFile as readFile$1 } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { promises, existsSync, readFileSync, writeFileSync as writeFileSync$1 } from 'node:fs';
import { Socket } from 'node:net';
import http, { Server as Server$1 } from 'node:http';
import https, { Server } from 'node:https';
import { EventEmitter } from 'node:events';
import { Buffer as Buffer$1 } from 'node:buffer';
import { resolve as resolve$1, dirname as dirname$1, join } from 'node:path';
import { execFile } from 'child_process';
import { unlinkSync, existsSync as existsSync$1, writeFileSync } from 'fs';
import { resolve as resolve$2, dirname as dirname$2 } from 'path';
import { fileURLToPath } from 'url';
import { createRequire } from 'module';
import { execFile as execFile$1 } from 'node:child_process';
import { fileURLToPath as fileURLToPath$1 } from 'node:url';
import { getIcons } from '@iconify/utils';
import { consola } from 'consola';

const suspectProtoRx = /"(?:_|\\u0{2}5[Ff]){2}(?:p|\\u0{2}70)(?:r|\\u0{2}72)(?:o|\\u0{2}6[Ff])(?:t|\\u0{2}74)(?:o|\\u0{2}6[Ff])(?:_|\\u0{2}5[Ff]){2}"\s*:/;
const suspectConstructorRx = /"(?:c|\\u0063)(?:o|\\u006[Ff])(?:n|\\u006[Ee])(?:s|\\u0073)(?:t|\\u0074)(?:r|\\u0072)(?:u|\\u0075)(?:c|\\u0063)(?:t|\\u0074)(?:o|\\u006[Ff])(?:r|\\u0072)"\s*:/;
const JsonSigRx = /^\s*["[{]|^\s*-?\d{1,16}(\.\d{1,17})?([Ee][+-]?\d+)?\s*$/;
function jsonParseTransform(key, value) {
  if (key === "__proto__" || key === "constructor" && value && typeof value === "object" && "prototype" in value) {
    warnKeyDropped(key);
    return;
  }
  return value;
}
function warnKeyDropped(key) {
  console.warn(`[destr] Dropping "${key}" key to prevent prototype pollution.`);
}
function destr(value, options = {}) {
  if (typeof value !== "string") {
    return value;
  }
  if (value[0] === '"' && value[value.length - 1] === '"' && value.indexOf("\\") === -1) {
    return value.slice(1, -1);
  }
  const _value = value.trim();
  if (_value.length <= 9) {
    switch (_value.toLowerCase()) {
      case "true": {
        return true;
      }
      case "false": {
        return false;
      }
      case "undefined": {
        return void 0;
      }
      case "null": {
        return null;
      }
      case "nan": {
        return Number.NaN;
      }
      case "infinity": {
        return Number.POSITIVE_INFINITY;
      }
      case "-infinity": {
        return Number.NEGATIVE_INFINITY;
      }
    }
  }
  if (!JsonSigRx.test(value)) {
    if (options.strict) {
      throw new SyntaxError("[destr] Invalid JSON");
    }
    return value;
  }
  try {
    if (suspectProtoRx.test(value) || suspectConstructorRx.test(value)) {
      if (options.strict) {
        throw new Error("[destr] Possible prototype pollution");
      }
      return JSON.parse(value, jsonParseTransform);
    }
    return JSON.parse(value);
  } catch (error) {
    if (options.strict) {
      throw error;
    }
    return value;
  }
}

const HASH_RE = /#/g;
const AMPERSAND_RE = /&/g;
const SLASH_RE = /\//g;
const EQUAL_RE = /=/g;
const IM_RE = /\?/g;
const PLUS_RE = /\+/g;
const ENC_CARET_RE = /%5e/gi;
const ENC_BACKTICK_RE = /%60/gi;
const ENC_PIPE_RE = /%7c/gi;
const ENC_SPACE_RE = /%20/gi;
const ENC_SLASH_RE = /%2f/gi;
const ENC_ENC_SLASH_RE = /%252f/gi;
function encode(text) {
  return encodeURI("" + text).replace(ENC_PIPE_RE, "|");
}
function encodeQueryValue(input) {
  return encode(typeof input === "string" ? input : JSON.stringify(input)).replace(PLUS_RE, "%2B").replace(ENC_SPACE_RE, "+").replace(HASH_RE, "%23").replace(AMPERSAND_RE, "%26").replace(ENC_BACKTICK_RE, "`").replace(ENC_CARET_RE, "^").replace(SLASH_RE, "%2F");
}
function encodeQueryKey(text) {
  return encodeQueryValue(text).replace(EQUAL_RE, "%3D");
}
function encodePath(text) {
  return encode(text).replace(HASH_RE, "%23").replace(IM_RE, "%3F").replace(ENC_ENC_SLASH_RE, "%2F").replace(AMPERSAND_RE, "%26").replace(PLUS_RE, "%2B");
}
function decode$1(text = "") {
  try {
    return decodeURIComponent("" + text);
  } catch {
    return "" + text;
  }
}
function decodePath(text) {
  return decode$1(text.replace(ENC_SLASH_RE, "%252F"));
}
function decodeQueryKey(text) {
  return decode$1(text.replace(PLUS_RE, " "));
}
function decodeQueryValue(text) {
  return decode$1(text.replace(PLUS_RE, " "));
}

function parseQuery(parametersString = "") {
  const object = /* @__PURE__ */ Object.create(null);
  if (parametersString[0] === "?") {
    parametersString = parametersString.slice(1);
  }
  for (const parameter of parametersString.split("&")) {
    const s = parameter.match(/([^=]+)=?(.*)/) || [];
    if (s.length < 2) {
      continue;
    }
    const key = decodeQueryKey(s[1]);
    if (key === "__proto__" || key === "constructor") {
      continue;
    }
    const value = decodeQueryValue(s[2] || "");
    if (object[key] === void 0) {
      object[key] = value;
    } else if (Array.isArray(object[key])) {
      object[key].push(value);
    } else {
      object[key] = [object[key], value];
    }
  }
  return object;
}
function encodeQueryItem(key, value) {
  if (typeof value === "number" || typeof value === "boolean") {
    value = String(value);
  }
  if (!value) {
    return encodeQueryKey(key);
  }
  if (Array.isArray(value)) {
    return value.map(
      (_value) => `${encodeQueryKey(key)}=${encodeQueryValue(_value)}`
    ).join("&");
  }
  return `${encodeQueryKey(key)}=${encodeQueryValue(value)}`;
}
function stringifyQuery(query) {
  return Object.keys(query).filter((k) => query[k] !== void 0).map((k) => encodeQueryItem(k, query[k])).filter(Boolean).join("&");
}

const PROTOCOL_STRICT_REGEX = /^[\s\w\0+.-]{2,}:([/\\]{1,2})/;
const PROTOCOL_REGEX = /^[\s\w\0+.-]{2,}:([/\\]{2})?/;
const PROTOCOL_RELATIVE_REGEX = /^([/\\]\s*){2,}[^/\\]/;
const PROTOCOL_SCRIPT_RE = /^[\s\0]*(blob|data|javascript|vbscript):$/i;
const TRAILING_SLASH_RE = /\/$|\/\?|\/#/;
const JOIN_LEADING_SLASH_RE = /^\.?\//;
function hasProtocol(inputString, opts = {}) {
  if (typeof opts === "boolean") {
    opts = { acceptRelative: opts };
  }
  if (opts.strict) {
    return PROTOCOL_STRICT_REGEX.test(inputString);
  }
  return PROTOCOL_REGEX.test(inputString) || (opts.acceptRelative ? PROTOCOL_RELATIVE_REGEX.test(inputString) : false);
}
function isScriptProtocol(protocol) {
  return !!protocol && PROTOCOL_SCRIPT_RE.test(protocol);
}
function hasTrailingSlash(input = "", respectQueryAndFragment) {
  if (!respectQueryAndFragment) {
    return input.endsWith("/");
  }
  return TRAILING_SLASH_RE.test(input);
}
function withoutTrailingSlash(input = "", respectQueryAndFragment) {
  if (!respectQueryAndFragment) {
    return (hasTrailingSlash(input) ? input.slice(0, -1) : input) || "/";
  }
  if (!hasTrailingSlash(input, true)) {
    return input || "/";
  }
  let path = input;
  let fragment = "";
  const fragmentIndex = input.indexOf("#");
  if (fragmentIndex !== -1) {
    path = input.slice(0, fragmentIndex);
    fragment = input.slice(fragmentIndex);
  }
  const [s0, ...s] = path.split("?");
  const cleanPath = s0.endsWith("/") ? s0.slice(0, -1) : s0;
  return (cleanPath || "/") + (s.length > 0 ? `?${s.join("?")}` : "") + fragment;
}
function withTrailingSlash(input = "", respectQueryAndFragment) {
  if (!respectQueryAndFragment) {
    return input.endsWith("/") ? input : input + "/";
  }
  if (hasTrailingSlash(input, true)) {
    return input || "/";
  }
  let path = input;
  let fragment = "";
  const fragmentIndex = input.indexOf("#");
  if (fragmentIndex !== -1) {
    path = input.slice(0, fragmentIndex);
    fragment = input.slice(fragmentIndex);
    if (!path) {
      return fragment;
    }
  }
  const [s0, ...s] = path.split("?");
  return s0 + "/" + (s.length > 0 ? `?${s.join("?")}` : "") + fragment;
}
function hasLeadingSlash(input = "") {
  return input.startsWith("/");
}
function withLeadingSlash(input = "") {
  return hasLeadingSlash(input) ? input : "/" + input;
}
function withBase(input, base) {
  if (isEmptyURL(base) || hasProtocol(input)) {
    return input;
  }
  const _base = withoutTrailingSlash(base);
  if (input.startsWith(_base)) {
    const nextChar = input[_base.length];
    if (!nextChar || nextChar === "/" || nextChar === "?") {
      return input;
    }
  }
  return joinURL(_base, input);
}
function withoutBase(input, base) {
  if (isEmptyURL(base)) {
    return input;
  }
  const _base = withoutTrailingSlash(base);
  if (!input.startsWith(_base)) {
    return input;
  }
  const nextChar = input[_base.length];
  if (nextChar && nextChar !== "/" && nextChar !== "?") {
    return input;
  }
  const trimmed = input.slice(_base.length);
  return trimmed[0] === "/" ? trimmed : "/" + trimmed;
}
function withQuery(input, query) {
  const parsed = parseURL(input);
  const mergedQuery = { ...parseQuery(parsed.search), ...query };
  parsed.search = stringifyQuery(mergedQuery);
  return stringifyParsedURL(parsed);
}
function getQuery$1(input) {
  return parseQuery(parseURL(input).search);
}
function isEmptyURL(url) {
  return !url || url === "/";
}
function isNonEmptyURL(url) {
  return url && url !== "/";
}
function joinURL(base, ...input) {
  let url = base || "";
  for (const segment of input.filter((url2) => isNonEmptyURL(url2))) {
    if (url) {
      const _segment = segment.replace(JOIN_LEADING_SLASH_RE, "");
      url = withTrailingSlash(url) + _segment;
    } else {
      url = segment;
    }
  }
  return url;
}
function joinRelativeURL(..._input) {
  const JOIN_SEGMENT_SPLIT_RE = /\/(?!\/)/;
  const input = _input.filter(Boolean);
  const segments = [];
  let segmentsDepth = 0;
  for (const i of input) {
    if (!i || i === "/") {
      continue;
    }
    for (const [sindex, s] of i.split(JOIN_SEGMENT_SPLIT_RE).entries()) {
      if (!s || s === ".") {
        continue;
      }
      if (s === "..") {
        if (segments.length === 1 && hasProtocol(segments[0])) {
          continue;
        }
        segments.pop();
        segmentsDepth--;
        continue;
      }
      if (sindex === 1 && segments[segments.length - 1]?.endsWith(":/")) {
        segments[segments.length - 1] += "/" + s;
        continue;
      }
      segments.push(s);
      segmentsDepth++;
    }
  }
  let url = segments.join("/");
  if (segmentsDepth >= 0) {
    if (input[0]?.startsWith("/") && !url.startsWith("/")) {
      url = "/" + url;
    } else if (input[0]?.startsWith("./") && !url.startsWith("./")) {
      url = "./" + url;
    }
  } else {
    url = "../".repeat(-1 * segmentsDepth) + url;
  }
  if (input[input.length - 1]?.endsWith("/") && !url.endsWith("/")) {
    url += "/";
  }
  return url;
}

const protocolRelative = Symbol.for("ufo:protocolRelative");
function parseURL(input = "", defaultProto) {
  const _specialProtoMatch = input.match(
    /^[\s\0]*(blob:|data:|javascript:|vbscript:)(.*)/i
  );
  if (_specialProtoMatch) {
    const [, _proto, _pathname = ""] = _specialProtoMatch;
    return {
      protocol: _proto.toLowerCase(),
      pathname: _pathname,
      href: _proto + _pathname,
      auth: "",
      host: "",
      search: "",
      hash: ""
    };
  }
  if (!hasProtocol(input, { acceptRelative: true })) {
    return parsePath(input);
  }
  const [, protocol = "", auth, hostAndPath = ""] = input.replace(/\\/g, "/").match(/^[\s\0]*([\w+.-]{2,}:)?\/\/([^/@]+@)?(.*)/) || [];
  let [, host = "", path = ""] = hostAndPath.match(/([^#/?]*)(.*)?/) || [];
  if (protocol === "file:") {
    path = path.replace(/\/(?=[A-Za-z]:)/, "");
  }
  const { pathname, search, hash } = parsePath(path);
  return {
    protocol: protocol.toLowerCase(),
    auth: auth ? auth.slice(0, Math.max(0, auth.length - 1)) : "",
    host,
    pathname,
    search,
    hash,
    [protocolRelative]: !protocol
  };
}
function parsePath(input = "") {
  const [pathname = "", search = "", hash = ""] = (input.match(/([^#?]*)(\?[^#]*)?(#.*)?/) || []).splice(1);
  return {
    pathname,
    search,
    hash
  };
}
function stringifyParsedURL(parsed) {
  const pathname = parsed.pathname || "";
  const search = parsed.search ? (parsed.search.startsWith("?") ? "" : "?") + parsed.search : "";
  const hash = parsed.hash || "";
  const auth = parsed.auth ? parsed.auth + "@" : "";
  const host = parsed.host || "";
  const proto = parsed.protocol || parsed[protocolRelative] ? (parsed.protocol || "") + "//" : "";
  return proto + auth + host + pathname + search + hash;
}

const NullObject = /* @__PURE__ */ (() => {
  const C = function() {
  };
  C.prototype = /* @__PURE__ */ Object.create(null);
  return C;
})();
function parse$1(str, options) {
  if (typeof str !== "string") {
    throw new TypeError("argument str must be a string");
  }
  const obj = new NullObject();
  const opt = {};
  const dec = opt.decode || decode;
  let index = 0;
  while (index < str.length) {
    const eqIdx = str.indexOf("=", index);
    if (eqIdx === -1) {
      break;
    }
    let endIdx = str.indexOf(";", index);
    if (endIdx === -1) {
      endIdx = str.length;
    } else if (endIdx < eqIdx) {
      index = str.lastIndexOf(";", eqIdx - 1) + 1;
      continue;
    }
    const key = str.slice(index, eqIdx).trim();
    if (opt?.filter && !opt?.filter(key)) {
      index = endIdx + 1;
      continue;
    }
    if (void 0 === obj[key]) {
      let val = str.slice(eqIdx + 1, endIdx).trim();
      if (val.codePointAt(0) === 34) {
        val = val.slice(1, -1);
      }
      obj[key] = tryDecode(val, dec);
    }
    index = endIdx + 1;
  }
  return obj;
}
function decode(str) {
  return str.includes("%") ? decodeURIComponent(str) : str;
}
function tryDecode(str, decode2) {
  try {
    return decode2(str);
  } catch {
    return str;
  }
}

const fieldContentRegExp = /^[\u0009\u0020-\u007E\u0080-\u00FF]+$/;
function serialize$2(name, value, options) {
  const opt = options || {};
  const enc = opt.encode || encodeURIComponent;
  if (typeof enc !== "function") {
    throw new TypeError("option encode is invalid");
  }
  if (!fieldContentRegExp.test(name)) {
    throw new TypeError("argument name is invalid");
  }
  const encodedValue = enc(value);
  if (encodedValue && !fieldContentRegExp.test(encodedValue)) {
    throw new TypeError("argument val is invalid");
  }
  let str = name + "=" + encodedValue;
  if (void 0 !== opt.maxAge && opt.maxAge !== null) {
    const maxAge = opt.maxAge - 0;
    if (Number.isNaN(maxAge) || !Number.isFinite(maxAge)) {
      throw new TypeError("option maxAge is invalid");
    }
    str += "; Max-Age=" + Math.floor(maxAge);
  }
  if (opt.domain) {
    if (!fieldContentRegExp.test(opt.domain)) {
      throw new TypeError("option domain is invalid");
    }
    str += "; Domain=" + opt.domain;
  }
  if (opt.path) {
    if (!fieldContentRegExp.test(opt.path)) {
      throw new TypeError("option path is invalid");
    }
    str += "; Path=" + opt.path;
  }
  if (opt.expires) {
    if (!isDate(opt.expires) || Number.isNaN(opt.expires.valueOf())) {
      throw new TypeError("option expires is invalid");
    }
    str += "; Expires=" + opt.expires.toUTCString();
  }
  if (opt.httpOnly) {
    str += "; HttpOnly";
  }
  if (opt.secure) {
    str += "; Secure";
  }
  if (opt.priority) {
    const priority = typeof opt.priority === "string" ? opt.priority.toLowerCase() : opt.priority;
    switch (priority) {
      case "low": {
        str += "; Priority=Low";
        break;
      }
      case "medium": {
        str += "; Priority=Medium";
        break;
      }
      case "high": {
        str += "; Priority=High";
        break;
      }
      default: {
        throw new TypeError("option priority is invalid");
      }
    }
  }
  if (opt.sameSite) {
    const sameSite = typeof opt.sameSite === "string" ? opt.sameSite.toLowerCase() : opt.sameSite;
    switch (sameSite) {
      case true: {
        str += "; SameSite=Strict";
        break;
      }
      case "lax": {
        str += "; SameSite=Lax";
        break;
      }
      case "strict": {
        str += "; SameSite=Strict";
        break;
      }
      case "none": {
        str += "; SameSite=None";
        break;
      }
      default: {
        throw new TypeError("option sameSite is invalid");
      }
    }
  }
  if (opt.partitioned) {
    str += "; Partitioned";
  }
  return str;
}
function isDate(val) {
  return Object.prototype.toString.call(val) === "[object Date]" || val instanceof Date;
}

function parseSetCookie(setCookieValue, options) {
  const parts = (setCookieValue || "").split(";").filter((str) => typeof str === "string" && !!str.trim());
  const nameValuePairStr = parts.shift() || "";
  const parsed = _parseNameValuePair(nameValuePairStr);
  const name = parsed.name;
  let value = parsed.value;
  try {
    value = options?.decode === false ? value : (options?.decode || decodeURIComponent)(value);
  } catch {
  }
  const cookie = {
    name,
    value
  };
  for (const part of parts) {
    const sides = part.split("=");
    const partKey = (sides.shift() || "").trimStart().toLowerCase();
    const partValue = sides.join("=");
    switch (partKey) {
      case "expires": {
        cookie.expires = new Date(partValue);
        break;
      }
      case "max-age": {
        cookie.maxAge = Number.parseInt(partValue, 10);
        break;
      }
      case "secure": {
        cookie.secure = true;
        break;
      }
      case "httponly": {
        cookie.httpOnly = true;
        break;
      }
      case "samesite": {
        cookie.sameSite = partValue;
        break;
      }
      default: {
        cookie[partKey] = partValue;
      }
    }
  }
  return cookie;
}
function _parseNameValuePair(nameValuePairStr) {
  let name = "";
  let value = "";
  const nameValueArr = nameValuePairStr.split("=");
  if (nameValueArr.length > 1) {
    name = nameValueArr.shift();
    value = nameValueArr.join("=");
  } else {
    value = nameValuePairStr;
  }
  return { name, value };
}

const NODE_TYPES = {
  NORMAL: 0,
  WILDCARD: 1,
  PLACEHOLDER: 2
};

function createRouter$1(options = {}) {
  const ctx = {
    options,
    rootNode: createRadixNode(),
    staticRoutesMap: {}
  };
  const normalizeTrailingSlash = (p) => options.strictTrailingSlash ? p : p.replace(/\/$/, "") || "/";
  if (options.routes) {
    for (const path in options.routes) {
      insert(ctx, normalizeTrailingSlash(path), options.routes[path]);
    }
  }
  return {
    ctx,
    lookup: (path) => lookup(ctx, normalizeTrailingSlash(path)),
    insert: (path, data) => insert(ctx, normalizeTrailingSlash(path), data),
    remove: (path) => remove(ctx, normalizeTrailingSlash(path))
  };
}
function lookup(ctx, path) {
  const staticPathNode = ctx.staticRoutesMap[path];
  if (staticPathNode) {
    return staticPathNode.data;
  }
  const sections = path.split("/");
  const params = {};
  let paramsFound = false;
  let wildcardNode = null;
  let node = ctx.rootNode;
  let wildCardParam = null;
  for (let i = 0; i < sections.length; i++) {
    const section = sections[i];
    if (node.wildcardChildNode !== null) {
      wildcardNode = node.wildcardChildNode;
      wildCardParam = sections.slice(i).join("/");
    }
    const nextNode = node.children.get(section);
    if (nextNode === void 0) {
      if (node && node.placeholderChildren.length > 1) {
        const remaining = sections.length - i;
        node = node.placeholderChildren.find((c) => c.maxDepth === remaining) || null;
      } else {
        node = node.placeholderChildren[0] || null;
      }
      if (!node) {
        break;
      }
      if (node.paramName) {
        params[node.paramName] = section;
      }
      paramsFound = true;
    } else {
      node = nextNode;
    }
  }
  if ((node === null || node.data === null) && wildcardNode !== null) {
    node = wildcardNode;
    params[node.paramName || "_"] = wildCardParam;
    paramsFound = true;
  }
  if (!node) {
    return null;
  }
  if (paramsFound) {
    return {
      ...node.data,
      params: paramsFound ? params : void 0
    };
  }
  return node.data;
}
function insert(ctx, path, data) {
  let isStaticRoute = true;
  const sections = path.split("/");
  let node = ctx.rootNode;
  let _unnamedPlaceholderCtr = 0;
  const matchedNodes = [node];
  for (const section of sections) {
    let childNode;
    if (childNode = node.children.get(section)) {
      node = childNode;
    } else {
      const type = getNodeType(section);
      childNode = createRadixNode({ type, parent: node });
      node.children.set(section, childNode);
      if (type === NODE_TYPES.PLACEHOLDER) {
        childNode.paramName = section === "*" ? `_${_unnamedPlaceholderCtr++}` : section.slice(1);
        node.placeholderChildren.push(childNode);
        isStaticRoute = false;
      } else if (type === NODE_TYPES.WILDCARD) {
        node.wildcardChildNode = childNode;
        childNode.paramName = section.slice(
          3
          /* "**:" */
        ) || "_";
        isStaticRoute = false;
      }
      matchedNodes.push(childNode);
      node = childNode;
    }
  }
  for (const [depth, node2] of matchedNodes.entries()) {
    node2.maxDepth = Math.max(matchedNodes.length - depth, node2.maxDepth || 0);
  }
  node.data = data;
  if (isStaticRoute === true) {
    ctx.staticRoutesMap[path] = node;
  }
  return node;
}
function remove(ctx, path) {
  let success = false;
  const sections = path.split("/");
  let node = ctx.rootNode;
  for (const section of sections) {
    node = node.children.get(section);
    if (!node) {
      return success;
    }
  }
  if (node.data) {
    const lastSection = sections.at(-1) || "";
    node.data = null;
    if (Object.keys(node.children).length === 0 && node.parent) {
      node.parent.children.delete(lastSection);
      node.parent.wildcardChildNode = null;
      node.parent.placeholderChildren = [];
    }
    success = true;
  }
  return success;
}
function createRadixNode(options = {}) {
  return {
    type: options.type || NODE_TYPES.NORMAL,
    maxDepth: 0,
    parent: options.parent || null,
    children: /* @__PURE__ */ new Map(),
    data: options.data || null,
    paramName: options.paramName || null,
    wildcardChildNode: null,
    placeholderChildren: []
  };
}
function getNodeType(str) {
  if (str.startsWith("**")) {
    return NODE_TYPES.WILDCARD;
  }
  if (str[0] === ":" || str === "*") {
    return NODE_TYPES.PLACEHOLDER;
  }
  return NODE_TYPES.NORMAL;
}

function toRouteMatcher(router) {
  const table = _routerNodeToTable("", router.ctx.rootNode);
  return _createMatcher(table, router.ctx.options.strictTrailingSlash);
}
function _createMatcher(table, strictTrailingSlash) {
  return {
    ctx: { table },
    matchAll: (path) => _matchRoutes(path, table, strictTrailingSlash)
  };
}
function _createRouteTable() {
  return {
    static: /* @__PURE__ */ new Map(),
    wildcard: /* @__PURE__ */ new Map(),
    dynamic: /* @__PURE__ */ new Map()
  };
}
function _matchRoutes(path, table, strictTrailingSlash) {
  if (strictTrailingSlash !== true && path.endsWith("/")) {
    path = path.slice(0, -1) || "/";
  }
  const matches = [];
  for (const [key, value] of _sortRoutesMap(table.wildcard)) {
    if (path === key || path.startsWith(key + "/")) {
      matches.push(value);
    }
  }
  for (const [key, value] of _sortRoutesMap(table.dynamic)) {
    if (path.startsWith(key + "/")) {
      const subPath = "/" + path.slice(key.length).split("/").splice(2).join("/");
      matches.push(..._matchRoutes(subPath, value));
    }
  }
  const staticMatch = table.static.get(path);
  if (staticMatch) {
    matches.push(staticMatch);
  }
  return matches.filter(Boolean);
}
function _sortRoutesMap(m) {
  return [...m.entries()].sort((a, b) => a[0].length - b[0].length);
}
function _routerNodeToTable(initialPath, initialNode) {
  const table = _createRouteTable();
  function _addNode(path, node) {
    if (path) {
      if (node.type === NODE_TYPES.NORMAL && !(path.includes("*") || path.includes(":"))) {
        if (node.data) {
          table.static.set(path, node.data);
        }
      } else if (node.type === NODE_TYPES.WILDCARD) {
        table.wildcard.set(path.replace("/**", ""), node.data);
      } else if (node.type === NODE_TYPES.PLACEHOLDER) {
        const subTable = _routerNodeToTable("", node);
        if (node.data) {
          subTable.static.set("/", node.data);
        }
        table.dynamic.set(path.replace(/\/\*|\/:\w+/, ""), subTable);
        return;
      }
    }
    for (const [childPath, child] of node.children.entries()) {
      _addNode(`${path}/${childPath}`.replace("//", "/"), child);
    }
  }
  _addNode(initialPath, initialNode);
  return table;
}

function isPlainObject(value) {
  if (value === null || typeof value !== "object") {
    return false;
  }
  const prototype = Object.getPrototypeOf(value);
  if (prototype !== null && prototype !== Object.prototype && Object.getPrototypeOf(prototype) !== null) {
    return false;
  }
  if (Symbol.iterator in value) {
    return false;
  }
  if (Symbol.toStringTag in value) {
    return Object.prototype.toString.call(value) === "[object Module]";
  }
  return true;
}

function _defu(baseObject, defaults, namespace = ".", merger) {
  if (!isPlainObject(defaults)) {
    return _defu(baseObject, {}, namespace, merger);
  }
  const object = { ...defaults };
  for (const key of Object.keys(baseObject)) {
    if (key === "__proto__" || key === "constructor") {
      continue;
    }
    const value = baseObject[key];
    if (value === null || value === void 0) {
      continue;
    }
    if (merger && merger(object, key, value, namespace)) {
      continue;
    }
    if (Array.isArray(value) && Array.isArray(object[key])) {
      object[key] = [...value, ...object[key]];
    } else if (isPlainObject(value) && isPlainObject(object[key])) {
      object[key] = _defu(
        value,
        object[key],
        (namespace ? `${namespace}.` : "") + key.toString(),
        merger
      );
    } else {
      object[key] = value;
    }
  }
  return object;
}
function createDefu(merger) {
  return (...arguments_) => (
    // eslint-disable-next-line unicorn/no-array-reduce
    arguments_.reduce((p, c) => _defu(p, c, "", merger), {})
  );
}
const defu = createDefu();
const defuFn = createDefu((object, key, currentValue) => {
  if (object[key] !== void 0 && typeof currentValue === "function") {
    object[key] = currentValue(object[key]);
    return true;
  }
});

function o(n){throw new Error(`${n} is not implemented yet!`)}let i$1 = class i extends EventEmitter{__unenv__={};readableEncoding=null;readableEnded=true;readableFlowing=false;readableHighWaterMark=0;readableLength=0;readableObjectMode=false;readableAborted=false;readableDidRead=false;closed=false;errored=null;readable=false;destroyed=false;static from(e,t){return new i(t)}constructor(e){super();}_read(e){}read(e){}setEncoding(e){return this}pause(){return this}resume(){return this}isPaused(){return  true}unpipe(e){return this}unshift(e,t){}wrap(e){return this}push(e,t){return  false}_destroy(e,t){this.removeAllListeners();}destroy(e){return this.destroyed=true,this._destroy(e),this}pipe(e,t){return {}}compose(e,t){throw new Error("Method not implemented.")}[Symbol.asyncDispose](){return this.destroy(),Promise.resolve()}async*[Symbol.asyncIterator](){throw o("Readable.asyncIterator")}iterator(e){throw o("Readable.iterator")}map(e,t){throw o("Readable.map")}filter(e,t){throw o("Readable.filter")}forEach(e,t){throw o("Readable.forEach")}reduce(e,t,r){throw o("Readable.reduce")}find(e,t){throw o("Readable.find")}findIndex(e,t){throw o("Readable.findIndex")}some(e,t){throw o("Readable.some")}toArray(e){throw o("Readable.toArray")}every(e,t){throw o("Readable.every")}flatMap(e,t){throw o("Readable.flatMap")}drop(e,t){throw o("Readable.drop")}take(e,t){throw o("Readable.take")}asIndexedPairs(e){throw o("Readable.asIndexedPairs")}};let l$1 = class l extends EventEmitter{__unenv__={};writable=true;writableEnded=false;writableFinished=false;writableHighWaterMark=0;writableLength=0;writableObjectMode=false;writableCorked=0;closed=false;errored=null;writableNeedDrain=false;writableAborted=false;destroyed=false;_data;_encoding="utf8";constructor(e){super();}pipe(e,t){return {}}_write(e,t,r){if(this.writableEnded){r&&r();return}if(this._data===void 0)this._data=e;else {const s=typeof this._data=="string"?Buffer$1.from(this._data,this._encoding||t||"utf8"):this._data,a=typeof e=="string"?Buffer$1.from(e,t||this._encoding||"utf8"):e;this._data=Buffer$1.concat([s,a]);}this._encoding=t,r&&r();}_writev(e,t){}_destroy(e,t){}_final(e){}write(e,t,r){const s=typeof t=="string"?this._encoding:"utf8",a=typeof t=="function"?t:typeof r=="function"?r:void 0;return this._write(e,s,a),true}setDefaultEncoding(e){return this}end(e,t,r){const s=typeof e=="function"?e:typeof t=="function"?t:typeof r=="function"?r:void 0;if(this.writableEnded)return s&&s(),this;const a=e===s?void 0:e;if(a){const u=t===s?void 0:t;this.write(a,u,s);}return this.writableEnded=true,this.writableFinished=true,this.emit("close"),this.emit("finish"),this}cork(){}uncork(){}destroy(e){return this.destroyed=true,delete this._data,this.removeAllListeners(),this}compose(e,t){throw new Error("Method not implemented.")}[Symbol.asyncDispose](){return Promise.resolve()}};const c$1=class c{allowHalfOpen=true;_destroy;constructor(e=new i$1,t=new l$1){Object.assign(this,e),Object.assign(this,t),this._destroy=m(e._destroy,t._destroy);}};function _(){return Object.assign(c$1.prototype,i$1.prototype),Object.assign(c$1.prototype,l$1.prototype),c$1}function m(...n){return function(...e){for(const t of n)t(...e);}}const g=_();class A extends g{__unenv__={};bufferSize=0;bytesRead=0;bytesWritten=0;connecting=false;destroyed=false;pending=false;localAddress="";localPort=0;remoteAddress="";remoteFamily="";remotePort=0;autoSelectFamilyAttemptedAddresses=[];readyState="readOnly";constructor(e){super();}write(e,t,r){return  false}connect(e,t,r){return this}end(e,t,r){return this}setEncoding(e){return this}pause(){return this}resume(){return this}setTimeout(e,t){return this}setNoDelay(e){return this}setKeepAlive(e,t){return this}address(){return {}}unref(){return this}ref(){return this}destroySoon(){this.destroy();}resetAndDestroy(){const e=new Error("ERR_SOCKET_CLOSED");return e.code="ERR_SOCKET_CLOSED",this.destroy(e),this}}class y extends i$1{aborted=false;httpVersion="1.1";httpVersionMajor=1;httpVersionMinor=1;complete=true;connection;socket;headers={};trailers={};method="GET";url="/";statusCode=200;statusMessage="";closed=false;errored=null;readable=false;constructor(e){super(),this.socket=this.connection=e||new A;}get rawHeaders(){const e=this.headers,t=[];for(const r in e)if(Array.isArray(e[r]))for(const s of e[r])t.push(r,s);else t.push(r,e[r]);return t}get rawTrailers(){return []}setTimeout(e,t){return this}get headersDistinct(){return p(this.headers)}get trailersDistinct(){return p(this.trailers)}}function p(n){const e={};for(const[t,r]of Object.entries(n))t&&(e[t]=(Array.isArray(r)?r:[r]).filter(Boolean));return e}class w extends l$1{statusCode=200;statusMessage="";upgrading=false;chunkedEncoding=false;shouldKeepAlive=false;useChunkedEncodingByDefault=false;sendDate=false;finished=false;headersSent=false;strictContentLength=false;connection=null;socket=null;req;_headers={};constructor(e){super(),this.req=e;}assignSocket(e){e._httpMessage=this,this.socket=e,this.connection=e,this.emit("socket",e),this._flush();}_flush(){this.flushHeaders();}detachSocket(e){}writeContinue(e){}writeHead(e,t,r){e&&(this.statusCode=e),typeof t=="string"&&(this.statusMessage=t,t=void 0);const s=r||t;if(s&&!Array.isArray(s))for(const a in s)this.setHeader(a,s[a]);return this.headersSent=true,this}writeProcessing(){}setTimeout(e,t){return this}appendHeader(e,t){e=e.toLowerCase();const r=this._headers[e],s=[...Array.isArray(r)?r:[r],...Array.isArray(t)?t:[t]].filter(Boolean);return this._headers[e]=s.length>1?s:s[0],this}setHeader(e,t){return this._headers[e.toLowerCase()]=t,this}setHeaders(e){for(const[t,r]of Object.entries(e))this.setHeader(t,r);return this}getHeader(e){return this._headers[e.toLowerCase()]}getHeaders(){return this._headers}getHeaderNames(){return Object.keys(this._headers)}hasHeader(e){return e.toLowerCase()in this._headers}removeHeader(e){delete this._headers[e.toLowerCase()];}addTrailers(e){}flushHeaders(){}writeEarlyHints(e,t){typeof t=="function"&&t();}}const E=(()=>{const n=function(){};return n.prototype=Object.create(null),n})();function R(n={}){const e=new E,t=Array.isArray(n)||H(n)?n:Object.entries(n);for(const[r,s]of t)if(s){if(e[r]===void 0){e[r]=s;continue}e[r]=[...Array.isArray(e[r])?e[r]:[e[r]],...Array.isArray(s)?s:[s]];}return e}function H(n){return typeof n?.entries=="function"}function v(n={}){if(n instanceof Headers)return n;const e=new Headers;for(const[t,r]of Object.entries(n))if(r!==void 0){if(Array.isArray(r)){for(const s of r)e.append(t,String(s));continue}e.set(t,String(r));}return e}const S=new Set([101,204,205,304]);async function b(n,e){const t=new y,r=new w(t);t.url=e.url?.toString()||"/";let s;if(!t.url.startsWith("/")){const d=new URL(t.url);s=d.host,t.url=d.pathname+d.search+d.hash;}t.method=e.method||"GET",t.headers=R(e.headers||{}),t.headers.host||(t.headers.host=e.host||s||"localhost"),t.connection.encrypted=t.connection.encrypted||e.protocol==="https",t.body=e.body||null,t.__unenv__=e.context,await n(t,r);let a=r._data;(S.has(r.statusCode)||t.method.toUpperCase()==="HEAD")&&(a=null,delete r._headers["content-length"]);const u={status:r.statusCode,statusText:r.statusMessage,headers:r._headers,body:a};return t.destroy(),r.destroy(),u}async function C(n,e,t={}){try{const r=await b(n,{url:e,...t});return new Response(r.body,{status:r.status,statusText:r.statusText,headers:v(r.headers)})}catch(r){return new Response(r.toString(),{status:Number.parseInt(r.statusCode||r.code)||500,statusText:r.statusText})}}

function hasProp(obj, prop) {
  try {
    return prop in obj;
  } catch {
    return false;
  }
}

class H3Error extends Error {
  static __h3_error__ = true;
  statusCode = 500;
  fatal = false;
  unhandled = false;
  statusMessage;
  data;
  cause;
  constructor(message, opts = {}) {
    super(message, opts);
    if (opts.cause && !this.cause) {
      this.cause = opts.cause;
    }
  }
  toJSON() {
    const obj = {
      message: this.message,
      statusCode: sanitizeStatusCode(this.statusCode, 500)
    };
    if (this.statusMessage) {
      obj.statusMessage = sanitizeStatusMessage(this.statusMessage);
    }
    if (this.data !== void 0) {
      obj.data = this.data;
    }
    return obj;
  }
}
function createError$1(input) {
  if (typeof input === "string") {
    return new H3Error(input);
  }
  if (isError(input)) {
    return input;
  }
  const err = new H3Error(input.message ?? input.statusMessage ?? "", {
    cause: input.cause || input
  });
  if (hasProp(input, "stack")) {
    try {
      Object.defineProperty(err, "stack", {
        get() {
          return input.stack;
        }
      });
    } catch {
      try {
        err.stack = input.stack;
      } catch {
      }
    }
  }
  if (input.data) {
    err.data = input.data;
  }
  if (input.statusCode) {
    err.statusCode = sanitizeStatusCode(input.statusCode, err.statusCode);
  } else if (input.status) {
    err.statusCode = sanitizeStatusCode(input.status, err.statusCode);
  }
  if (input.statusMessage) {
    err.statusMessage = input.statusMessage;
  } else if (input.statusText) {
    err.statusMessage = input.statusText;
  }
  if (err.statusMessage) {
    const originalMessage = err.statusMessage;
    const sanitizedMessage = sanitizeStatusMessage(err.statusMessage);
    if (sanitizedMessage !== originalMessage) {
      console.warn(
        "[h3] Please prefer using `message` for longer error messages instead of `statusMessage`. In the future, `statusMessage` will be sanitized by default."
      );
    }
  }
  if (input.fatal !== void 0) {
    err.fatal = input.fatal;
  }
  if (input.unhandled !== void 0) {
    err.unhandled = input.unhandled;
  }
  return err;
}
function sendError(event, error, debug) {
  if (event.handled) {
    return;
  }
  const h3Error = isError(error) ? error : createError$1(error);
  const responseBody = {
    statusCode: h3Error.statusCode,
    statusMessage: h3Error.statusMessage,
    stack: [],
    data: h3Error.data
  };
  if (debug) {
    responseBody.stack = (h3Error.stack || "").split("\n").map((l) => l.trim());
  }
  if (event.handled) {
    return;
  }
  const _code = Number.parseInt(h3Error.statusCode);
  setResponseStatus(event, _code, h3Error.statusMessage);
  event.node.res.setHeader("content-type", MIMES.json);
  event.node.res.end(JSON.stringify(responseBody, void 0, 2));
}
function isError(input) {
  return input?.constructor?.__h3_error__ === true;
}

function parse(multipartBodyBuffer, boundary) {
  let lastline = "";
  let state = 0 /* INIT */;
  let buffer = [];
  const allParts = [];
  let currentPartHeaders = [];
  for (let i = 0; i < multipartBodyBuffer.length; i++) {
    const prevByte = i > 0 ? multipartBodyBuffer[i - 1] : null;
    const currByte = multipartBodyBuffer[i];
    const newLineChar = currByte === 10 || currByte === 13;
    if (!newLineChar) {
      lastline += String.fromCodePoint(currByte);
    }
    const newLineDetected = currByte === 10 && prevByte === 13;
    if (0 /* INIT */ === state && newLineDetected) {
      if ("--" + boundary === lastline) {
        state = 1 /* READING_HEADERS */;
      }
      lastline = "";
    } else if (1 /* READING_HEADERS */ === state && newLineDetected) {
      if (lastline.length > 0) {
        const i2 = lastline.indexOf(":");
        if (i2 > 0) {
          const name = lastline.slice(0, i2).toLowerCase();
          const value = lastline.slice(i2 + 1).trim();
          currentPartHeaders.push([name, value]);
        }
      } else {
        state = 2 /* READING_DATA */;
        buffer = [];
      }
      lastline = "";
    } else if (2 /* READING_DATA */ === state) {
      if (lastline.length > boundary.length + 4) {
        lastline = "";
      }
      if ("--" + boundary === lastline) {
        const j = buffer.length - lastline.length;
        const part = buffer.slice(0, j - 1);
        allParts.push(process$1(part, currentPartHeaders));
        buffer = [];
        currentPartHeaders = [];
        lastline = "";
        state = 3 /* READING_PART_SEPARATOR */;
      } else {
        buffer.push(currByte);
      }
      if (newLineDetected) {
        lastline = "";
      }
    } else if (3 /* READING_PART_SEPARATOR */ === state && newLineDetected) {
      state = 1 /* READING_HEADERS */;
    }
  }
  return allParts;
}
function process$1(data, headers) {
  const dataObj = {};
  const contentDispositionHeader = headers.find((h) => h[0] === "content-disposition")?.[1] || "";
  for (const i of contentDispositionHeader.split(";")) {
    const s = i.split("=");
    if (s.length !== 2) {
      continue;
    }
    const key = (s[0] || "").trim();
    if (key === "name" || key === "filename") {
      const _value = (s[1] || "").trim().replace(/"/g, "");
      dataObj[key] = Buffer.from(_value, "latin1").toString("utf8");
    }
  }
  const contentType = headers.find((h) => h[0] === "content-type")?.[1] || "";
  if (contentType) {
    dataObj.type = contentType;
  }
  dataObj.data = Buffer.from(data);
  return dataObj;
}

function getQuery(event) {
  return getQuery$1(event.path || "");
}
function getRouterParams(event, opts = {}) {
  let params = event.context.params || {};
  if (opts.decode) {
    params = { ...params };
    for (const key in params) {
      params[key] = decode$1(params[key]);
    }
  }
  return params;
}
function getRouterParam(event, name, opts = {}) {
  const params = getRouterParams(event, opts);
  return params[name];
}
function isMethod(event, expected, allowHead) {
  if (typeof expected === "string") {
    if (event.method === expected) {
      return true;
    }
  } else if (expected.includes(event.method)) {
    return true;
  }
  return false;
}
function assertMethod(event, expected, allowHead) {
  if (!isMethod(event, expected)) {
    throw createError$1({
      statusCode: 405,
      statusMessage: "HTTP method is not allowed."
    });
  }
}
function getRequestHeaders(event) {
  const _headers = {};
  for (const key in event.node.req.headers) {
    const val = event.node.req.headers[key];
    _headers[key] = Array.isArray(val) ? val.filter(Boolean).join(", ") : val;
  }
  return _headers;
}
function getRequestHeader(event, name) {
  const headers = getRequestHeaders(event);
  const value = headers[name.toLowerCase()];
  return value;
}
const getHeader = getRequestHeader;
function getRequestHost(event, opts = {}) {
  if (opts.xForwardedHost) {
    const _header = event.node.req.headers["x-forwarded-host"];
    const xForwardedHost = (_header || "").split(",").shift()?.trim();
    if (xForwardedHost) {
      return xForwardedHost;
    }
  }
  return event.node.req.headers.host || "localhost";
}
function getRequestProtocol(event, opts = {}) {
  if (opts.xForwardedProto !== false && event.node.req.headers["x-forwarded-proto"] === "https") {
    return "https";
  }
  return event.node.req.connection?.encrypted ? "https" : "http";
}
function getRequestURL(event, opts = {}) {
  const host = getRequestHost(event, opts);
  const protocol = getRequestProtocol(event, opts);
  const path = (event.node.req.originalUrl || event.path).replace(
    /^[/\\]+/g,
    "/"
  );
  return new URL(path, `${protocol}://${host}`);
}

const RawBodySymbol = Symbol.for("h3RawBody");
const ParsedBodySymbol = Symbol.for("h3ParsedBody");
const PayloadMethods$1 = ["PATCH", "POST", "PUT", "DELETE"];
function readRawBody(event, encoding = "utf8") {
  assertMethod(event, PayloadMethods$1);
  const _rawBody = event._requestBody || event.web?.request?.body || event.node.req[RawBodySymbol] || event.node.req.rawBody || event.node.req.body;
  if (_rawBody) {
    const promise2 = Promise.resolve(_rawBody).then((_resolved) => {
      if (Buffer.isBuffer(_resolved)) {
        return _resolved;
      }
      if (typeof _resolved.pipeTo === "function") {
        return new Promise((resolve, reject) => {
          const chunks = [];
          _resolved.pipeTo(
            new WritableStream({
              write(chunk) {
                chunks.push(chunk);
              },
              close() {
                resolve(Buffer.concat(chunks));
              },
              abort(reason) {
                reject(reason);
              }
            })
          ).catch(reject);
        });
      } else if (typeof _resolved.pipe === "function") {
        return new Promise((resolve, reject) => {
          const chunks = [];
          _resolved.on("data", (chunk) => {
            chunks.push(chunk);
          }).on("end", () => {
            resolve(Buffer.concat(chunks));
          }).on("error", reject);
        });
      }
      if (_resolved.constructor === Object) {
        return Buffer.from(JSON.stringify(_resolved));
      }
      if (_resolved instanceof URLSearchParams) {
        return Buffer.from(_resolved.toString());
      }
      if (_resolved instanceof FormData) {
        return new Response(_resolved).bytes().then((uint8arr) => Buffer.from(uint8arr));
      }
      return Buffer.from(_resolved);
    });
    return encoding ? promise2.then((buff) => buff.toString(encoding)) : promise2;
  }
  if (!Number.parseInt(event.node.req.headers["content-length"] || "") && !/\bchunked\b/i.test(
    String(event.node.req.headers["transfer-encoding"] ?? "")
  )) {
    return Promise.resolve(void 0);
  }
  const promise = event.node.req[RawBodySymbol] = new Promise(
    (resolve, reject) => {
      const bodyData = [];
      event.node.req.on("error", (err) => {
        reject(err);
      }).on("data", (chunk) => {
        bodyData.push(chunk);
      }).on("end", () => {
        resolve(Buffer.concat(bodyData));
      });
    }
  );
  const result = encoding ? promise.then((buff) => buff.toString(encoding)) : promise;
  return result;
}
async function readBody(event, options = {}) {
  const request = event.node.req;
  if (hasProp(request, ParsedBodySymbol)) {
    return request[ParsedBodySymbol];
  }
  const contentType = request.headers["content-type"] || "";
  const body = await readRawBody(event);
  let parsed;
  if (contentType === "application/json") {
    parsed = _parseJSON(body, options.strict ?? true);
  } else if (contentType.startsWith("application/x-www-form-urlencoded")) {
    parsed = _parseURLEncodedBody(body);
  } else if (contentType.startsWith("text/")) {
    parsed = body;
  } else {
    parsed = _parseJSON(body, options.strict ?? false);
  }
  request[ParsedBodySymbol] = parsed;
  return parsed;
}
async function readMultipartFormData(event) {
  const contentType = getRequestHeader(event, "content-type");
  if (!contentType || !contentType.startsWith("multipart/form-data")) {
    return;
  }
  const boundary = contentType.match(/boundary=([^;]*)(;|$)/i)?.[1];
  if (!boundary) {
    return;
  }
  const body = await readRawBody(event, false);
  if (!body) {
    return;
  }
  return parse(body, boundary);
}
function getRequestWebStream(event) {
  if (!PayloadMethods$1.includes(event.method)) {
    return;
  }
  const bodyStream = event.web?.request?.body || event._requestBody;
  if (bodyStream) {
    return bodyStream;
  }
  const _hasRawBody = RawBodySymbol in event.node.req || "rawBody" in event.node.req || "body" in event.node.req || "__unenv__" in event.node.req;
  if (_hasRawBody) {
    return new ReadableStream({
      async start(controller) {
        const _rawBody = await readRawBody(event, false);
        if (_rawBody) {
          controller.enqueue(_rawBody);
        }
        controller.close();
      }
    });
  }
  return new ReadableStream({
    start: (controller) => {
      event.node.req.on("data", (chunk) => {
        controller.enqueue(chunk);
      });
      event.node.req.on("end", () => {
        controller.close();
      });
      event.node.req.on("error", (err) => {
        controller.error(err);
      });
    }
  });
}
function _parseJSON(body = "", strict) {
  if (!body) {
    return void 0;
  }
  try {
    return destr(body, { strict });
  } catch {
    throw createError$1({
      statusCode: 400,
      statusMessage: "Bad Request",
      message: "Invalid JSON body"
    });
  }
}
function _parseURLEncodedBody(body) {
  const form = new URLSearchParams(body);
  const parsedForm = /* @__PURE__ */ Object.create(null);
  for (const [key, value] of form.entries()) {
    if (hasProp(parsedForm, key)) {
      if (!Array.isArray(parsedForm[key])) {
        parsedForm[key] = [parsedForm[key]];
      }
      parsedForm[key].push(value);
    } else {
      parsedForm[key] = value;
    }
  }
  return parsedForm;
}

function handleCacheHeaders(event, opts) {
  const cacheControls = ["public", ...opts.cacheControls || []];
  let cacheMatched = false;
  if (opts.maxAge !== void 0) {
    cacheControls.push(`max-age=${+opts.maxAge}`, `s-maxage=${+opts.maxAge}`);
  }
  if (opts.modifiedTime) {
    const modifiedTime = new Date(opts.modifiedTime);
    const ifModifiedSince = event.node.req.headers["if-modified-since"];
    event.node.res.setHeader("last-modified", modifiedTime.toUTCString());
    if (ifModifiedSince && new Date(ifModifiedSince) >= modifiedTime) {
      cacheMatched = true;
    }
  }
  if (opts.etag) {
    event.node.res.setHeader("etag", opts.etag);
    const ifNonMatch = event.node.req.headers["if-none-match"];
    if (ifNonMatch === opts.etag) {
      cacheMatched = true;
    }
  }
  event.node.res.setHeader("cache-control", cacheControls.join(", "));
  if (cacheMatched) {
    event.node.res.statusCode = 304;
    if (!event.handled) {
      event.node.res.end();
    }
    return true;
  }
  return false;
}

const MIMES = {
  html: "text/html",
  json: "application/json"
};

const DISALLOWED_STATUS_CHARS = /[^\u0009\u0020-\u007E]/g;
function sanitizeStatusMessage(statusMessage = "") {
  return statusMessage.replace(DISALLOWED_STATUS_CHARS, "");
}
function sanitizeStatusCode(statusCode, defaultStatusCode = 200) {
  if (!statusCode) {
    return defaultStatusCode;
  }
  if (typeof statusCode === "string") {
    statusCode = Number.parseInt(statusCode, 10);
  }
  if (statusCode < 100 || statusCode > 999) {
    return defaultStatusCode;
  }
  return statusCode;
}

function getDistinctCookieKey(name, opts) {
  return [name, opts.domain || "", opts.path || "/"].join(";");
}

function parseCookies(event) {
  return parse$1(event.node.req.headers.cookie || "");
}
function getCookie(event, name) {
  return parseCookies(event)[name];
}
function setCookie(event, name, value, serializeOptions = {}) {
  if (!serializeOptions.path) {
    serializeOptions = { path: "/", ...serializeOptions };
  }
  const newCookie = serialize$2(name, value, serializeOptions);
  const currentCookies = splitCookiesString(
    event.node.res.getHeader("set-cookie")
  );
  if (currentCookies.length === 0) {
    event.node.res.setHeader("set-cookie", newCookie);
    return;
  }
  const newCookieKey = getDistinctCookieKey(name, serializeOptions);
  event.node.res.removeHeader("set-cookie");
  for (const cookie of currentCookies) {
    const parsed = parseSetCookie(cookie);
    const key = getDistinctCookieKey(parsed.name, parsed);
    if (key === newCookieKey) {
      continue;
    }
    event.node.res.appendHeader("set-cookie", cookie);
  }
  event.node.res.appendHeader("set-cookie", newCookie);
}
function deleteCookie(event, name, serializeOptions) {
  setCookie(event, name, "", {
    ...serializeOptions,
    maxAge: 0
  });
}
function splitCookiesString(cookiesString) {
  if (Array.isArray(cookiesString)) {
    return cookiesString.flatMap((c) => splitCookiesString(c));
  }
  if (typeof cookiesString !== "string") {
    return [];
  }
  const cookiesStrings = [];
  let pos = 0;
  let start;
  let ch;
  let lastComma;
  let nextStart;
  let cookiesSeparatorFound;
  const skipWhitespace = () => {
    while (pos < cookiesString.length && /\s/.test(cookiesString.charAt(pos))) {
      pos += 1;
    }
    return pos < cookiesString.length;
  };
  const notSpecialChar = () => {
    ch = cookiesString.charAt(pos);
    return ch !== "=" && ch !== ";" && ch !== ",";
  };
  while (pos < cookiesString.length) {
    start = pos;
    cookiesSeparatorFound = false;
    while (skipWhitespace()) {
      ch = cookiesString.charAt(pos);
      if (ch === ",") {
        lastComma = pos;
        pos += 1;
        skipWhitespace();
        nextStart = pos;
        while (pos < cookiesString.length && notSpecialChar()) {
          pos += 1;
        }
        if (pos < cookiesString.length && cookiesString.charAt(pos) === "=") {
          cookiesSeparatorFound = true;
          pos = nextStart;
          cookiesStrings.push(cookiesString.slice(start, lastComma));
          start = pos;
        } else {
          pos = lastComma + 1;
        }
      } else {
        pos += 1;
      }
    }
    if (!cookiesSeparatorFound || pos >= cookiesString.length) {
      cookiesStrings.push(cookiesString.slice(start));
    }
  }
  return cookiesStrings;
}

const defer = typeof setImmediate === "undefined" ? (fn) => fn() : setImmediate;
function send(event, data, type) {
  if (type) {
    defaultContentType(event, type);
  }
  return new Promise((resolve) => {
    defer(() => {
      if (!event.handled) {
        event.node.res.end(data);
      }
      resolve();
    });
  });
}
function sendNoContent(event, code) {
  if (event.handled) {
    return;
  }
  if (!code && event.node.res.statusCode !== 200) {
    code = event.node.res.statusCode;
  }
  const _code = sanitizeStatusCode(code, 204);
  if (_code === 204) {
    event.node.res.removeHeader("content-length");
  }
  event.node.res.writeHead(_code);
  event.node.res.end();
}
function setResponseStatus(event, code, text) {
  if (code) {
    event.node.res.statusCode = sanitizeStatusCode(
      code,
      event.node.res.statusCode
    );
  }
  if (text) {
    event.node.res.statusMessage = sanitizeStatusMessage(text);
  }
}
function getResponseStatus(event) {
  return event.node.res.statusCode;
}
function getResponseStatusText(event) {
  return event.node.res.statusMessage;
}
function defaultContentType(event, type) {
  if (type && event.node.res.statusCode !== 304 && !event.node.res.getHeader("content-type")) {
    event.node.res.setHeader("content-type", type);
  }
}
function sendRedirect(event, location, code = 302) {
  event.node.res.statusCode = sanitizeStatusCode(
    code,
    event.node.res.statusCode
  );
  event.node.res.setHeader("location", location);
  const encodedLoc = location.replace(/"/g, "%22");
  const html = `<!DOCTYPE html><html><head><meta http-equiv="refresh" content="0; url=${encodedLoc}"></head></html>`;
  return send(event, html, MIMES.html);
}
function getResponseHeader(event, name) {
  return event.node.res.getHeader(name);
}
function setResponseHeaders(event, headers) {
  for (const [name, value] of Object.entries(headers)) {
    event.node.res.setHeader(
      name,
      value
    );
  }
}
const setHeaders = setResponseHeaders;
function setResponseHeader(event, name, value) {
  event.node.res.setHeader(name, value);
}
function appendResponseHeader(event, name, value) {
  let current = event.node.res.getHeader(name);
  if (!current) {
    event.node.res.setHeader(name, value);
    return;
  }
  if (!Array.isArray(current)) {
    current = [current.toString()];
  }
  event.node.res.setHeader(name, [...current, value]);
}
function removeResponseHeader(event, name) {
  return event.node.res.removeHeader(name);
}
function isStream(data) {
  if (!data || typeof data !== "object") {
    return false;
  }
  if (typeof data.pipe === "function") {
    if (typeof data._read === "function") {
      return true;
    }
    if (typeof data.abort === "function") {
      return true;
    }
  }
  if (typeof data.pipeTo === "function") {
    return true;
  }
  return false;
}
function isWebResponse(data) {
  return typeof Response !== "undefined" && data instanceof Response;
}
function sendStream(event, stream) {
  if (!stream || typeof stream !== "object") {
    throw new Error("[h3] Invalid stream provided.");
  }
  event.node.res._data = stream;
  if (!event.node.res.socket) {
    event._handled = true;
    return Promise.resolve();
  }
  if (hasProp(stream, "pipeTo") && typeof stream.pipeTo === "function") {
    return stream.pipeTo(
      new WritableStream({
        write(chunk) {
          event.node.res.write(chunk);
        }
      })
    ).then(() => {
      event.node.res.end();
    });
  }
  if (hasProp(stream, "pipe") && typeof stream.pipe === "function") {
    return new Promise((resolve, reject) => {
      stream.pipe(event.node.res);
      if (stream.on) {
        stream.on("end", () => {
          event.node.res.end();
          resolve();
        });
        stream.on("error", (error) => {
          reject(error);
        });
      }
      event.node.res.on("close", () => {
        if (stream.abort) {
          stream.abort();
        }
      });
    });
  }
  throw new Error("[h3] Invalid or incompatible stream provided.");
}
function sendWebResponse(event, response) {
  for (const [key, value] of response.headers) {
    if (key === "set-cookie") {
      event.node.res.appendHeader(key, splitCookiesString(value));
    } else {
      event.node.res.setHeader(key, value);
    }
  }
  if (response.status) {
    event.node.res.statusCode = sanitizeStatusCode(
      response.status,
      event.node.res.statusCode
    );
  }
  if (response.statusText) {
    event.node.res.statusMessage = sanitizeStatusMessage(response.statusText);
  }
  if (response.redirected) {
    event.node.res.setHeader("location", response.url);
  }
  if (!response.body) {
    event.node.res.end();
    return;
  }
  return sendStream(event, response.body);
}

const PayloadMethods = /* @__PURE__ */ new Set(["PATCH", "POST", "PUT", "DELETE"]);
const ignoredHeaders = /* @__PURE__ */ new Set([
  "transfer-encoding",
  "accept-encoding",
  "connection",
  "keep-alive",
  "upgrade",
  "expect",
  "host",
  "accept"
]);
async function proxyRequest(event, target, opts = {}) {
  let body;
  let duplex;
  if (PayloadMethods.has(event.method)) {
    if (opts.streamRequest) {
      body = getRequestWebStream(event);
      duplex = "half";
    } else {
      body = await readRawBody(event, false).catch(() => void 0);
    }
  }
  const method = opts.fetchOptions?.method || event.method;
  const fetchHeaders = mergeHeaders$1(
    getProxyRequestHeaders(event, { host: target.startsWith("/") }),
    opts.fetchOptions?.headers,
    opts.headers
  );
  return sendProxy(event, target, {
    ...opts,
    fetchOptions: {
      method,
      body,
      duplex,
      ...opts.fetchOptions,
      headers: fetchHeaders
    }
  });
}
async function sendProxy(event, target, opts = {}) {
  let response;
  try {
    response = await _getFetch(opts.fetch)(target, {
      headers: opts.headers,
      ignoreResponseError: true,
      // make $ofetch.raw transparent
      ...opts.fetchOptions
    });
  } catch (error) {
    throw createError$1({
      status: 502,
      statusMessage: "Bad Gateway",
      cause: error
    });
  }
  event.node.res.statusCode = sanitizeStatusCode(
    response.status,
    event.node.res.statusCode
  );
  event.node.res.statusMessage = sanitizeStatusMessage(response.statusText);
  const cookies = [];
  for (const [key, value] of response.headers.entries()) {
    if (key === "content-encoding") {
      continue;
    }
    if (key === "content-length") {
      continue;
    }
    if (key === "set-cookie") {
      cookies.push(...splitCookiesString(value));
      continue;
    }
    event.node.res.setHeader(key, value);
  }
  if (cookies.length > 0) {
    event.node.res.setHeader(
      "set-cookie",
      cookies.map((cookie) => {
        if (opts.cookieDomainRewrite) {
          cookie = rewriteCookieProperty(
            cookie,
            opts.cookieDomainRewrite,
            "domain"
          );
        }
        if (opts.cookiePathRewrite) {
          cookie = rewriteCookieProperty(
            cookie,
            opts.cookiePathRewrite,
            "path"
          );
        }
        return cookie;
      })
    );
  }
  if (opts.onResponse) {
    await opts.onResponse(event, response);
  }
  if (response._data !== void 0) {
    return response._data;
  }
  if (event.handled) {
    return;
  }
  if (opts.sendStream === false) {
    const data = new Uint8Array(await response.arrayBuffer());
    return event.node.res.end(data);
  }
  if (response.body) {
    for await (const chunk of response.body) {
      event.node.res.write(chunk);
    }
  }
  return event.node.res.end();
}
function getProxyRequestHeaders(event, opts) {
  const headers = /* @__PURE__ */ Object.create(null);
  const reqHeaders = getRequestHeaders(event);
  for (const name in reqHeaders) {
    if (!ignoredHeaders.has(name) || name === "host" && opts?.host) {
      headers[name] = reqHeaders[name];
    }
  }
  return headers;
}
function fetchWithEvent(event, req, init, options) {
  return _getFetch(options?.fetch)(req, {
    ...init,
    context: init?.context || event.context,
    headers: {
      ...getProxyRequestHeaders(event, {
        host: typeof req === "string" && req.startsWith("/")
      }),
      ...init?.headers
    }
  });
}
function _getFetch(_fetch) {
  if (_fetch) {
    return _fetch;
  }
  if (globalThis.fetch) {
    return globalThis.fetch;
  }
  throw new Error(
    "fetch is not available. Try importing `node-fetch-native/polyfill` for Node.js."
  );
}
function rewriteCookieProperty(header, map, property) {
  const _map = typeof map === "string" ? { "*": map } : map;
  return header.replace(
    new RegExp(`(;\\s*${property}=)([^;]+)`, "gi"),
    (match, prefix, previousValue) => {
      let newValue;
      if (previousValue in _map) {
        newValue = _map[previousValue];
      } else if ("*" in _map) {
        newValue = _map["*"];
      } else {
        return match;
      }
      return newValue ? prefix + newValue : "";
    }
  );
}
function mergeHeaders$1(defaults, ...inputs) {
  const _inputs = inputs.filter(Boolean);
  if (_inputs.length === 0) {
    return defaults;
  }
  const merged = new Headers(defaults);
  for (const input of _inputs) {
    const entries = Array.isArray(input) ? input : typeof input.entries === "function" ? input.entries() : Object.entries(input);
    for (const [key, value] of entries) {
      if (value !== void 0) {
        merged.set(key, value);
      }
    }
  }
  return merged;
}

class H3Event {
  "__is_event__" = true;
  // Context
  node;
  // Node
  web;
  // Web
  context = {};
  // Shared
  // Request
  _method;
  _path;
  _headers;
  _requestBody;
  // Response
  _handled = false;
  // Hooks
  _onBeforeResponseCalled;
  _onAfterResponseCalled;
  constructor(req, res) {
    this.node = { req, res };
  }
  // --- Request ---
  get method() {
    if (!this._method) {
      this._method = (this.node.req.method || "GET").toUpperCase();
    }
    return this._method;
  }
  get path() {
    return this._path || this.node.req.url || "/";
  }
  get headers() {
    if (!this._headers) {
      this._headers = _normalizeNodeHeaders(this.node.req.headers);
    }
    return this._headers;
  }
  // --- Respoonse ---
  get handled() {
    return this._handled || this.node.res.writableEnded || this.node.res.headersSent;
  }
  respondWith(response) {
    return Promise.resolve(response).then(
      (_response) => sendWebResponse(this, _response)
    );
  }
  // --- Utils ---
  toString() {
    return `[${this.method}] ${this.path}`;
  }
  toJSON() {
    return this.toString();
  }
  // --- Deprecated ---
  /** @deprecated Please use `event.node.req` instead. */
  get req() {
    return this.node.req;
  }
  /** @deprecated Please use `event.node.res` instead. */
  get res() {
    return this.node.res;
  }
}
function isEvent(input) {
  return hasProp(input, "__is_event__");
}
function createEvent(req, res) {
  return new H3Event(req, res);
}
function _normalizeNodeHeaders(nodeHeaders) {
  const headers = new Headers();
  for (const [name, value] of Object.entries(nodeHeaders)) {
    if (Array.isArray(value)) {
      for (const item of value) {
        headers.append(name, item);
      }
    } else if (value) {
      headers.set(name, value);
    }
  }
  return headers;
}

function defineEventHandler(handler) {
  if (typeof handler === "function") {
    handler.__is_handler__ = true;
    return handler;
  }
  const _hooks = {
    onRequest: _normalizeArray(handler.onRequest),
    onBeforeResponse: _normalizeArray(handler.onBeforeResponse)
  };
  const _handler = (event) => {
    return _callHandler(event, handler.handler, _hooks);
  };
  _handler.__is_handler__ = true;
  _handler.__resolve__ = handler.handler.__resolve__;
  _handler.__websocket__ = handler.websocket;
  return _handler;
}
function _normalizeArray(input) {
  return input ? Array.isArray(input) ? input : [input] : void 0;
}
async function _callHandler(event, handler, hooks) {
  if (hooks.onRequest) {
    for (const hook of hooks.onRequest) {
      await hook(event);
      if (event.handled) {
        return;
      }
    }
  }
  const body = await handler(event);
  const response = { body };
  if (hooks.onBeforeResponse) {
    for (const hook of hooks.onBeforeResponse) {
      await hook(event, response);
    }
  }
  return response.body;
}
const eventHandler = defineEventHandler;
function isEventHandler(input) {
  return hasProp(input, "__is_handler__");
}
function toEventHandler(input, _, _route) {
  return input;
}
function defineLazyEventHandler(factory) {
  let _promise;
  let _resolved;
  const resolveHandler = () => {
    if (_resolved) {
      return Promise.resolve(_resolved);
    }
    if (!_promise) {
      _promise = Promise.resolve(factory()).then((r) => {
        const handler2 = r.default || r;
        if (typeof handler2 !== "function") {
          throw new TypeError(
            "Invalid lazy handler result. It should be a function:",
            handler2
          );
        }
        _resolved = { handler: toEventHandler(r.default || r) };
        return _resolved;
      });
    }
    return _promise;
  };
  const handler = eventHandler((event) => {
    if (_resolved) {
      return _resolved.handler(event);
    }
    return resolveHandler().then((r) => r.handler(event));
  });
  handler.__resolve__ = resolveHandler;
  return handler;
}
const lazyEventHandler = defineLazyEventHandler;

function createApp(options = {}) {
  const stack = [];
  const handler = createAppEventHandler(stack, options);
  const resolve = createResolver(stack);
  handler.__resolve__ = resolve;
  const getWebsocket = cachedFn(() => websocketOptions(resolve, options));
  const app = {
    // @ts-expect-error
    use: (arg1, arg2, arg3) => use(app, arg1, arg2, arg3),
    resolve,
    handler,
    stack,
    options,
    get websocket() {
      return getWebsocket();
    }
  };
  return app;
}
function use(app, arg1, arg2, arg3) {
  if (Array.isArray(arg1)) {
    for (const i of arg1) {
      use(app, i, arg2, arg3);
    }
  } else if (Array.isArray(arg2)) {
    for (const i of arg2) {
      use(app, arg1, i, arg3);
    }
  } else if (typeof arg1 === "string") {
    app.stack.push(
      normalizeLayer({ ...arg3, route: arg1, handler: arg2 })
    );
  } else if (typeof arg1 === "function") {
    app.stack.push(normalizeLayer({ ...arg2, handler: arg1 }));
  } else {
    app.stack.push(normalizeLayer({ ...arg1 }));
  }
  return app;
}
function createAppEventHandler(stack, options) {
  const spacing = options.debug ? 2 : void 0;
  return eventHandler(async (event) => {
    event.node.req.originalUrl = event.node.req.originalUrl || event.node.req.url || "/";
    const _rawReqUrl = event.node.req.url || "/";
    const _reqPath = _decodePath(event._path || _rawReqUrl);
    event._path = _reqPath;
    const _needsRawUrl = _reqPath !== _rawReqUrl;
    let _layerPath;
    if (options.onRequest) {
      await options.onRequest(event);
    }
    for (const layer of stack) {
      if (layer.route.length > 1) {
        if (!_reqPath.startsWith(layer.route)) {
          continue;
        }
        _layerPath = _reqPath.slice(layer.route.length) || "/";
      } else {
        _layerPath = _reqPath;
      }
      if (layer.match && !layer.match(_layerPath, event)) {
        continue;
      }
      event._path = _layerPath;
      event.node.req.url = _needsRawUrl ? layer.route.length > 1 ? _rawReqUrl.slice(layer.route.length) || "/" : _rawReqUrl : _layerPath;
      const val = await layer.handler(event);
      const _body = val === void 0 ? void 0 : await val;
      if (_body !== void 0) {
        const _response = { body: _body };
        if (options.onBeforeResponse) {
          event._onBeforeResponseCalled = true;
          await options.onBeforeResponse(event, _response);
        }
        await handleHandlerResponse(event, _response.body, spacing);
        if (options.onAfterResponse) {
          event._onAfterResponseCalled = true;
          await options.onAfterResponse(event, _response);
        }
        return;
      }
      if (event.handled) {
        if (options.onAfterResponse) {
          event._onAfterResponseCalled = true;
          await options.onAfterResponse(event, void 0);
        }
        return;
      }
    }
    if (!event.handled) {
      throw createError$1({
        statusCode: 404,
        statusMessage: `Cannot find any path matching ${event.path || "/"}.`
      });
    }
    if (options.onAfterResponse) {
      event._onAfterResponseCalled = true;
      await options.onAfterResponse(event, void 0);
    }
  });
}
function createResolver(stack) {
  return async (path) => {
    let _layerPath;
    for (const layer of stack) {
      if (layer.route === "/" && !layer.handler.__resolve__) {
        continue;
      }
      if (!path.startsWith(layer.route)) {
        continue;
      }
      _layerPath = path.slice(layer.route.length) || "/";
      if (layer.match && !layer.match(_layerPath, void 0)) {
        continue;
      }
      let res = { route: layer.route, handler: layer.handler };
      if (res.handler.__resolve__) {
        const _res = await res.handler.__resolve__(_layerPath);
        if (!_res) {
          continue;
        }
        res = {
          ...res,
          ..._res,
          route: joinURL(res.route || "/", _res.route || "/")
        };
      }
      return res;
    }
  };
}
function normalizeLayer(input) {
  let handler = input.handler;
  if (handler.handler) {
    handler = handler.handler;
  }
  if (input.lazy) {
    handler = lazyEventHandler(handler);
  } else if (!isEventHandler(handler)) {
    handler = toEventHandler(handler, void 0, input.route);
  }
  return {
    route: withoutTrailingSlash(input.route),
    match: input.match,
    handler
  };
}
function handleHandlerResponse(event, val, jsonSpace) {
  if (val === null) {
    return sendNoContent(event);
  }
  if (val) {
    if (isWebResponse(val)) {
      return sendWebResponse(event, val);
    }
    if (isStream(val)) {
      return sendStream(event, val);
    }
    if (val.buffer) {
      return send(event, val);
    }
    if (val.arrayBuffer && typeof val.arrayBuffer === "function") {
      return val.arrayBuffer().then((arrayBuffer) => {
        return send(event, Buffer.from(arrayBuffer), val.type);
      });
    }
    if (val instanceof Error) {
      throw createError$1(val);
    }
    if (typeof val.end === "function") {
      return true;
    }
  }
  const valType = typeof val;
  if (valType === "string") {
    return send(event, val, MIMES.html);
  }
  if (valType === "object" || valType === "boolean" || valType === "number") {
    return send(event, JSON.stringify(val, void 0, jsonSpace), MIMES.json);
  }
  if (valType === "bigint") {
    return send(event, val.toString(), MIMES.json);
  }
  throw createError$1({
    statusCode: 500,
    statusMessage: `[h3] Cannot send ${valType} as response.`
  });
}
function cachedFn(fn) {
  let cache;
  return () => {
    if (!cache) {
      cache = fn();
    }
    return cache;
  };
}
function _decodePath(url) {
  const qIndex = url.indexOf("?");
  const path = qIndex === -1 ? url : url.slice(0, qIndex);
  const query = qIndex === -1 ? "" : url.slice(qIndex);
  const decodedPath = path.includes("%25") ? decodePath(path.replace(/%25/g, "%2525")) : decodePath(path);
  return decodedPath + query;
}
function websocketOptions(evResolver, appOptions) {
  return {
    ...appOptions.websocket,
    async resolve(info) {
      const url = info.request?.url || info.url || "/";
      const { pathname } = typeof url === "string" ? parseURL(url) : url;
      const resolved = await evResolver(pathname);
      return resolved?.handler?.__websocket__ || {};
    }
  };
}

const RouterMethods = [
  "connect",
  "delete",
  "get",
  "head",
  "options",
  "post",
  "put",
  "trace",
  "patch"
];
function createRouter(opts = {}) {
  const _router = createRouter$1({});
  const routes = {};
  let _matcher;
  const router = {};
  const addRoute = (path, handler, method) => {
    let route = routes[path];
    if (!route) {
      routes[path] = route = { path, handlers: {} };
      _router.insert(path, route);
    }
    if (Array.isArray(method)) {
      for (const m of method) {
        addRoute(path, handler, m);
      }
    } else {
      route.handlers[method] = toEventHandler(handler);
    }
    return router;
  };
  router.use = router.add = (path, handler, method) => addRoute(path, handler, method || "all");
  for (const method of RouterMethods) {
    router[method] = (path, handle) => router.add(path, handle, method);
  }
  const matchHandler = (path = "/", method = "get") => {
    const qIndex = path.indexOf("?");
    if (qIndex !== -1) {
      path = path.slice(0, Math.max(0, qIndex));
    }
    const matched = _router.lookup(path);
    if (!matched || !matched.handlers) {
      return {
        error: createError$1({
          statusCode: 404,
          name: "Not Found",
          statusMessage: `Cannot find any route matching ${path || "/"}.`
        })
      };
    }
    let handler = matched.handlers[method] || matched.handlers.all;
    if (!handler) {
      if (!_matcher) {
        _matcher = toRouteMatcher(_router);
      }
      const _matches = _matcher.matchAll(path).reverse();
      for (const _match of _matches) {
        if (_match.handlers[method]) {
          handler = _match.handlers[method];
          matched.handlers[method] = matched.handlers[method] || handler;
          break;
        }
        if (_match.handlers.all) {
          handler = _match.handlers.all;
          matched.handlers.all = matched.handlers.all || handler;
          break;
        }
      }
    }
    if (!handler) {
      return {
        error: createError$1({
          statusCode: 405,
          name: "Method Not Allowed",
          statusMessage: `Method ${method} is not allowed on this route.`
        })
      };
    }
    return { matched, handler };
  };
  const isPreemptive = opts.preemptive || opts.preemtive;
  router.handler = eventHandler((event) => {
    const match = matchHandler(
      event.path,
      event.method.toLowerCase()
    );
    if ("error" in match) {
      if (isPreemptive) {
        throw match.error;
      } else {
        return;
      }
    }
    event.context.matchedRoute = match.matched;
    const params = match.matched.params || {};
    event.context.params = params;
    return Promise.resolve(match.handler(event)).then((res) => {
      if (res === void 0 && isPreemptive) {
        return null;
      }
      return res;
    });
  });
  router.handler.__resolve__ = async (path) => {
    path = withLeadingSlash(path);
    const match = matchHandler(path);
    if ("error" in match) {
      return;
    }
    let res = {
      route: match.matched.path,
      handler: match.handler
    };
    if (match.handler.__resolve__) {
      const _res = await match.handler.__resolve__(path);
      if (!_res) {
        return;
      }
      res = { ...res, ..._res };
    }
    return res;
  };
  return router;
}
function toNodeListener(app) {
  const toNodeHandle = async function(req, res) {
    const event = createEvent(req, res);
    try {
      await app.handler(event);
    } catch (_error) {
      const error = createError$1(_error);
      if (!isError(_error)) {
        error.unhandled = true;
      }
      setResponseStatus(event, error.statusCode, error.statusMessage);
      if (app.options.onError) {
        await app.options.onError(error, event);
      }
      if (event.handled) {
        return;
      }
      if (error.unhandled || error.fatal) {
        console.error("[h3]", error.fatal ? "[fatal]" : "[unhandled]", error);
      }
      if (app.options.onBeforeResponse && !event._onBeforeResponseCalled) {
        await app.options.onBeforeResponse(event, { body: error });
      }
      await sendError(event, error, !!app.options.debug);
      if (app.options.onAfterResponse && !event._onAfterResponseCalled) {
        await app.options.onAfterResponse(event, { body: error });
      }
    }
  };
  return toNodeHandle;
}

function flatHooks(configHooks, hooks = {}, parentName) {
  for (const key in configHooks) {
    const subHook = configHooks[key];
    const name = parentName ? `${parentName}:${key}` : key;
    if (typeof subHook === "object" && subHook !== null) {
      flatHooks(subHook, hooks, name);
    } else if (typeof subHook === "function") {
      hooks[name] = subHook;
    }
  }
  return hooks;
}
const defaultTask = { run: (function_) => function_() };
const _createTask = () => defaultTask;
const createTask = typeof console.createTask !== "undefined" ? console.createTask : _createTask;
function serialTaskCaller(hooks, args) {
  const name = args.shift();
  const task = createTask(name);
  return hooks.reduce(
    (promise, hookFunction) => promise.then(() => task.run(() => hookFunction(...args))),
    Promise.resolve()
  );
}
function parallelTaskCaller(hooks, args) {
  const name = args.shift();
  const task = createTask(name);
  return Promise.all(hooks.map((hook) => task.run(() => hook(...args))));
}
function callEachWith(callbacks, arg0) {
  for (const callback of [...callbacks]) {
    callback(arg0);
  }
}

class Hookable {
  constructor() {
    this._hooks = {};
    this._before = void 0;
    this._after = void 0;
    this._deprecatedMessages = void 0;
    this._deprecatedHooks = {};
    this.hook = this.hook.bind(this);
    this.callHook = this.callHook.bind(this);
    this.callHookWith = this.callHookWith.bind(this);
  }
  hook(name, function_, options = {}) {
    if (!name || typeof function_ !== "function") {
      return () => {
      };
    }
    const originalName = name;
    let dep;
    while (this._deprecatedHooks[name]) {
      dep = this._deprecatedHooks[name];
      name = dep.to;
    }
    if (dep && !options.allowDeprecated) {
      let message = dep.message;
      if (!message) {
        message = `${originalName} hook has been deprecated` + (dep.to ? `, please use ${dep.to}` : "");
      }
      if (!this._deprecatedMessages) {
        this._deprecatedMessages = /* @__PURE__ */ new Set();
      }
      if (!this._deprecatedMessages.has(message)) {
        console.warn(message);
        this._deprecatedMessages.add(message);
      }
    }
    if (!function_.name) {
      try {
        Object.defineProperty(function_, "name", {
          get: () => "_" + name.replace(/\W+/g, "_") + "_hook_cb",
          configurable: true
        });
      } catch {
      }
    }
    this._hooks[name] = this._hooks[name] || [];
    this._hooks[name].push(function_);
    return () => {
      if (function_) {
        this.removeHook(name, function_);
        function_ = void 0;
      }
    };
  }
  hookOnce(name, function_) {
    let _unreg;
    let _function = (...arguments_) => {
      if (typeof _unreg === "function") {
        _unreg();
      }
      _unreg = void 0;
      _function = void 0;
      return function_(...arguments_);
    };
    _unreg = this.hook(name, _function);
    return _unreg;
  }
  removeHook(name, function_) {
    if (this._hooks[name]) {
      const index = this._hooks[name].indexOf(function_);
      if (index !== -1) {
        this._hooks[name].splice(index, 1);
      }
      if (this._hooks[name].length === 0) {
        delete this._hooks[name];
      }
    }
  }
  deprecateHook(name, deprecated) {
    this._deprecatedHooks[name] = typeof deprecated === "string" ? { to: deprecated } : deprecated;
    const _hooks = this._hooks[name] || [];
    delete this._hooks[name];
    for (const hook of _hooks) {
      this.hook(name, hook);
    }
  }
  deprecateHooks(deprecatedHooks) {
    Object.assign(this._deprecatedHooks, deprecatedHooks);
    for (const name in deprecatedHooks) {
      this.deprecateHook(name, deprecatedHooks[name]);
    }
  }
  addHooks(configHooks) {
    const hooks = flatHooks(configHooks);
    const removeFns = Object.keys(hooks).map(
      (key) => this.hook(key, hooks[key])
    );
    return () => {
      for (const unreg of removeFns.splice(0, removeFns.length)) {
        unreg();
      }
    };
  }
  removeHooks(configHooks) {
    const hooks = flatHooks(configHooks);
    for (const key in hooks) {
      this.removeHook(key, hooks[key]);
    }
  }
  removeAllHooks() {
    for (const key in this._hooks) {
      delete this._hooks[key];
    }
  }
  callHook(name, ...arguments_) {
    arguments_.unshift(name);
    return this.callHookWith(serialTaskCaller, name, ...arguments_);
  }
  callHookParallel(name, ...arguments_) {
    arguments_.unshift(name);
    return this.callHookWith(parallelTaskCaller, name, ...arguments_);
  }
  callHookWith(caller, name, ...arguments_) {
    const event = this._before || this._after ? { name, args: arguments_, context: {} } : void 0;
    if (this._before) {
      callEachWith(this._before, event);
    }
    const result = caller(
      name in this._hooks ? [...this._hooks[name]] : [],
      arguments_
    );
    if (result instanceof Promise) {
      return result.finally(() => {
        if (this._after && event) {
          callEachWith(this._after, event);
        }
      });
    }
    if (this._after && event) {
      callEachWith(this._after, event);
    }
    return result;
  }
  beforeEach(function_) {
    this._before = this._before || [];
    this._before.push(function_);
    return () => {
      if (this._before !== void 0) {
        const index = this._before.indexOf(function_);
        if (index !== -1) {
          this._before.splice(index, 1);
        }
      }
    };
  }
  afterEach(function_) {
    this._after = this._after || [];
    this._after.push(function_);
    return () => {
      if (this._after !== void 0) {
        const index = this._after.indexOf(function_);
        if (index !== -1) {
          this._after.splice(index, 1);
        }
      }
    };
  }
}
function createHooks() {
  return new Hookable();
}

const s$1=globalThis.Headers,i=globalThis.AbortController,l=globalThis.fetch||(()=>{throw new Error("[node-fetch-native] Failed to fetch: `globalThis.fetch` is not available!")});

class FetchError extends Error {
  constructor(message, opts) {
    super(message, opts);
    this.name = "FetchError";
    if (opts?.cause && !this.cause) {
      this.cause = opts.cause;
    }
  }
}
function createFetchError(ctx) {
  const errorMessage = ctx.error?.message || ctx.error?.toString() || "";
  const method = ctx.request?.method || ctx.options?.method || "GET";
  const url = ctx.request?.url || String(ctx.request) || "/";
  const requestStr = `[${method}] ${JSON.stringify(url)}`;
  const statusStr = ctx.response ? `${ctx.response.status} ${ctx.response.statusText}` : "<no response>";
  const message = `${requestStr}: ${statusStr}${errorMessage ? ` ${errorMessage}` : ""}`;
  const fetchError = new FetchError(
    message,
    ctx.error ? { cause: ctx.error } : void 0
  );
  for (const key of ["request", "options", "response"]) {
    Object.defineProperty(fetchError, key, {
      get() {
        return ctx[key];
      }
    });
  }
  for (const [key, refKey] of [
    ["data", "_data"],
    ["status", "status"],
    ["statusCode", "status"],
    ["statusText", "statusText"],
    ["statusMessage", "statusText"]
  ]) {
    Object.defineProperty(fetchError, key, {
      get() {
        return ctx.response && ctx.response[refKey];
      }
    });
  }
  return fetchError;
}

const payloadMethods = new Set(
  Object.freeze(["PATCH", "POST", "PUT", "DELETE"])
);
function isPayloadMethod(method = "GET") {
  return payloadMethods.has(method.toUpperCase());
}
function isJSONSerializable(value) {
  if (value === void 0) {
    return false;
  }
  const t = typeof value;
  if (t === "string" || t === "number" || t === "boolean" || t === null) {
    return true;
  }
  if (t !== "object") {
    return false;
  }
  if (Array.isArray(value)) {
    return true;
  }
  if (value.buffer) {
    return false;
  }
  if (value instanceof FormData || value instanceof URLSearchParams) {
    return false;
  }
  return value.constructor && value.constructor.name === "Object" || typeof value.toJSON === "function";
}
const textTypes = /* @__PURE__ */ new Set([
  "image/svg",
  "application/xml",
  "application/xhtml",
  "application/html"
]);
const JSON_RE = /^application\/(?:[\w!#$%&*.^`~-]*\+)?json(;.+)?$/i;
function detectResponseType(_contentType = "") {
  if (!_contentType) {
    return "json";
  }
  const contentType = _contentType.split(";").shift() || "";
  if (JSON_RE.test(contentType)) {
    return "json";
  }
  if (contentType === "text/event-stream") {
    return "stream";
  }
  if (textTypes.has(contentType) || contentType.startsWith("text/")) {
    return "text";
  }
  return "blob";
}
function resolveFetchOptions(request, input, defaults, Headers) {
  const headers = mergeHeaders(
    input?.headers ?? request?.headers,
    defaults?.headers,
    Headers
  );
  let query;
  if (defaults?.query || defaults?.params || input?.params || input?.query) {
    query = {
      ...defaults?.params,
      ...defaults?.query,
      ...input?.params,
      ...input?.query
    };
  }
  return {
    ...defaults,
    ...input,
    query,
    params: query,
    headers
  };
}
function mergeHeaders(input, defaults, Headers) {
  if (!defaults) {
    return new Headers(input);
  }
  const headers = new Headers(defaults);
  if (input) {
    for (const [key, value] of Symbol.iterator in input || Array.isArray(input) ? input : new Headers(input)) {
      headers.set(key, value);
    }
  }
  return headers;
}
async function callHooks(context, hooks) {
  if (hooks) {
    if (Array.isArray(hooks)) {
      for (const hook of hooks) {
        await hook(context);
      }
    } else {
      await hooks(context);
    }
  }
}

const retryStatusCodes = /* @__PURE__ */ new Set([
  408,
  // Request Timeout
  409,
  // Conflict
  425,
  // Too Early (Experimental)
  429,
  // Too Many Requests
  500,
  // Internal Server Error
  502,
  // Bad Gateway
  503,
  // Service Unavailable
  504
  // Gateway Timeout
]);
const nullBodyResponses = /* @__PURE__ */ new Set([101, 204, 205, 304]);
function createFetch(globalOptions = {}) {
  const {
    fetch = globalThis.fetch,
    Headers = globalThis.Headers,
    AbortController = globalThis.AbortController
  } = globalOptions;
  async function onError(context) {
    const isAbort = context.error && context.error.name === "AbortError" && !context.options.timeout || false;
    if (context.options.retry !== false && !isAbort) {
      let retries;
      if (typeof context.options.retry === "number") {
        retries = context.options.retry;
      } else {
        retries = isPayloadMethod(context.options.method) ? 0 : 1;
      }
      const responseCode = context.response && context.response.status || 500;
      if (retries > 0 && (Array.isArray(context.options.retryStatusCodes) ? context.options.retryStatusCodes.includes(responseCode) : retryStatusCodes.has(responseCode))) {
        const retryDelay = typeof context.options.retryDelay === "function" ? context.options.retryDelay(context) : context.options.retryDelay || 0;
        if (retryDelay > 0) {
          await new Promise((resolve) => setTimeout(resolve, retryDelay));
        }
        return $fetchRaw(context.request, {
          ...context.options,
          retry: retries - 1
        });
      }
    }
    const error = createFetchError(context);
    if (Error.captureStackTrace) {
      Error.captureStackTrace(error, $fetchRaw);
    }
    throw error;
  }
  const $fetchRaw = async function $fetchRaw2(_request, _options = {}) {
    const context = {
      request: _request,
      options: resolveFetchOptions(
        _request,
        _options,
        globalOptions.defaults,
        Headers
      ),
      response: void 0,
      error: void 0
    };
    if (context.options.method) {
      context.options.method = context.options.method.toUpperCase();
    }
    if (context.options.onRequest) {
      await callHooks(context, context.options.onRequest);
      if (!(context.options.headers instanceof Headers)) {
        context.options.headers = new Headers(
          context.options.headers || {}
          /* compat */
        );
      }
    }
    if (typeof context.request === "string") {
      if (context.options.baseURL) {
        context.request = withBase(context.request, context.options.baseURL);
      }
      if (context.options.query) {
        context.request = withQuery(context.request, context.options.query);
        delete context.options.query;
      }
      if ("query" in context.options) {
        delete context.options.query;
      }
      if ("params" in context.options) {
        delete context.options.params;
      }
    }
    if (context.options.body && isPayloadMethod(context.options.method)) {
      if (isJSONSerializable(context.options.body)) {
        const contentType = context.options.headers.get("content-type");
        if (typeof context.options.body !== "string") {
          context.options.body = contentType === "application/x-www-form-urlencoded" ? new URLSearchParams(
            context.options.body
          ).toString() : JSON.stringify(context.options.body);
        }
        if (!contentType) {
          context.options.headers.set("content-type", "application/json");
        }
        if (!context.options.headers.has("accept")) {
          context.options.headers.set("accept", "application/json");
        }
      } else if (
        // ReadableStream Body
        "pipeTo" in context.options.body && typeof context.options.body.pipeTo === "function" || // Node.js Stream Body
        typeof context.options.body.pipe === "function"
      ) {
        if (!("duplex" in context.options)) {
          context.options.duplex = "half";
        }
      }
    }
    let abortTimeout;
    if (!context.options.signal && context.options.timeout) {
      const controller = new AbortController();
      abortTimeout = setTimeout(() => {
        const error = new Error(
          "[TimeoutError]: The operation was aborted due to timeout"
        );
        error.name = "TimeoutError";
        error.code = 23;
        controller.abort(error);
      }, context.options.timeout);
      context.options.signal = controller.signal;
    }
    try {
      context.response = await fetch(
        context.request,
        context.options
      );
    } catch (error) {
      context.error = error;
      if (context.options.onRequestError) {
        await callHooks(
          context,
          context.options.onRequestError
        );
      }
      return await onError(context);
    } finally {
      if (abortTimeout) {
        clearTimeout(abortTimeout);
      }
    }
    const hasBody = (context.response.body || // https://github.com/unjs/ofetch/issues/324
    // https://github.com/unjs/ofetch/issues/294
    // https://github.com/JakeChampion/fetch/issues/1454
    context.response._bodyInit) && !nullBodyResponses.has(context.response.status) && context.options.method !== "HEAD";
    if (hasBody) {
      const responseType = (context.options.parseResponse ? "json" : context.options.responseType) || detectResponseType(context.response.headers.get("content-type") || "");
      switch (responseType) {
        case "json": {
          const data = await context.response.text();
          const parseFunction = context.options.parseResponse || destr;
          context.response._data = parseFunction(data);
          break;
        }
        case "stream": {
          context.response._data = context.response.body || context.response._bodyInit;
          break;
        }
        default: {
          context.response._data = await context.response[responseType]();
        }
      }
    }
    if (context.options.onResponse) {
      await callHooks(
        context,
        context.options.onResponse
      );
    }
    if (!context.options.ignoreResponseError && context.response.status >= 400 && context.response.status < 600) {
      if (context.options.onResponseError) {
        await callHooks(
          context,
          context.options.onResponseError
        );
      }
      return await onError(context);
    }
    return context.response;
  };
  const $fetch = async function $fetch2(request, options) {
    const r = await $fetchRaw(request, options);
    return r._data;
  };
  $fetch.raw = $fetchRaw;
  $fetch.native = (...args) => fetch(...args);
  $fetch.create = (defaultOptions = {}, customGlobalOptions = {}) => createFetch({
    ...globalOptions,
    ...customGlobalOptions,
    defaults: {
      ...globalOptions.defaults,
      ...customGlobalOptions.defaults,
      ...defaultOptions
    }
  });
  return $fetch;
}

function createNodeFetch() {
  const useKeepAlive = JSON.parse(process.env.FETCH_KEEP_ALIVE || "false");
  if (!useKeepAlive) {
    return l;
  }
  const agentOptions = { keepAlive: true };
  const httpAgent = new http.Agent(agentOptions);
  const httpsAgent = new https.Agent(agentOptions);
  const nodeFetchOptions = {
    agent(parsedURL) {
      return parsedURL.protocol === "http:" ? httpAgent : httpsAgent;
    }
  };
  return function nodeFetchWithKeepAlive(input, init) {
    return l(input, { ...nodeFetchOptions, ...init });
  };
}
const fetch = globalThis.fetch ? (...args) => globalThis.fetch(...args) : createNodeFetch();
const Headers$1 = globalThis.Headers || s$1;
const AbortController = globalThis.AbortController || i;
const ofetch = createFetch({ fetch, Headers: Headers$1, AbortController });
const $fetch$1 = ofetch;

function wrapToPromise(value) {
  if (!value || typeof value.then !== "function") {
    return Promise.resolve(value);
  }
  return value;
}
function asyncCall(function_, ...arguments_) {
  try {
    return wrapToPromise(function_(...arguments_));
  } catch (error) {
    return Promise.reject(error);
  }
}
function isPrimitive(value) {
  const type = typeof value;
  return value === null || type !== "object" && type !== "function";
}
function isPureObject(value) {
  const proto = Object.getPrototypeOf(value);
  return !proto || proto.isPrototypeOf(Object);
}
function stringify(value) {
  if (isPrimitive(value)) {
    return String(value);
  }
  if (isPureObject(value) || Array.isArray(value)) {
    return JSON.stringify(value);
  }
  if (typeof value.toJSON === "function") {
    return stringify(value.toJSON());
  }
  throw new Error("[unstorage] Cannot stringify value!");
}
const BASE64_PREFIX = "base64:";
function serializeRaw(value) {
  if (typeof value === "string") {
    return value;
  }
  return BASE64_PREFIX + base64Encode(value);
}
function deserializeRaw(value) {
  if (typeof value !== "string") {
    return value;
  }
  if (!value.startsWith(BASE64_PREFIX)) {
    return value;
  }
  return base64Decode(value.slice(BASE64_PREFIX.length));
}
function base64Decode(input) {
  if (globalThis.Buffer) {
    return Buffer.from(input, "base64");
  }
  return Uint8Array.from(
    globalThis.atob(input),
    (c) => c.codePointAt(0)
  );
}
function base64Encode(input) {
  if (globalThis.Buffer) {
    return Buffer.from(input).toString("base64");
  }
  return globalThis.btoa(String.fromCodePoint(...input));
}

const storageKeyProperties = [
  "has",
  "hasItem",
  "get",
  "getItem",
  "getItemRaw",
  "set",
  "setItem",
  "setItemRaw",
  "del",
  "remove",
  "removeItem",
  "getMeta",
  "setMeta",
  "removeMeta",
  "getKeys",
  "clear",
  "mount",
  "unmount"
];
function prefixStorage(storage, base) {
  base = normalizeBaseKey(base);
  if (!base) {
    return storage;
  }
  const nsStorage = { ...storage };
  for (const property of storageKeyProperties) {
    nsStorage[property] = (key = "", ...args) => (
      // @ts-ignore
      storage[property](base + key, ...args)
    );
  }
  nsStorage.getKeys = (key = "", ...arguments_) => storage.getKeys(base + key, ...arguments_).then((keys) => keys.map((key2) => key2.slice(base.length)));
  nsStorage.keys = nsStorage.getKeys;
  nsStorage.getItems = async (items, commonOptions) => {
    const prefixedItems = items.map(
      (item) => typeof item === "string" ? base + item : { ...item, key: base + item.key }
    );
    const results = await storage.getItems(prefixedItems, commonOptions);
    return results.map((entry) => ({
      key: entry.key.slice(base.length),
      value: entry.value
    }));
  };
  nsStorage.setItems = async (items, commonOptions) => {
    const prefixedItems = items.map((item) => ({
      key: base + item.key,
      value: item.value,
      options: item.options
    }));
    return storage.setItems(prefixedItems, commonOptions);
  };
  return nsStorage;
}
function normalizeKey$1(key) {
  if (!key) {
    return "";
  }
  return key.split("?")[0]?.replace(/[/\\]/g, ":").replace(/:+/g, ":").replace(/^:|:$/g, "") || "";
}
function joinKeys(...keys) {
  return normalizeKey$1(keys.join(":"));
}
function normalizeBaseKey(base) {
  base = normalizeKey$1(base);
  return base ? base + ":" : "";
}
function filterKeyByDepth(key, depth) {
  if (depth === void 0) {
    return true;
  }
  let substrCount = 0;
  let index = key.indexOf(":");
  while (index > -1) {
    substrCount++;
    index = key.indexOf(":", index + 1);
  }
  return substrCount <= depth;
}
function filterKeyByBase(key, base) {
  if (base) {
    return key.startsWith(base) && key[key.length - 1] !== "$";
  }
  return key[key.length - 1] !== "$";
}

function defineDriver$1(factory) {
  return factory;
}

const DRIVER_NAME$1 = "memory";
const memory = defineDriver$1(() => {
  const data = /* @__PURE__ */ new Map();
  return {
    name: DRIVER_NAME$1,
    getInstance: () => data,
    hasItem(key) {
      return data.has(key);
    },
    getItem(key) {
      return data.get(key) ?? null;
    },
    getItemRaw(key) {
      return data.get(key) ?? null;
    },
    setItem(key, value) {
      data.set(key, value);
    },
    setItemRaw(key, value) {
      data.set(key, value);
    },
    removeItem(key) {
      data.delete(key);
    },
    getKeys() {
      return [...data.keys()];
    },
    clear() {
      data.clear();
    },
    dispose() {
      data.clear();
    }
  };
});

function createStorage(options = {}) {
  const context = {
    mounts: { "": options.driver || memory() },
    mountpoints: [""],
    watching: false,
    watchListeners: [],
    unwatch: {}
  };
  const getMount = (key) => {
    for (const base of context.mountpoints) {
      if (key.startsWith(base)) {
        return {
          base,
          relativeKey: key.slice(base.length),
          driver: context.mounts[base]
        };
      }
    }
    return {
      base: "",
      relativeKey: key,
      driver: context.mounts[""]
    };
  };
  const getMounts = (base, includeParent) => {
    return context.mountpoints.filter(
      (mountpoint) => mountpoint.startsWith(base) || includeParent && base.startsWith(mountpoint)
    ).map((mountpoint) => ({
      relativeBase: base.length > mountpoint.length ? base.slice(mountpoint.length) : void 0,
      mountpoint,
      driver: context.mounts[mountpoint]
    }));
  };
  const onChange = (event, key) => {
    if (!context.watching) {
      return;
    }
    key = normalizeKey$1(key);
    for (const listener of context.watchListeners) {
      listener(event, key);
    }
  };
  const startWatch = async () => {
    if (context.watching) {
      return;
    }
    context.watching = true;
    for (const mountpoint in context.mounts) {
      context.unwatch[mountpoint] = await watch(
        context.mounts[mountpoint],
        onChange,
        mountpoint
      );
    }
  };
  const stopWatch = async () => {
    if (!context.watching) {
      return;
    }
    for (const mountpoint in context.unwatch) {
      await context.unwatch[mountpoint]();
    }
    context.unwatch = {};
    context.watching = false;
  };
  const runBatch = (items, commonOptions, cb) => {
    const batches = /* @__PURE__ */ new Map();
    const getBatch = (mount) => {
      let batch = batches.get(mount.base);
      if (!batch) {
        batch = {
          driver: mount.driver,
          base: mount.base,
          items: []
        };
        batches.set(mount.base, batch);
      }
      return batch;
    };
    for (const item of items) {
      const isStringItem = typeof item === "string";
      const key = normalizeKey$1(isStringItem ? item : item.key);
      const value = isStringItem ? void 0 : item.value;
      const options2 = isStringItem || !item.options ? commonOptions : { ...commonOptions, ...item.options };
      const mount = getMount(key);
      getBatch(mount).items.push({
        key,
        value,
        relativeKey: mount.relativeKey,
        options: options2
      });
    }
    return Promise.all([...batches.values()].map((batch) => cb(batch))).then(
      (r) => r.flat()
    );
  };
  const storage = {
    // Item
    hasItem(key, opts = {}) {
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      return asyncCall(driver.hasItem, relativeKey, opts);
    },
    getItem(key, opts = {}) {
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      return asyncCall(driver.getItem, relativeKey, opts).then(
        (value) => destr(value)
      );
    },
    getItems(items, commonOptions = {}) {
      return runBatch(items, commonOptions, (batch) => {
        if (batch.driver.getItems) {
          return asyncCall(
            batch.driver.getItems,
            batch.items.map((item) => ({
              key: item.relativeKey,
              options: item.options
            })),
            commonOptions
          ).then(
            (r) => r.map((item) => ({
              key: joinKeys(batch.base, item.key),
              value: destr(item.value)
            }))
          );
        }
        return Promise.all(
          batch.items.map((item) => {
            return asyncCall(
              batch.driver.getItem,
              item.relativeKey,
              item.options
            ).then((value) => ({
              key: item.key,
              value: destr(value)
            }));
          })
        );
      });
    },
    getItemRaw(key, opts = {}) {
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (driver.getItemRaw) {
        return asyncCall(driver.getItemRaw, relativeKey, opts);
      }
      return asyncCall(driver.getItem, relativeKey, opts).then(
        (value) => deserializeRaw(value)
      );
    },
    async setItem(key, value, opts = {}) {
      if (value === void 0) {
        return storage.removeItem(key);
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (!driver.setItem) {
        return;
      }
      await asyncCall(driver.setItem, relativeKey, stringify(value), opts);
      if (!driver.watch) {
        onChange("update", key);
      }
    },
    async setItems(items, commonOptions) {
      await runBatch(items, commonOptions, async (batch) => {
        if (batch.driver.setItems) {
          return asyncCall(
            batch.driver.setItems,
            batch.items.map((item) => ({
              key: item.relativeKey,
              value: stringify(item.value),
              options: item.options
            })),
            commonOptions
          );
        }
        if (!batch.driver.setItem) {
          return;
        }
        await Promise.all(
          batch.items.map((item) => {
            return asyncCall(
              batch.driver.setItem,
              item.relativeKey,
              stringify(item.value),
              item.options
            );
          })
        );
      });
    },
    async setItemRaw(key, value, opts = {}) {
      if (value === void 0) {
        return storage.removeItem(key, opts);
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (driver.setItemRaw) {
        await asyncCall(driver.setItemRaw, relativeKey, value, opts);
      } else if (driver.setItem) {
        await asyncCall(driver.setItem, relativeKey, serializeRaw(value), opts);
      } else {
        return;
      }
      if (!driver.watch) {
        onChange("update", key);
      }
    },
    async removeItem(key, opts = {}) {
      if (typeof opts === "boolean") {
        opts = { removeMeta: opts };
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (!driver.removeItem) {
        return;
      }
      await asyncCall(driver.removeItem, relativeKey, opts);
      if (opts.removeMeta || opts.removeMata) {
        await asyncCall(driver.removeItem, relativeKey + "$", opts);
      }
      if (!driver.watch) {
        onChange("remove", key);
      }
    },
    // Meta
    async getMeta(key, opts = {}) {
      if (typeof opts === "boolean") {
        opts = { nativeOnly: opts };
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      const meta = /* @__PURE__ */ Object.create(null);
      if (driver.getMeta) {
        Object.assign(meta, await asyncCall(driver.getMeta, relativeKey, opts));
      }
      if (!opts.nativeOnly) {
        const value = await asyncCall(
          driver.getItem,
          relativeKey + "$",
          opts
        ).then((value_) => destr(value_));
        if (value && typeof value === "object") {
          if (typeof value.atime === "string") {
            value.atime = new Date(value.atime);
          }
          if (typeof value.mtime === "string") {
            value.mtime = new Date(value.mtime);
          }
          Object.assign(meta, value);
        }
      }
      return meta;
    },
    setMeta(key, value, opts = {}) {
      return this.setItem(key + "$", value, opts);
    },
    removeMeta(key, opts = {}) {
      return this.removeItem(key + "$", opts);
    },
    // Keys
    async getKeys(base, opts = {}) {
      base = normalizeBaseKey(base);
      const mounts = getMounts(base, true);
      let maskedMounts = [];
      const allKeys = [];
      let allMountsSupportMaxDepth = true;
      for (const mount of mounts) {
        if (!mount.driver.flags?.maxDepth) {
          allMountsSupportMaxDepth = false;
        }
        const rawKeys = await asyncCall(
          mount.driver.getKeys,
          mount.relativeBase,
          opts
        );
        for (const key of rawKeys) {
          const fullKey = mount.mountpoint + normalizeKey$1(key);
          if (!maskedMounts.some((p) => fullKey.startsWith(p))) {
            allKeys.push(fullKey);
          }
        }
        maskedMounts = [
          mount.mountpoint,
          ...maskedMounts.filter((p) => !p.startsWith(mount.mountpoint))
        ];
      }
      const shouldFilterByDepth = opts.maxDepth !== void 0 && !allMountsSupportMaxDepth;
      return allKeys.filter(
        (key) => (!shouldFilterByDepth || filterKeyByDepth(key, opts.maxDepth)) && filterKeyByBase(key, base)
      );
    },
    // Utils
    async clear(base, opts = {}) {
      base = normalizeBaseKey(base);
      await Promise.all(
        getMounts(base, false).map(async (m) => {
          if (m.driver.clear) {
            return asyncCall(m.driver.clear, m.relativeBase, opts);
          }
          if (m.driver.removeItem) {
            const keys = await m.driver.getKeys(m.relativeBase || "", opts);
            return Promise.all(
              keys.map((key) => m.driver.removeItem(key, opts))
            );
          }
        })
      );
    },
    async dispose() {
      await Promise.all(
        Object.values(context.mounts).map((driver) => dispose(driver))
      );
    },
    async watch(callback) {
      await startWatch();
      context.watchListeners.push(callback);
      return async () => {
        context.watchListeners = context.watchListeners.filter(
          (listener) => listener !== callback
        );
        if (context.watchListeners.length === 0) {
          await stopWatch();
        }
      };
    },
    async unwatch() {
      context.watchListeners = [];
      await stopWatch();
    },
    // Mount
    mount(base, driver) {
      base = normalizeBaseKey(base);
      if (base && context.mounts[base]) {
        throw new Error(`already mounted at ${base}`);
      }
      if (base) {
        context.mountpoints.push(base);
        context.mountpoints.sort((a, b) => b.length - a.length);
      }
      context.mounts[base] = driver;
      if (context.watching) {
        Promise.resolve(watch(driver, onChange, base)).then((unwatcher) => {
          context.unwatch[base] = unwatcher;
        }).catch(console.error);
      }
      return storage;
    },
    async unmount(base, _dispose = true) {
      base = normalizeBaseKey(base);
      if (!base || !context.mounts[base]) {
        return;
      }
      if (context.watching && base in context.unwatch) {
        context.unwatch[base]?.();
        delete context.unwatch[base];
      }
      if (_dispose) {
        await dispose(context.mounts[base]);
      }
      context.mountpoints = context.mountpoints.filter((key) => key !== base);
      delete context.mounts[base];
    },
    getMount(key = "") {
      key = normalizeKey$1(key) + ":";
      const m = getMount(key);
      return {
        driver: m.driver,
        base: m.base
      };
    },
    getMounts(base = "", opts = {}) {
      base = normalizeKey$1(base);
      const mounts = getMounts(base, opts.parents);
      return mounts.map((m) => ({
        driver: m.driver,
        base: m.mountpoint
      }));
    },
    // Aliases
    keys: (base, opts = {}) => storage.getKeys(base, opts),
    get: (key, opts = {}) => storage.getItem(key, opts),
    set: (key, value, opts = {}) => storage.setItem(key, value, opts),
    has: (key, opts = {}) => storage.hasItem(key, opts),
    del: (key, opts = {}) => storage.removeItem(key, opts),
    remove: (key, opts = {}) => storage.removeItem(key, opts)
  };
  return storage;
}
function watch(driver, onChange, base) {
  return driver.watch ? driver.watch((event, key) => onChange(event, base + key)) : () => {
  };
}
async function dispose(driver) {
  if (typeof driver.dispose === "function") {
    await asyncCall(driver.dispose);
  }
}

const _assets = {

};

const normalizeKey = function normalizeKey(key) {
  if (!key) {
    return "";
  }
  return key.split("?")[0]?.replace(/[/\\]/g, ":").replace(/:+/g, ":").replace(/^:|:$/g, "") || "";
};

const assets$1 = {
  getKeys() {
    return Promise.resolve(Object.keys(_assets))
  },
  hasItem (id) {
    id = normalizeKey(id);
    return Promise.resolve(id in _assets)
  },
  getItem (id) {
    id = normalizeKey(id);
    return Promise.resolve(_assets[id] ? _assets[id].import() : null)
  },
  getMeta (id) {
    id = normalizeKey(id);
    return Promise.resolve(_assets[id] ? _assets[id].meta : {})
  }
};

function defineDriver(factory) {
  return factory;
}
function createError(driver, message, opts) {
  const err = new Error(`[unstorage] [${driver}] ${message}`, opts);
  if (Error.captureStackTrace) {
    Error.captureStackTrace(err, createError);
  }
  return err;
}
function createRequiredError(driver, name) {
  if (Array.isArray(name)) {
    return createError(
      driver,
      `Missing some of the required options ${name.map((n) => "`" + n + "`").join(", ")}`
    );
  }
  return createError(driver, `Missing required option \`${name}\`.`);
}

function ignoreNotfound(err) {
  return err.code === "ENOENT" || err.code === "EISDIR" ? null : err;
}
function ignoreExists(err) {
  return err.code === "EEXIST" ? null : err;
}
async function writeFile(path, data, encoding) {
  await ensuredir(dirname$1(path));
  return promises.writeFile(path, data, encoding);
}
function readFile(path, encoding) {
  return promises.readFile(path, encoding).catch(ignoreNotfound);
}
function unlink(path) {
  return promises.unlink(path).catch(ignoreNotfound);
}
function readdir(dir) {
  return promises.readdir(dir, { withFileTypes: true }).catch(ignoreNotfound).then((r) => r || []);
}
async function ensuredir(dir) {
  if (existsSync(dir)) {
    return;
  }
  await ensuredir(dirname$1(dir)).catch(ignoreExists);
  await promises.mkdir(dir).catch(ignoreExists);
}
async function readdirRecursive(dir, ignore, maxDepth) {
  if (ignore && ignore(dir)) {
    return [];
  }
  const entries = await readdir(dir);
  const files = [];
  await Promise.all(
    entries.map(async (entry) => {
      const entryPath = resolve$1(dir, entry.name);
      if (entry.isDirectory()) {
        if (maxDepth === void 0 || maxDepth > 0) {
          const dirFiles = await readdirRecursive(
            entryPath,
            ignore,
            maxDepth === void 0 ? void 0 : maxDepth - 1
          );
          files.push(...dirFiles.map((f) => entry.name + "/" + f));
        }
      } else {
        if (!(ignore && ignore(entry.name))) {
          files.push(entry.name);
        }
      }
    })
  );
  return files;
}
async function rmRecursive(dir) {
  const entries = await readdir(dir);
  await Promise.all(
    entries.map((entry) => {
      const entryPath = resolve$1(dir, entry.name);
      if (entry.isDirectory()) {
        return rmRecursive(entryPath).then(() => promises.rmdir(entryPath));
      } else {
        return promises.unlink(entryPath);
      }
    })
  );
}

const PATH_TRAVERSE_RE = /\.\.:|\.\.$/;
const DRIVER_NAME = "fs-lite";
const unstorage_47drivers_47fs_45lite = defineDriver((opts = {}) => {
  if (!opts.base) {
    throw createRequiredError(DRIVER_NAME, "base");
  }
  opts.base = resolve$1(opts.base);
  const r = (key) => {
    if (PATH_TRAVERSE_RE.test(key)) {
      throw createError(
        DRIVER_NAME,
        `Invalid key: ${JSON.stringify(key)}. It should not contain .. segments`
      );
    }
    const resolved = join(opts.base, key.replace(/:/g, "/"));
    return resolved;
  };
  return {
    name: DRIVER_NAME,
    options: opts,
    flags: {
      maxDepth: true
    },
    hasItem(key) {
      return existsSync(r(key));
    },
    getItem(key) {
      return readFile(r(key), "utf8");
    },
    getItemRaw(key) {
      return readFile(r(key));
    },
    async getMeta(key) {
      const { atime, mtime, size, birthtime, ctime } = await promises.stat(r(key)).catch(() => ({}));
      return { atime, mtime, size, birthtime, ctime };
    },
    setItem(key, value) {
      if (opts.readOnly) {
        return;
      }
      return writeFile(r(key), value, "utf8");
    },
    setItemRaw(key, value) {
      if (opts.readOnly) {
        return;
      }
      return writeFile(r(key), value);
    },
    removeItem(key) {
      if (opts.readOnly) {
        return;
      }
      return unlink(r(key));
    },
    getKeys(_base, topts) {
      return readdirRecursive(r("."), opts.ignore, topts?.maxDepth);
    },
    async clear() {
      if (opts.readOnly || opts.noClear) {
        return;
      }
      await rmRecursive(r("."));
    }
  };
});

const storage = createStorage({});

storage.mount('/assets', assets$1);

storage.mount('data', unstorage_47drivers_47fs_45lite({"driver":"fsLite","base":"./.data/kv"}));

function useStorage(base = "") {
  return base ? prefixStorage(storage, base) : storage;
}

function serialize$1(o){return typeof o=="string"?`'${o}'`:new c().serialize(o)}const c=/*@__PURE__*/function(){class o{#t=new Map;compare(t,r){const e=typeof t,n=typeof r;return e==="string"&&n==="string"?t.localeCompare(r):e==="number"&&n==="number"?t-r:String.prototype.localeCompare.call(this.serialize(t,true),this.serialize(r,true))}serialize(t,r){if(t===null)return "null";switch(typeof t){case "string":return r?t:`'${t}'`;case "bigint":return `${t}n`;case "object":return this.$object(t);case "function":return this.$function(t)}return String(t)}serializeObject(t){const r=Object.prototype.toString.call(t);if(r!=="[object Object]")return this.serializeBuiltInType(r.length<10?`unknown:${r}`:r.slice(8,-1),t);const e=t.constructor,n=e===Object||e===void 0?"":e.name;if(n!==""&&globalThis[n]===e)return this.serializeBuiltInType(n,t);if(typeof t.toJSON=="function"){const i=t.toJSON();return n+(i!==null&&typeof i=="object"?this.$object(i):`(${this.serialize(i)})`)}return this.serializeObjectEntries(n,Object.entries(t))}serializeBuiltInType(t,r){const e=this["$"+t];if(e)return e.call(this,r);if(typeof r?.entries=="function")return this.serializeObjectEntries(t,r.entries());throw new Error(`Cannot serialize ${t}`)}serializeObjectEntries(t,r){const e=Array.from(r).sort((i,a)=>this.compare(i[0],a[0]));let n=`${t}{`;for(let i=0;i<e.length;i++){const[a,l]=e[i];n+=`${this.serialize(a,true)}:${this.serialize(l)}`,i<e.length-1&&(n+=",");}return n+"}"}$object(t){let r=this.#t.get(t);return r===void 0&&(this.#t.set(t,`#${this.#t.size}`),r=this.serializeObject(t),this.#t.set(t,r)),r}$function(t){const r=Function.prototype.toString.call(t);return r.slice(-15)==="[native code] }"?`${t.name||""}()[native]`:`${t.name}(${t.length})${r.replace(/\s*\n\s*/g,"")}`}$Array(t){let r="[";for(let e=0;e<t.length;e++)r+=this.serialize(t[e]),e<t.length-1&&(r+=",");return r+"]"}$Date(t){try{return `Date(${t.toISOString()})`}catch{return "Date(null)"}}$ArrayBuffer(t){return `ArrayBuffer[${new Uint8Array(t).join(",")}]`}$Set(t){return `Set${this.$Array(Array.from(t).sort((r,e)=>this.compare(r,e)))}`}$Map(t){return this.serializeObjectEntries("Map",t.entries())}}for(const s of ["Error","RegExp","URL"])o.prototype["$"+s]=function(t){return `${s}(${t})`};for(const s of ["Int8Array","Uint8Array","Uint8ClampedArray","Int16Array","Uint16Array","Int32Array","Uint32Array","Float32Array","Float64Array"])o.prototype["$"+s]=function(t){return `${s}[${t.join(",")}]`};for(const s of ["BigInt64Array","BigUint64Array"])o.prototype["$"+s]=function(t){return `${s}[${t.join("n,")}${t.length>0?"n":""}]`};return o}();

function isEqual(object1, object2) {
  if (object1 === object2) {
    return true;
  }
  if (serialize$1(object1) === serialize$1(object2)) {
    return true;
  }
  return false;
}

const e=globalThis.process?.getBuiltinModule?.("crypto")?.hash,r="sha256",s="base64url";function digest(t){if(e)return e(r,t,s);const o=createHash(r).update(t);return globalThis.process?.versions?.webcontainer?o.digest().toString(s):o.digest(s)}

function hash$1(input) {
  return digest(serialize$1(input));
}

const Hasher = /* @__PURE__ */ (() => {
  class Hasher2 {
    buff = "";
    #context = /* @__PURE__ */ new Map();
    write(str) {
      this.buff += str;
    }
    dispatch(value) {
      const type = value === null ? "null" : typeof value;
      return this[type](value);
    }
    object(object) {
      if (object && typeof object.toJSON === "function") {
        return this.object(object.toJSON());
      }
      const objString = Object.prototype.toString.call(object);
      let objType = "";
      const objectLength = objString.length;
      objType = objectLength < 10 ? "unknown:[" + objString + "]" : objString.slice(8, objectLength - 1);
      objType = objType.toLowerCase();
      let objectNumber = null;
      if ((objectNumber = this.#context.get(object)) === void 0) {
        this.#context.set(object, this.#context.size);
      } else {
        return this.dispatch("[CIRCULAR:" + objectNumber + "]");
      }
      if (typeof Buffer !== "undefined" && Buffer.isBuffer && Buffer.isBuffer(object)) {
        this.write("buffer:");
        return this.write(object.toString("utf8"));
      }
      if (objType !== "object" && objType !== "function" && objType !== "asyncfunction") {
        if (this[objType]) {
          this[objType](object);
        } else {
          this.unknown(object, objType);
        }
      } else {
        const keys = Object.keys(object).sort();
        const extraKeys = [];
        this.write("object:" + (keys.length + extraKeys.length) + ":");
        const dispatchForKey = (key) => {
          this.dispatch(key);
          this.write(":");
          this.dispatch(object[key]);
          this.write(",");
        };
        for (const key of keys) {
          dispatchForKey(key);
        }
        for (const key of extraKeys) {
          dispatchForKey(key);
        }
      }
    }
    array(arr, unordered) {
      unordered = unordered === void 0 ? false : unordered;
      this.write("array:" + arr.length + ":");
      if (!unordered || arr.length <= 1) {
        for (const entry of arr) {
          this.dispatch(entry);
        }
        return;
      }
      const contextAdditions = /* @__PURE__ */ new Map();
      const entries = arr.map((entry) => {
        const hasher = new Hasher2();
        hasher.dispatch(entry);
        for (const [key, value] of hasher.#context) {
          contextAdditions.set(key, value);
        }
        return hasher.toString();
      });
      this.#context = contextAdditions;
      entries.sort();
      return this.array(entries, false);
    }
    date(date) {
      return this.write("date:" + date.toJSON());
    }
    symbol(sym) {
      return this.write("symbol:" + sym.toString());
    }
    unknown(value, type) {
      this.write(type);
      if (!value) {
        return;
      }
      this.write(":");
      if (value && typeof value.entries === "function") {
        return this.array(
          [...value.entries()],
          true
          /* ordered */
        );
      }
    }
    error(err) {
      return this.write("error:" + err.toString());
    }
    boolean(bool) {
      return this.write("bool:" + bool);
    }
    string(string) {
      this.write("string:" + string.length + ":");
      this.write(string);
    }
    function(fn) {
      this.write("fn:");
      if (isNativeFunction(fn)) {
        this.dispatch("[native]");
      } else {
        this.dispatch(fn.toString());
      }
    }
    number(number) {
      return this.write("number:" + number);
    }
    null() {
      return this.write("Null");
    }
    undefined() {
      return this.write("Undefined");
    }
    regexp(regex) {
      return this.write("regex:" + regex.toString());
    }
    arraybuffer(arr) {
      this.write("arraybuffer:");
      return this.dispatch(new Uint8Array(arr));
    }
    url(url) {
      return this.write("url:" + url.toString());
    }
    map(map) {
      this.write("map:");
      const arr = [...map];
      return this.array(arr, false);
    }
    set(set) {
      this.write("set:");
      const arr = [...set];
      return this.array(arr, false);
    }
    bigint(number) {
      return this.write("bigint:" + number.toString());
    }
  }
  for (const type of [
    "uint8array",
    "uint8clampedarray",
    "unt8array",
    "uint16array",
    "unt16array",
    "uint32array",
    "unt32array",
    "float32array",
    "float64array"
  ]) {
    Hasher2.prototype[type] = function(arr) {
      this.write(type + ":");
      return this.array([...arr], false);
    };
  }
  function isNativeFunction(f) {
    if (typeof f !== "function") {
      return false;
    }
    return Function.prototype.toString.call(f).slice(
      -15
      /* "[native code] }".length */
    ) === "[native code] }";
  }
  return Hasher2;
})();
function serialize(object) {
  const hasher = new Hasher();
  hasher.dispatch(object);
  return hasher.buff;
}
function hash(value) {
  return digest(typeof value === "string" ? value : serialize(value)).replace(/[-_]/g, "").slice(0, 10);
}

function defaultCacheOptions() {
  return {
    name: "_",
    base: "/cache",
    swr: true,
    maxAge: 1
  };
}
function defineCachedFunction(fn, opts = {}) {
  opts = { ...defaultCacheOptions(), ...opts };
  const pending = {};
  const group = opts.group || "nitro/functions";
  const name = opts.name || fn.name || "_";
  const integrity = opts.integrity || hash([fn, opts]);
  const validate = opts.validate || ((entry) => entry.value !== void 0);
  async function get(key, resolver, shouldInvalidateCache, event) {
    const cacheKey = [opts.base, group, name, key + ".json"].filter(Boolean).join(":").replace(/:\/$/, ":index");
    let entry = await useStorage().getItem(cacheKey).catch((error) => {
      console.error(`[cache] Cache read error.`, error);
      useNitroApp().captureError(error, { event, tags: ["cache"] });
    }) || {};
    if (typeof entry !== "object") {
      entry = {};
      const error = new Error("Malformed data read from cache.");
      console.error("[cache]", error);
      useNitroApp().captureError(error, { event, tags: ["cache"] });
    }
    const ttl = (opts.maxAge ?? 0) * 1e3;
    if (ttl) {
      entry.expires = Date.now() + ttl;
    }
    const expired = shouldInvalidateCache || entry.integrity !== integrity || ttl && Date.now() - (entry.mtime || 0) > ttl || validate(entry) === false;
    const _resolve = async () => {
      const isPending = pending[key];
      if (!isPending) {
        if (entry.value !== void 0 && (opts.staleMaxAge || 0) >= 0 && opts.swr === false) {
          entry.value = void 0;
          entry.integrity = void 0;
          entry.mtime = void 0;
          entry.expires = void 0;
        }
        pending[key] = Promise.resolve(resolver());
      }
      try {
        entry.value = await pending[key];
      } catch (error) {
        if (!isPending) {
          delete pending[key];
        }
        throw error;
      }
      if (!isPending) {
        entry.mtime = Date.now();
        entry.integrity = integrity;
        delete pending[key];
        if (validate(entry) !== false) {
          let setOpts;
          if (opts.maxAge && !opts.swr) {
            setOpts = { ttl: opts.maxAge };
          }
          const promise = useStorage().setItem(cacheKey, entry, setOpts).catch((error) => {
            console.error(`[cache] Cache write error.`, error);
            useNitroApp().captureError(error, { event, tags: ["cache"] });
          });
          if (event?.waitUntil) {
            event.waitUntil(promise);
          }
        }
      }
    };
    const _resolvePromise = expired ? _resolve() : Promise.resolve();
    if (entry.value === void 0) {
      await _resolvePromise;
    } else if (expired && event && event.waitUntil) {
      event.waitUntil(_resolvePromise);
    }
    if (opts.swr && validate(entry) !== false) {
      _resolvePromise.catch((error) => {
        console.error(`[cache] SWR handler error.`, error);
        useNitroApp().captureError(error, { event, tags: ["cache"] });
      });
      return entry;
    }
    return _resolvePromise.then(() => entry);
  }
  return async (...args) => {
    const shouldBypassCache = await opts.shouldBypassCache?.(...args);
    if (shouldBypassCache) {
      return fn(...args);
    }
    const key = await (opts.getKey || getKey)(...args);
    const shouldInvalidateCache = await opts.shouldInvalidateCache?.(...args);
    const entry = await get(
      key,
      () => fn(...args),
      shouldInvalidateCache,
      args[0] && isEvent(args[0]) ? args[0] : void 0
    );
    let value = entry.value;
    if (opts.transform) {
      value = await opts.transform(entry, ...args) || value;
    }
    return value;
  };
}
function cachedFunction(fn, opts = {}) {
  return defineCachedFunction(fn, opts);
}
function getKey(...args) {
  return args.length > 0 ? hash(args) : "";
}
function escapeKey(key) {
  return String(key).replace(/\W/g, "");
}
function defineCachedEventHandler(handler, opts = defaultCacheOptions()) {
  const variableHeaderNames = (opts.varies || []).filter(Boolean).map((h) => h.toLowerCase()).sort();
  const _opts = {
    ...opts,
    getKey: async (event) => {
      const customKey = await opts.getKey?.(event);
      if (customKey) {
        return escapeKey(customKey);
      }
      const _path = event.node.req.originalUrl || event.node.req.url || event.path;
      let _pathname;
      try {
        _pathname = escapeKey(decodeURI(parseURL(_path).pathname)).slice(0, 16) || "index";
      } catch {
        _pathname = "-";
      }
      const _hashedPath = `${_pathname}.${hash(_path)}`;
      const _headers = variableHeaderNames.map((header) => [header, event.node.req.headers[header]]).map(([name, value]) => `${escapeKey(name)}.${hash(value)}`);
      return [_hashedPath, ..._headers].join(":");
    },
    validate: (entry) => {
      if (!entry.value) {
        return false;
      }
      if (entry.value.code >= 400) {
        return false;
      }
      if (entry.value.body === void 0) {
        return false;
      }
      if (entry.value.headers.etag === "undefined" || entry.value.headers["last-modified"] === "undefined") {
        return false;
      }
      return true;
    },
    group: opts.group || "nitro/handlers",
    integrity: opts.integrity || hash([handler, opts])
  };
  const _cachedHandler = cachedFunction(
    async (incomingEvent) => {
      const variableHeaders = {};
      for (const header of variableHeaderNames) {
        const value = incomingEvent.node.req.headers[header];
        if (value !== void 0) {
          variableHeaders[header] = value;
        }
      }
      const reqProxy = cloneWithProxy(incomingEvent.node.req, {
        headers: variableHeaders
      });
      const resHeaders = {};
      let _resSendBody;
      const resProxy = cloneWithProxy(incomingEvent.node.res, {
        statusCode: 200,
        writableEnded: false,
        writableFinished: false,
        headersSent: false,
        closed: false,
        getHeader(name) {
          return resHeaders[name];
        },
        setHeader(name, value) {
          resHeaders[name] = value;
          return this;
        },
        getHeaderNames() {
          return Object.keys(resHeaders);
        },
        hasHeader(name) {
          return name in resHeaders;
        },
        removeHeader(name) {
          delete resHeaders[name];
        },
        getHeaders() {
          return resHeaders;
        },
        end(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2();
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return this;
        },
        write(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2(void 0);
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return true;
        },
        writeHead(statusCode, headers2) {
          this.statusCode = statusCode;
          if (headers2) {
            if (Array.isArray(headers2) || typeof headers2 === "string") {
              throw new TypeError("Raw headers  is not supported.");
            }
            for (const header in headers2) {
              const value = headers2[header];
              if (value !== void 0) {
                this.setHeader(
                  header,
                  value
                );
              }
            }
          }
          return this;
        }
      });
      const event = createEvent(reqProxy, resProxy);
      event.fetch = (url, fetchOptions) => fetchWithEvent(event, url, fetchOptions, {
        fetch: useNitroApp().localFetch
      });
      event.$fetch = (url, fetchOptions) => fetchWithEvent(event, url, fetchOptions, {
        fetch: globalThis.$fetch
      });
      event.waitUntil = incomingEvent.waitUntil;
      event.context = incomingEvent.context;
      event.context.cache = {
        options: _opts
      };
      const body = await handler(event) || _resSendBody;
      const headers = event.node.res.getHeaders();
      headers.etag = String(
        headers.Etag || headers.etag || `W/"${hash(body)}"`
      );
      headers["last-modified"] = String(
        headers["Last-Modified"] || headers["last-modified"] || (/* @__PURE__ */ new Date()).toUTCString()
      );
      const cacheControl = [];
      if (opts.swr) {
        if (opts.maxAge) {
          cacheControl.push(`s-maxage=${opts.maxAge}`);
        }
        if (opts.staleMaxAge) {
          cacheControl.push(`stale-while-revalidate=${opts.staleMaxAge}`);
        } else {
          cacheControl.push("stale-while-revalidate");
        }
      } else if (opts.maxAge) {
        cacheControl.push(`max-age=${opts.maxAge}`);
      }
      if (cacheControl.length > 0) {
        headers["cache-control"] = cacheControl.join(", ");
      }
      const cacheEntry = {
        code: event.node.res.statusCode,
        headers,
        body
      };
      return cacheEntry;
    },
    _opts
  );
  return defineEventHandler(async (event) => {
    if (opts.headersOnly) {
      if (handleCacheHeaders(event, { maxAge: opts.maxAge })) {
        return;
      }
      return handler(event);
    }
    const response = await _cachedHandler(
      event
    );
    if (event.node.res.headersSent || event.node.res.writableEnded) {
      return response.body;
    }
    if (handleCacheHeaders(event, {
      modifiedTime: new Date(response.headers["last-modified"]),
      etag: response.headers.etag,
      maxAge: opts.maxAge
    })) {
      return;
    }
    event.node.res.statusCode = response.code;
    for (const name in response.headers) {
      const value = response.headers[name];
      if (name === "set-cookie") {
        event.node.res.appendHeader(
          name,
          splitCookiesString(value)
        );
      } else {
        if (value !== void 0) {
          event.node.res.setHeader(name, value);
        }
      }
    }
    return response.body;
  });
}
function cloneWithProxy(obj, overrides) {
  return new Proxy(obj, {
    get(target, property, receiver) {
      if (property in overrides) {
        return overrides[property];
      }
      return Reflect.get(target, property, receiver);
    },
    set(target, property, value, receiver) {
      if (property in overrides) {
        overrides[property] = value;
        return true;
      }
      return Reflect.set(target, property, value, receiver);
    }
  });
}
const cachedEventHandler = defineCachedEventHandler;

function klona(x) {
	if (typeof x !== 'object') return x;

	var k, tmp, str=Object.prototype.toString.call(x);

	if (str === '[object Object]') {
		if (x.constructor !== Object && typeof x.constructor === 'function') {
			tmp = new x.constructor();
			for (k in x) {
				if (x.hasOwnProperty(k) && tmp[k] !== x[k]) {
					tmp[k] = klona(x[k]);
				}
			}
		} else {
			tmp = {}; // null
			for (k in x) {
				if (k === '__proto__') {
					Object.defineProperty(tmp, k, {
						value: klona(x[k]),
						configurable: true,
						enumerable: true,
						writable: true,
					});
				} else {
					tmp[k] = klona(x[k]);
				}
			}
		}
		return tmp;
	}

	if (str === '[object Array]') {
		k = x.length;
		for (tmp=Array(k); k--;) {
			tmp[k] = klona(x[k]);
		}
		return tmp;
	}

	if (str === '[object Set]') {
		tmp = new Set;
		x.forEach(function (val) {
			tmp.add(klona(val));
		});
		return tmp;
	}

	if (str === '[object Map]') {
		tmp = new Map;
		x.forEach(function (val, key) {
			tmp.set(klona(key), klona(val));
		});
		return tmp;
	}

	if (str === '[object Date]') {
		return new Date(+x);
	}

	if (str === '[object RegExp]') {
		tmp = new RegExp(x.source, x.flags);
		tmp.lastIndex = x.lastIndex;
		return tmp;
	}

	if (str === '[object DataView]') {
		return new x.constructor( klona(x.buffer) );
	}

	if (str === '[object ArrayBuffer]') {
		return x.slice(0);
	}

	// ArrayBuffer.isView(x)
	// ~> `new` bcuz `Buffer.slice` => ref
	if (str.slice(-6) === 'Array]') {
		return new x.constructor(x);
	}

	return x;
}

const inlineAppConfig = {
  "nuxt": {},
  "ui": {
    "colors": {
      "primary": "green",
      "secondary": "blue",
      "success": "green",
      "info": "blue",
      "warning": "yellow",
      "error": "red",
      "neutral": "slate"
    },
    "icons": {
      "arrowDown": "i-lucide-arrow-down",
      "arrowLeft": "i-lucide-arrow-left",
      "arrowRight": "i-lucide-arrow-right",
      "arrowUp": "i-lucide-arrow-up",
      "caution": "i-lucide-circle-alert",
      "check": "i-lucide-check",
      "chevronDoubleLeft": "i-lucide-chevrons-left",
      "chevronDoubleRight": "i-lucide-chevrons-right",
      "chevronDown": "i-lucide-chevron-down",
      "chevronLeft": "i-lucide-chevron-left",
      "chevronRight": "i-lucide-chevron-right",
      "chevronUp": "i-lucide-chevron-up",
      "close": "i-lucide-x",
      "copy": "i-lucide-copy",
      "copyCheck": "i-lucide-copy-check",
      "dark": "i-lucide-moon",
      "drag": "i-lucide-grip-vertical",
      "ellipsis": "i-lucide-ellipsis",
      "error": "i-lucide-circle-x",
      "external": "i-lucide-arrow-up-right",
      "eye": "i-lucide-eye",
      "eyeOff": "i-lucide-eye-off",
      "file": "i-lucide-file",
      "folder": "i-lucide-folder",
      "folderOpen": "i-lucide-folder-open",
      "hash": "i-lucide-hash",
      "info": "i-lucide-info",
      "light": "i-lucide-sun",
      "loading": "i-lucide-loader-circle",
      "menu": "i-lucide-menu",
      "minus": "i-lucide-minus",
      "panelClose": "i-lucide-panel-left-close",
      "panelOpen": "i-lucide-panel-left-open",
      "plus": "i-lucide-plus",
      "reload": "i-lucide-rotate-ccw",
      "search": "i-lucide-search",
      "stop": "i-lucide-square",
      "success": "i-lucide-circle-check",
      "system": "i-lucide-monitor",
      "tip": "i-lucide-lightbulb",
      "upload": "i-lucide-upload",
      "warning": "i-lucide-triangle-alert"
    },
    "tv": {
      "twMergeConfig": {}
    }
  },
  "icon": {
    "provider": "server",
    "class": "",
    "aliases": {},
    "iconifyApiEndpoint": "https://api.iconify.design",
    "localApiEndpoint": "/api/_nuxt_icon",
    "fallbackToApi": true,
    "cssSelectorPrefix": "i-",
    "cssWherePseudo": true,
    "cssLayer": "base",
    "mode": "css",
    "attrs": {
      "aria-hidden": true
    },
    "collections": [
      "academicons",
      "akar-icons",
      "ant-design",
      "arcticons",
      "basil",
      "bi",
      "bitcoin-icons",
      "bpmn",
      "brandico",
      "bx",
      "bxl",
      "bxs",
      "bytesize",
      "carbon",
      "catppuccin",
      "cbi",
      "charm",
      "ci",
      "cib",
      "cif",
      "cil",
      "circle-flags",
      "circum",
      "clarity",
      "codex",
      "codicon",
      "covid",
      "cryptocurrency",
      "cryptocurrency-color",
      "cuida",
      "dashicons",
      "devicon",
      "devicon-plain",
      "dinkie-icons",
      "duo-icons",
      "ei",
      "el",
      "emojione",
      "emojione-monotone",
      "emojione-v1",
      "entypo",
      "entypo-social",
      "eos-icons",
      "ep",
      "et",
      "eva",
      "f7",
      "fa",
      "fa-brands",
      "fa-regular",
      "fa-solid",
      "fa6-brands",
      "fa6-regular",
      "fa6-solid",
      "fa7-brands",
      "fa7-regular",
      "fa7-solid",
      "fad",
      "famicons",
      "fe",
      "feather",
      "file-icons",
      "flag",
      "flagpack",
      "flat-color-icons",
      "flat-ui",
      "flowbite",
      "fluent",
      "fluent-color",
      "fluent-emoji",
      "fluent-emoji-flat",
      "fluent-emoji-high-contrast",
      "fluent-mdl2",
      "fontelico",
      "fontisto",
      "formkit",
      "foundation",
      "fxemoji",
      "gala",
      "game-icons",
      "garden",
      "geo",
      "gg",
      "gis",
      "gravity-ui",
      "gridicons",
      "grommet-icons",
      "guidance",
      "healthicons",
      "heroicons",
      "heroicons-outline",
      "heroicons-solid",
      "hugeicons",
      "humbleicons",
      "ic",
      "icomoon-free",
      "icon-park",
      "icon-park-outline",
      "icon-park-solid",
      "icon-park-twotone",
      "iconamoon",
      "iconoir",
      "icons8",
      "il",
      "ion",
      "iwwa",
      "ix",
      "jam",
      "la",
      "lets-icons",
      "line-md",
      "lineicons",
      "logos",
      "ls",
      "lsicon",
      "lucide",
      "lucide-lab",
      "mage",
      "majesticons",
      "maki",
      "map",
      "marketeq",
      "material-icon-theme",
      "material-symbols",
      "material-symbols-light",
      "mdi",
      "mdi-light",
      "medical-icon",
      "memory",
      "meteocons",
      "meteor-icons",
      "mi",
      "mingcute",
      "mono-icons",
      "mynaui",
      "nimbus",
      "nonicons",
      "noto",
      "noto-v1",
      "nrk",
      "octicon",
      "oi",
      "ooui",
      "openmoji",
      "oui",
      "pajamas",
      "pepicons",
      "pepicons-pencil",
      "pepicons-pop",
      "pepicons-print",
      "ph",
      "picon",
      "pixel",
      "pixelarticons",
      "prime",
      "proicons",
      "ps",
      "qlementine-icons",
      "quill",
      "radix-icons",
      "raphael",
      "ri",
      "rivet-icons",
      "roentgen",
      "si",
      "si-glyph",
      "sidekickicons",
      "simple-icons",
      "simple-line-icons",
      "skill-icons",
      "solar",
      "stash",
      "streamline",
      "streamline-block",
      "streamline-color",
      "streamline-cyber",
      "streamline-cyber-color",
      "streamline-emojis",
      "streamline-flex",
      "streamline-flex-color",
      "streamline-freehand",
      "streamline-freehand-color",
      "streamline-kameleon-color",
      "streamline-logos",
      "streamline-pixel",
      "streamline-plump",
      "streamline-plump-color",
      "streamline-sharp",
      "streamline-sharp-color",
      "streamline-stickies-color",
      "streamline-ultimate",
      "streamline-ultimate-color",
      "subway",
      "svg-spinners",
      "system-uicons",
      "tabler",
      "tdesign",
      "teenyicons",
      "temaki",
      "token",
      "token-branded",
      "topcoat",
      "twemoji",
      "typcn",
      "uil",
      "uim",
      "uis",
      "uit",
      "uiw",
      "unjs",
      "vaadin",
      "vs",
      "vscode-icons",
      "websymbol",
      "weui",
      "whh",
      "wi",
      "wpf",
      "zmdi",
      "zondicons"
    ],
    "fetchTimeout": 1500
  }
};



const appConfig = defuFn(inlineAppConfig);

const NUMBER_CHAR_RE = /\d/;
const STR_SPLITTERS = ["-", "_", "/", "."];
function isUppercase(char = "") {
  if (NUMBER_CHAR_RE.test(char)) {
    return void 0;
  }
  return char !== char.toLowerCase();
}
function splitByCase(str, separators) {
  const splitters = STR_SPLITTERS;
  const parts = [];
  if (!str || typeof str !== "string") {
    return parts;
  }
  let buff = "";
  let previousUpper;
  let previousSplitter;
  for (const char of str) {
    const isSplitter = splitters.includes(char);
    if (isSplitter === true) {
      parts.push(buff);
      buff = "";
      previousUpper = void 0;
      continue;
    }
    const isUpper = isUppercase(char);
    if (previousSplitter === false) {
      if (previousUpper === false && isUpper === true) {
        parts.push(buff);
        buff = char;
        previousUpper = isUpper;
        continue;
      }
      if (previousUpper === true && isUpper === false && buff.length > 1) {
        const lastChar = buff.at(-1);
        parts.push(buff.slice(0, Math.max(0, buff.length - 1)));
        buff = lastChar + char;
        previousUpper = isUpper;
        continue;
      }
    }
    buff += char;
    previousUpper = isUpper;
    previousSplitter = isSplitter;
  }
  parts.push(buff);
  return parts;
}
function upperFirst(str) {
  return str ? str[0].toUpperCase() + str.slice(1) : "";
}
function kebabCase(str, joiner) {
  return str ? (Array.isArray(str) ? str : splitByCase(str)).map((p) => p.toLowerCase()).join(joiner) : "";
}
function snakeCase(str) {
  return kebabCase(str || "", "_");
}

function getEnv(key, opts) {
  const envKey = snakeCase(key).toUpperCase();
  return destr(
    process.env[opts.prefix + envKey] ?? process.env[opts.altPrefix + envKey]
  );
}
function _isObject(input) {
  return typeof input === "object" && !Array.isArray(input);
}
function applyEnv(obj, opts, parentKey = "") {
  for (const key in obj) {
    const subKey = parentKey ? `${parentKey}_${key}` : key;
    const envValue = getEnv(subKey, opts);
    if (_isObject(obj[key])) {
      if (_isObject(envValue)) {
        obj[key] = { ...obj[key], ...envValue };
        applyEnv(obj[key], opts, subKey);
      } else if (envValue === void 0) {
        applyEnv(obj[key], opts, subKey);
      } else {
        obj[key] = envValue ?? obj[key];
      }
    } else {
      obj[key] = envValue ?? obj[key];
    }
    if (opts.envExpansion && typeof obj[key] === "string") {
      obj[key] = _expandFromEnv(obj[key]);
    }
  }
  return obj;
}
const envExpandRx = /\{\{([^{}]*)\}\}/g;
function _expandFromEnv(value) {
  return value.replace(envExpandRx, (match, key) => {
    return process.env[key] || match;
  });
}

const _inlineRuntimeConfig = {
  "app": {
    "baseURL": "/",
    "buildId": "657bbfe8-f58c-4e57-9e3c-404d4f80083f",
    "buildAssetsDir": "/_nuxt/",
    "cdnURL": ""
  },
  "nitro": {
    "envPrefix": "NUXT_",
    "routeRules": {
      "/__nuxt_error": {
        "cache": false
      },
      "/_nuxt/builds/meta/**": {
        "headers": {
          "cache-control": "public, max-age=31536000, immutable"
        }
      },
      "/_nuxt/builds/**": {
        "headers": {
          "cache-control": "public, max-age=1, immutable"
        }
      },
      "/_fonts/**": {
        "headers": {
          "cache-control": "public, max-age=31536000, immutable"
        }
      },
      "/_nuxt/**": {
        "headers": {
          "cache-control": "public, max-age=31536000, immutable"
        }
      }
    }
  },
  "public": {
    "pbxApiBase": "/api/pbx"
  },
  "licenseApiUrl": "https://license.softphone.plus",
  "icon": {
    "serverKnownCssClasses": []
  }
};
const envOptions = {
  prefix: "NITRO_",
  altPrefix: _inlineRuntimeConfig.nitro.envPrefix ?? process.env.NITRO_ENV_PREFIX ?? "_",
  envExpansion: _inlineRuntimeConfig.nitro.envExpansion ?? process.env.NITRO_ENV_EXPANSION ?? false
};
const _sharedRuntimeConfig = _deepFreeze(
  applyEnv(klona(_inlineRuntimeConfig), envOptions)
);
function useRuntimeConfig(event) {
  if (!event) {
    return _sharedRuntimeConfig;
  }
  if (event.context.nitro.runtimeConfig) {
    return event.context.nitro.runtimeConfig;
  }
  const runtimeConfig = klona(_inlineRuntimeConfig);
  applyEnv(runtimeConfig, envOptions);
  event.context.nitro.runtimeConfig = runtimeConfig;
  return runtimeConfig;
}
const _sharedAppConfig = _deepFreeze(klona(appConfig));
function useAppConfig(event) {
  {
    return _sharedAppConfig;
  }
}
function _deepFreeze(object) {
  const propNames = Object.getOwnPropertyNames(object);
  for (const name of propNames) {
    const value = object[name];
    if (value && typeof value === "object") {
      _deepFreeze(value);
    }
  }
  return Object.freeze(object);
}
new Proxy(/* @__PURE__ */ Object.create(null), {
  get: (_, prop) => {
    console.warn(
      "Please use `useRuntimeConfig()` instead of accessing config directly."
    );
    const runtimeConfig = useRuntimeConfig();
    if (prop in runtimeConfig) {
      return runtimeConfig[prop];
    }
    return void 0;
  }
});

function createContext(opts = {}) {
  let currentInstance;
  let isSingleton = false;
  const checkConflict = (instance) => {
    if (currentInstance && currentInstance !== instance) {
      throw new Error("Context conflict");
    }
  };
  let als;
  if (opts.asyncContext) {
    const _AsyncLocalStorage = opts.AsyncLocalStorage || globalThis.AsyncLocalStorage;
    if (_AsyncLocalStorage) {
      als = new _AsyncLocalStorage();
    } else {
      console.warn("[unctx] `AsyncLocalStorage` is not provided.");
    }
  }
  const _getCurrentInstance = () => {
    if (als) {
      const instance = als.getStore();
      if (instance !== void 0) {
        return instance;
      }
    }
    return currentInstance;
  };
  return {
    use: () => {
      const _instance = _getCurrentInstance();
      if (_instance === void 0) {
        throw new Error("Context is not available");
      }
      return _instance;
    },
    tryUse: () => {
      return _getCurrentInstance();
    },
    set: (instance, replace) => {
      if (!replace) {
        checkConflict(instance);
      }
      currentInstance = instance;
      isSingleton = true;
    },
    unset: () => {
      currentInstance = void 0;
      isSingleton = false;
    },
    call: (instance, callback) => {
      checkConflict(instance);
      currentInstance = instance;
      try {
        return als ? als.run(instance, callback) : callback();
      } finally {
        if (!isSingleton) {
          currentInstance = void 0;
        }
      }
    },
    async callAsync(instance, callback) {
      currentInstance = instance;
      const onRestore = () => {
        currentInstance = instance;
      };
      const onLeave = () => currentInstance === instance ? onRestore : void 0;
      asyncHandlers.add(onLeave);
      try {
        const r = als ? als.run(instance, callback) : callback();
        if (!isSingleton) {
          currentInstance = void 0;
        }
        return await r;
      } finally {
        asyncHandlers.delete(onLeave);
      }
    }
  };
}
function createNamespace(defaultOpts = {}) {
  const contexts = {};
  return {
    get(key, opts = {}) {
      if (!contexts[key]) {
        contexts[key] = createContext({ ...defaultOpts, ...opts });
      }
      return contexts[key];
    }
  };
}
const _globalThis = typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : typeof global !== "undefined" ? global : {};
const globalKey = "__unctx__";
const defaultNamespace = _globalThis[globalKey] || (_globalThis[globalKey] = createNamespace());
const getContext = (key, opts = {}) => defaultNamespace.get(key, opts);
const asyncHandlersKey = "__unctx_async_handlers__";
const asyncHandlers = _globalThis[asyncHandlersKey] || (_globalThis[asyncHandlersKey] = /* @__PURE__ */ new Set());
function executeAsync(function_) {
  const restores = [];
  for (const leaveHandler of asyncHandlers) {
    const restore2 = leaveHandler();
    if (restore2) {
      restores.push(restore2);
    }
  }
  const restore = () => {
    for (const restore2 of restores) {
      restore2();
    }
  };
  let awaitable = function_();
  if (awaitable && typeof awaitable === "object" && "catch" in awaitable) {
    awaitable = awaitable.catch((error) => {
      restore();
      throw error;
    });
  }
  return [awaitable, restore];
}

getContext("nitro-app", {
  asyncContext: false,
  AsyncLocalStorage: void 0
});

const config = useRuntimeConfig();
const _routeRulesMatcher = toRouteMatcher(
  createRouter$1({ routes: config.nitro.routeRules })
);
function createRouteRulesHandler(ctx) {
  return eventHandler((event) => {
    const routeRules = getRouteRules(event);
    if (routeRules.headers) {
      setHeaders(event, routeRules.headers);
    }
    if (routeRules.redirect) {
      let target = routeRules.redirect.to;
      if (target.endsWith("/**")) {
        let targetPath = event.path;
        const strpBase = routeRules.redirect._redirectStripBase;
        if (strpBase) {
          targetPath = withoutBase(targetPath, strpBase);
        }
        target = joinURL(target.slice(0, -3), targetPath);
      } else if (event.path.includes("?")) {
        const query = getQuery$1(event.path);
        target = withQuery(target, query);
      }
      return sendRedirect(event, target, routeRules.redirect.statusCode);
    }
    if (routeRules.proxy) {
      let target = routeRules.proxy.to;
      if (target.endsWith("/**")) {
        let targetPath = event.path;
        const strpBase = routeRules.proxy._proxyStripBase;
        if (strpBase) {
          targetPath = withoutBase(targetPath, strpBase);
        }
        target = joinURL(target.slice(0, -3), targetPath);
      } else if (event.path.includes("?")) {
        const query = getQuery$1(event.path);
        target = withQuery(target, query);
      }
      return proxyRequest(event, target, {
        fetch: ctx.localFetch,
        ...routeRules.proxy
      });
    }
  });
}
function getRouteRules(event) {
  event.context._nitro = event.context._nitro || {};
  if (!event.context._nitro.routeRules) {
    event.context._nitro.routeRules = getRouteRulesForPath(
      withoutBase(event.path.split("?")[0], useRuntimeConfig().app.baseURL)
    );
  }
  return event.context._nitro.routeRules;
}
function getRouteRulesForPath(path) {
  return defu({}, ..._routeRulesMatcher.matchAll(path).reverse());
}

function _captureError(error, type) {
  console.error(`[${type}]`, error);
  useNitroApp().captureError(error, { tags: [type] });
}
function trapUnhandledNodeErrors() {
  process.on(
    "unhandledRejection",
    (error) => _captureError(error, "unhandledRejection")
  );
  process.on(
    "uncaughtException",
    (error) => _captureError(error, "uncaughtException")
  );
}
function joinHeaders(value) {
  return Array.isArray(value) ? value.join(", ") : String(value);
}
function normalizeFetchResponse(response) {
  if (!response.headers.has("set-cookie")) {
    return response;
  }
  return new Response(response.body, {
    status: response.status,
    statusText: response.statusText,
    headers: normalizeCookieHeaders(response.headers)
  });
}
function normalizeCookieHeader(header = "") {
  return splitCookiesString(joinHeaders(header));
}
function normalizeCookieHeaders(headers) {
  const outgoingHeaders = new Headers();
  for (const [name, header] of headers) {
    if (name === "set-cookie") {
      for (const cookie of normalizeCookieHeader(header)) {
        outgoingHeaders.append("set-cookie", cookie);
      }
    } else {
      outgoingHeaders.set(name, joinHeaders(header));
    }
  }
  return outgoingHeaders;
}

/**
* Nitro internal functions extracted from https://github.com/nitrojs/nitro/blob/v2/src/runtime/internal/utils.ts
*/
function isJsonRequest(event) {
	// If the client specifically requests HTML, then avoid classifying as JSON.
	if (hasReqHeader(event, "accept", "text/html")) {
		return false;
	}
	return hasReqHeader(event, "accept", "application/json") || hasReqHeader(event, "user-agent", "curl/") || hasReqHeader(event, "user-agent", "httpie/") || hasReqHeader(event, "sec-fetch-mode", "cors") || event.path.startsWith("/api/") || event.path.endsWith(".json");
}
function hasReqHeader(event, name, includes) {
	const value = getRequestHeader(event, name);
	return !!(value && typeof value === "string" && value.toLowerCase().includes(includes));
}

const errorHandler$0 = (async function errorhandler(error, event, { defaultHandler }) {
	if (event.handled || isJsonRequest(event)) {
		// let Nitro handle JSON errors
		return;
	}
	// invoke default Nitro error handler (which will log appropriately if required)
	const defaultRes = await defaultHandler(error, event, { json: true });
	// let Nitro handle redirect if appropriate
	const status = error.status || error.statusCode || 500;
	if (status === 404 && defaultRes.status === 302) {
		setResponseHeaders(event, defaultRes.headers);
		setResponseStatus(event, defaultRes.status, defaultRes.statusText);
		return send(event, JSON.stringify(defaultRes.body, null, 2));
	}
	const errorObject = defaultRes.body;
	// remove proto/hostname/port from URL
	const url = new URL(errorObject.url);
	errorObject.url = withoutBase(url.pathname, useRuntimeConfig(event).app.baseURL) + url.search + url.hash;
	// add default server message (keep sanitized for unhandled errors)
	errorObject.message = error.unhandled ? errorObject.message || "Server Error" : error.message || errorObject.message || "Server Error";
	// we will be rendering this error internally so we can pass along the error.data safely
	errorObject.data ||= error.data;
	errorObject.statusText ||= error.statusText || error.statusMessage;
	delete defaultRes.headers["content-type"];
	delete defaultRes.headers["content-security-policy"];
	setResponseHeaders(event, defaultRes.headers);
	// Access request headers
	const reqHeaders = getRequestHeaders(event);
	// Detect to avoid recursion in SSR rendering of errors
	const isRenderingError = event.path.startsWith("/__nuxt_error") || !!reqHeaders["x-nuxt-error"];
	// HTML response (via SSR)
	const res = isRenderingError ? null : await useNitroApp().localFetch(withQuery(joinURL(useRuntimeConfig(event).app.baseURL, "/__nuxt_error"), errorObject), {
		headers: {
			...reqHeaders,
			"x-nuxt-error": "true"
		},
		redirect: "manual"
	}).catch(() => null);
	if (event.handled) {
		return;
	}
	// Fallback to static rendered error page
	if (!res) {
		const { template } = await import('../_/error-500.mjs');
		setResponseHeader(event, "Content-Type", "text/html;charset=UTF-8");
		return send(event, template(errorObject));
	}
	const html = await res.text();
	for (const [header, value] of res.headers.entries()) {
		if (header === "set-cookie") {
			appendResponseHeader(event, header, value);
			continue;
		}
		setResponseHeader(event, header, value);
	}
	setResponseStatus(event, res.status && res.status !== 200 ? res.status : defaultRes.status, res.statusText || defaultRes.statusText);
	return send(event, html);
});

function defineNitroErrorHandler(handler) {
  return handler;
}

const errorHandler$1 = defineNitroErrorHandler(
  function defaultNitroErrorHandler(error, event) {
    const res = defaultHandler(error, event);
    setResponseHeaders(event, res.headers);
    setResponseStatus(event, res.status, res.statusText);
    return send(event, JSON.stringify(res.body, null, 2));
  }
);
function defaultHandler(error, event, opts) {
  const isSensitive = error.unhandled || error.fatal;
  const statusCode = error.statusCode || 500;
  const statusMessage = error.statusMessage || "Server Error";
  const url = getRequestURL(event, { xForwardedHost: true, xForwardedProto: true });
  if (statusCode === 404) {
    const baseURL = "/";
    if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) {
      const redirectTo = `${baseURL}${url.pathname.slice(1)}${url.search}`;
      return {
        status: 302,
        statusText: "Found",
        headers: { location: redirectTo },
        body: `Redirecting...`
      };
    }
  }
  if (isSensitive && !opts?.silent) {
    const tags = [error.unhandled && "[unhandled]", error.fatal && "[fatal]"].filter(Boolean).join(" ");
    console.error(`[request error] ${tags} [${event.method}] ${url}
`, error);
  }
  const headers = {
    "content-type": "application/json",
    // Prevent browser from guessing the MIME types of resources.
    "x-content-type-options": "nosniff",
    // Prevent error page from being embedded in an iframe
    "x-frame-options": "DENY",
    // Prevent browsers from sending the Referer header
    "referrer-policy": "no-referrer",
    // Disable the execution of any js
    "content-security-policy": "script-src 'none'; frame-ancestors 'none';"
  };
  setResponseStatus(event, statusCode, statusMessage);
  if (statusCode === 404 || !getResponseHeader(event, "cache-control")) {
    headers["cache-control"] = "no-cache";
  }
  const body = {
    error: true,
    url: url.href,
    statusCode,
    statusMessage,
    message: isSensitive ? "Server Error" : error.message,
    data: isSensitive ? void 0 : error.data
  };
  return {
    status: statusCode,
    statusText: statusMessage,
    headers,
    body
  };
}

const errorHandlers = [errorHandler$0, errorHandler$1];

async function errorHandler(error, event) {
  for (const handler of errorHandlers) {
    try {
      await handler(error, event, { defaultHandler });
      if (event.handled) {
        return; // Response handled
      }
    } catch(error) {
      // Handler itself thrown, log and continue
      console.error(error);
    }
  }
  // H3 will handle fallback
}

const script = "\"use strict\";(()=>{const t=window,e=document.documentElement,c=[\"dark\",\"light\"],n=getStorageValue(\"localStorage\",\"nuxt-color-mode\")||\"system\";let i=n===\"system\"?u():n;const r=e.getAttribute(\"data-color-mode-forced\");r&&(i=r),l(i),t[\"__NUXT_COLOR_MODE__\"]={preference:n,value:i,getColorScheme:u,addColorScheme:l,removeColorScheme:d};function l(o){const s=\"\"+o+\"\",a=\"\";e.classList?e.classList.add(s):e.className+=\" \"+s,a&&e.setAttribute(\"data-\"+a,o)}function d(o){const s=\"\"+o+\"\",a=\"\";e.classList?e.classList.remove(s):e.className=e.className.replace(new RegExp(s,\"g\"),\"\"),a&&e.removeAttribute(\"data-\"+a)}function f(o){return t.matchMedia(\"(prefers-color-scheme\"+o+\")\")}function u(){if(t.matchMedia&&f(\"\").media!==\"not all\"){for(const o of c)if(f(\":\"+o).matches)return o}return\"light\"}})();function getStorageValue(t,e){switch(t){case\"localStorage\":return window.localStorage.getItem(e);case\"sessionStorage\":return window.sessionStorage.getItem(e);case\"cookie\":return getCookie(e);default:return null}}function getCookie(t){const c=(\"; \"+window.document.cookie).split(\"; \"+t+\"=\");if(c.length===2)return c.pop()?.split(\";\").shift()}";

const _ZtmKUqR5HuKUjKurgUqIYJEoYg1fp1BxY8l2Mhbz7Ts = (function(nitro) {
  nitro.hooks.hook("render:html", (htmlContext) => {
    htmlContext.head.push(`<script>${script}<\/script>`);
  });
});

function defineNitroPlugin(def) {
  return def;
}

const LICENSE_FILE = "/etc/softcall-license.enc";
const ADDON_REL = "native/build/Release/softcall_license.node";
function findAddonPath() {
  const candidates = [
    resolve$2(process.cwd(), ADDON_REL)
  ];
  try {
    const thisDir = dirname$2(fileURLToPath(globalThis._importMeta_.url));
    candidates.push(resolve$2(thisDir, "../..", ADDON_REL));
    candidates.push(resolve$2(thisDir, "../../../..", ADDON_REL));
  } catch {
  }
  candidates.push(resolve$2("/opt/issabel-ui", ADDON_REL));
  for (const p of candidates) {
    if (existsSync$1(p)) return p;
  }
  return candidates[0];
}
const ADDON_PATH = findAddonPath();
let addon = null;
let periodicTimer = null;
function makeRequire() {
  try {
    return createRequire(globalThis._importMeta_.url);
  } catch {
    return createRequire(resolve$2(process.cwd(), "package.json"));
  }
}
function loadAddon() {
  if (addon) return addon;
  try {
    const _require = makeRequire();
    addon = _require(ADDON_PATH);
  } catch (e) {
    console.error("[License] Failed to load native addon:", e);
    addon = null;
  }
  return addon;
}
function getAddon() {
  if (!addon) loadAddon();
  return addon;
}
function getMachineId() {
  const a = getAddon();
  if (!a) return "unknown";
  return a.nativeMachineId();
}
function getLicenseStatus() {
  const a = getAddon();
  if (!a) {
    return {
      valid: false,
      customer: "",
      key: "",
      expiresAt: "",
      reason: "License module not loaded",
      features: [],
      machineId: "unknown"
    };
  }
  const status = a.nativeGetStatus();
  return { ...status, machineId: a.nativeMachineId() };
}
function isLicenseValid() {
  const a = getAddon();
  if (!a) return false;
  return a.nativeGetStatus().valid === true;
}
function validateLocalLicense() {
  const a = getAddon();
  if (!a) return { valid: false, reason: "License module not loaded" };
  const result = a.nativeValidate(LICENSE_FILE);
  return { valid: result.valid, reason: result.reason || "" };
}
async function activateLicense(key) {
  const a = getAddon();
  if (!a) return { ok: false, reason: "License module not loaded" };
  const machineId = a.nativeMachineId();
  const config = useRuntimeConfig();
  const apiUrl = config.licenseApiUrl || "https://license.softphone.plus";
  try {
    const response = await $fetch(`${apiUrl}/api/licenses/check`, {
      method: "POST",
      body: { key, machineId },
      timeout: 15e3
    });
    if (!response.valid || !response.license) {
      return { ok: false, reason: response.reason || "License validation failed" };
    }
    const licenseJson = JSON.stringify(response.license);
    const encrypted = a.nativeEncrypt(licenseJson);
    writeFileSync(LICENSE_FILE, Buffer.from(encrypted));
    const result = a.nativeValidate(LICENSE_FILE);
    if (!result.valid) {
      try {
        unlinkSync(LICENSE_FILE);
      } catch {
      }
      return { ok: false, reason: result.reason || "Local validation failed after save" };
    }
    await startAsterisk();
    return {
      ok: true,
      customer: result.customer,
      features: result.features
    };
  } catch (e) {
    if (e.status === 429) {
      return { ok: false, reason: "Rate limited. Please try again later." };
    }
    return { ok: false, reason: e.message || "Failed to contact license server" };
  }
}
async function deactivateLicense() {
  const a = getAddon();
  if (a) a.nativeInvalidate();
  try {
    unlinkSync(LICENSE_FILE);
  } catch {
  }
  await stopAsterisk();
  return { ok: true };
}
async function checkRemoteLicense() {
  const a = getAddon();
  if (!a) return false;
  const status = a.nativeGetStatus();
  if (!status.key) return false;
  const machineId = a.nativeMachineId();
  const config = useRuntimeConfig();
  const apiUrl = config.licenseApiUrl || "https://license.softphone.plus";
  try {
    const response = await $fetch(`${apiUrl}/api/licenses/check`, {
      method: "POST",
      body: { key: status.key, machineId },
      timeout: 15e3
    });
    if (!response.valid) {
      a.nativeInvalidate();
      console.log("[License] Remote check failed:", response.reason);
      await stopAsterisk();
      return false;
    }
    if (response.license) {
      const licenseJson = JSON.stringify(response.license);
      const encrypted = a.nativeEncrypt(licenseJson);
      writeFileSync(LICENSE_FILE, Buffer.from(encrypted));
      a.nativeValidate(LICENSE_FILE);
    }
    return true;
  } catch (e) {
    if (e.status === 429) {
      console.log("[License] Remote check rate limited, using cached license");
      return status.valid;
    }
    console.log("[License] Remote check failed (network), using cached license");
    return status.valid;
  }
}
function startPeriodicCheck() {
  if (periodicTimer) return;
  const INTERVAL = 24 * 60 * 60 * 1e3;
  periodicTimer = setInterval(async () => {
    console.log("[License] Periodic remote validation...");
    const ok = await checkRemoteLicense();
    if (!ok) {
      console.error("[License] Periodic check failed - license invalid");
    }
  }, INTERVAL);
}
function execShell(cmd, args) {
  return new Promise((resolve2) => {
    execFile(cmd, args, (err, stdout, stderr) => {
      resolve2({ code: err ? err.code || 1 : 0, stdout: stdout || "", stderr: stderr || "" });
    });
  });
}
async function stopAsterisk() {
  console.log("[License] Stopping Asterisk...");
  await execShell("systemctl", ["stop", "asterisk"]);
}
async function startAsterisk() {
  console.log("[License] Starting Asterisk...");
  await execShell("systemctl", ["start", "asterisk"]);
}
function initLicenseModule() {
  loadAddon();
}

const _CnRx2Act_uFs0fOF97i_W6HWZbpMsp_e3Vi934jN4M = defineNitroPlugin(() => {
  console.log("[License] Initializing license module...");
  initLicenseModule();
  const result = validateLocalLicense();
  if (!result.valid) {
    console.error(`[License] Local validation failed: ${result.reason}`);
    if (result.reason !== "License file not found") {
      stopAsterisk().catch(() => {
      });
    }
    return;
  }
  console.log("[License] Local license valid, verifying with remote server...");
  checkRemoteLicense().then((remoteOk) => {
    if (!remoteOk && !isLicenseValid()) {
      console.error("[License] Remote verification failed and license is now invalid");
      stopAsterisk().catch(() => {
      });
      return;
    }
    const status = getLicenseStatus();
    console.log(`[License] Active - Customer: ${status.customer}, Features: ${status.features.join(", ")}`);
    startPeriodicCheck();
  }).catch((err) => {
    console.error("[License] Remote check error:", err);
  });
});

var __defProp$1 = Object.defineProperty;
var __defNormalProp$1 = (obj, key, value) => key in obj ? __defProp$1(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField$1 = (obj, key, value) => __defNormalProp$1(obj, typeof key !== "symbol" ? key + "" : key, value);
class AmiClient extends EventEmitter {
  constructor(host, port, username, secret) {
    super();
    __publicField$1(this, "host", host);
    __publicField$1(this, "port", port);
    __publicField$1(this, "username", username);
    __publicField$1(this, "secret", secret);
    __publicField$1(this, "socket", null);
    __publicField$1(this, "buffer", "");
    __publicField$1(this, "connected", false);
    __publicField$1(this, "loggedIn", false);
    __publicField$1(this, "greetingReceived", false);
    __publicField$1(this, "reconnectTimer", null);
    __publicField$1(this, "keepaliveTimer", null);
    __publicField$1(this, "actionId", 0);
    __publicField$1(this, "pendingActions", /* @__PURE__ */ new Map());
    this.setMaxListeners(200);
  }
  connect() {
    if (this.socket) {
      this.socket.removeAllListeners();
      this.socket.destroy();
    }
    if (this.keepaliveTimer) {
      clearInterval(this.keepaliveTimer);
      this.keepaliveTimer = null;
    }
    this.socket = new Socket();
    this.buffer = "";
    this.greetingReceived = false;
    this.loggedIn = false;
    this.socket.connect(this.port, this.host, () => {
      this.connected = true;
      console.log("[AMI] TCP connected to", this.host, this.port);
    });
    this.socket.on("data", (data) => this.onData(data.toString()));
    this.socket.on("close", () => {
      console.log("[AMI] Socket closed");
      this.connected = false;
      this.loggedIn = false;
      this.greetingReceived = false;
      if (this.keepaliveTimer) {
        clearInterval(this.keepaliveTimer);
        this.keepaliveTimer = null;
      }
      for (const [id, p] of this.pendingActions) {
        p.reject(new Error("Disconnected"));
      }
      this.pendingActions.clear();
      this.emit("disconnected");
      this.scheduleReconnect();
    });
    this.socket.on("error", (err) => {
      console.error("[AMI] Socket error:", err.message);
    });
  }
  scheduleReconnect() {
    if (this.reconnectTimer) return;
    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = null;
      console.log("[AMI] Reconnecting...");
      this.connect();
    }, 5e3);
  }
  onData(data) {
    this.buffer += data;
    if (!this.greetingReceived) {
      const nlIdx = this.buffer.indexOf("\r\n");
      if (nlIdx === -1) return;
      const firstLine = this.buffer.substring(0, nlIdx);
      if (firstLine.startsWith("Asterisk Call Manager")) {
        this.greetingReceived = true;
        this.buffer = this.buffer.substring(nlIdx + 2);
        console.log("[AMI] Greeting:", firstLine);
        this.doLogin();
      }
    }
    this.processBlocks();
  }
  processBlocks() {
    while (true) {
      const idx = this.buffer.indexOf("\r\n\r\n");
      if (idx === -1) break;
      const block = this.buffer.substring(0, idx);
      this.buffer = this.buffer.substring(idx + 4);
      if (!block.trim()) continue;
      const parsed = this.parseBlock(block);
      if (!parsed) continue;
      if (parsed.response && !this.loggedIn) {
        if (parsed.response === "Success") {
          this.loggedIn = true;
          console.log("[AMI] Login successful:", parsed.message || "");
          this.startKeepalive();
          this.emit("ready");
        } else {
          console.error("[AMI] Login failed:", parsed.message || parsed.response);
        }
        continue;
      }
      const aid = parsed.actionid;
      if (aid && this.pendingActions.has(aid)) {
        const pending = this.pendingActions.get(aid);
        this.pendingActions.delete(aid);
        if (parsed.response === "Error") {
          pending.reject(new Error(parsed.message || "AMI error"));
        } else {
          pending.resolve(parsed);
        }
      }
      if (parsed.event) {
        this.emit("event", parsed);
        this.emit(`event:${parsed.event}`, parsed);
      }
    }
  }
  parseBlock(block) {
    const result = {};
    for (const line of block.split("\r\n")) {
      const idx = line.indexOf(": ");
      if (idx === -1) continue;
      const key = line.substring(0, idx).toLowerCase().replace(/-/g, "");
      const val = line.substring(idx + 2);
      result[key] = val;
    }
    return Object.keys(result).length ? result : null;
  }
  doLogin() {
    console.log("[AMI] Sending login...");
    this.sendRaw(
      `Action: Login\r
Username: ${this.username}\r
Secret: ${this.secret}\r
Events: on\r
\r
`
    );
  }
  startKeepalive() {
    if (this.keepaliveTimer) clearInterval(this.keepaliveTimer);
    this.keepaliveTimer = setInterval(() => {
      if (!this.connected || !this.loggedIn) return;
      this.sendAction("Ping").catch(() => {
      });
    }, 25e3);
  }
  sendRaw(data) {
    if (this.socket && this.connected) {
      this.socket.write(data);
    }
  }
  async sendAction(action, params = {}) {
    const id = String(++this.actionId);
    let raw = `Action: ${action}\r
ActionID: ${id}\r
`;
    for (const [k, v] of Object.entries(params)) {
      raw += `${k}: ${v}\r
`;
    }
    raw += "\r\n";
    return new Promise((resolve, reject) => {
      this.pendingActions.set(id, { resolve, reject });
      this.sendRaw(raw);
      setTimeout(() => {
        if (this.pendingActions.has(id)) {
          this.pendingActions.delete(id);
          resolve({ response: "Timeout" });
        }
      }, 1e4);
    });
  }
  isReady() {
    return this.connected && this.loggedIn;
  }
  destroy() {
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    if (this.keepaliveTimer) clearInterval(this.keepaliveTimer);
    if (this.socket) {
      this.socket.removeAllListeners();
      this.socket.destroy();
    }
    this.removeAllListeners();
  }
}
let _client = null;
function getAmiClient() {
  if (!_client) {
    _client = new AmiClient("127.0.0.1", 5038, "admin", "Os01000455834");
  }
  return _client;
}

const ISSABEL_CONF = "/etc/issabel.conf";
const execCmd = (command, args, env) => new Promise((resolve) => {
  execFile$1(command, args, { env: { ...process.env, ...env }, timeout: 1e4 }, (error, stdout, stderr) => {
    var _a;
    if (error) {
      resolve({
        stdout: String(stdout != null ? stdout : ""),
        stderr: String(stderr != null ? stderr : "") || String((_a = error.message) != null ? _a : ""),
        code: typeof error.code === "number" ? error.code : 1
      });
      return;
    }
    resolve({ stdout: String(stdout != null ? stdout : ""), stderr: String(stderr != null ? stderr : ""), code: 0 });
  });
});
const readIssabelSecrets = async () => {
  const text = await readFile$1(ISSABEL_CONF, "utf-8");
  const secrets = /* @__PURE__ */ new Map();
  for (const rawLine of text.split("\n")) {
    const line = rawLine.trim();
    if (!line || line.startsWith("#") || !line.includes("=")) continue;
    const [key, ...rest] = line.split("=");
    secrets.set(key.trim(), rest.join("=").trim());
  }
  return {
    mysqlRootPassword: secrets.get("mysqlrootpwd") || "",
    amiAdminPassword: secrets.get("amiadminpwd") || ""
  };
};
const mysqlQuery = async (query, db = "asterisk") => {
  const { mysqlRootPassword } = await readIssabelSecrets();
  if (!mysqlRootPassword) return [];
  const result = await execCmd(
    "mysql",
    ["-uroot", "-D", db, "-Nse", query],
    { MYSQL_PWD: mysqlRootPassword }
  );
  if (result.code !== 0) return [];
  return result.stdout.trim().split("\n").map((line) => line.trim()).filter(Boolean);
};
const mysqlExec = async (query, db = "asterisk") => {
  const { mysqlRootPassword } = await readIssabelSecrets();
  if (!mysqlRootPassword) return { ok: false, error: "No MySQL password" };
  const result = await execCmd(
    "mysql",
    ["-uroot", "-D", db, "-e", query],
    { MYSQL_PWD: mysqlRootPassword }
  );
  return { ok: result.code === 0, error: result.stderr };
};
const runAsterisk = async (cliCommand) => {
  const result = await execCmd("asterisk", ["-rx", cliCommand]);
  if (result.code !== 0) return "";
  return result.stdout.trim();
};
const reloadAsterisk = async () => {
  return runAsterisk("core reload");
};
const serviceIsActive = async (name) => {
  const status = await execCmd("service", [name, "status"]);
  const text = `${status.stdout}
${status.stderr}`.toLowerCase();
  if (text.includes("unrecognized") || text.includes("not found") || text.includes("no such"))
    return { running: false, installed: false };
  if (status.code === 0 || text.includes("active (running)") || text.includes("running"))
    return { running: true, installed: true };
  if (text.includes("active (exited)") || text.includes("active")) {
    return { running: true, installed: true };
  }
  return { running: false, installed: true };
};
const isDialerRunning = async () => {
  const { readFile: readFile2 } = await import('node:fs/promises');
  const pidFile = "/opt/issabel/dialer/dialerd.pid";
  try {
    const pid = (await readFile2(pidFile, "utf-8")).trim().split(/\s/)[0];
    if (pid && /^\d+$/.test(pid)) {
      const { access } = await import('node:fs/promises');
      await access(`/proc/${pid}`);
      return { running: true, installed: true };
    }
  } catch {
  }
  return serviceIsActive("issabeldialer");
};

var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
class AmiStateManager {
  constructor() {
    __publicField(this, "extensions", /* @__PURE__ */ new Map());
    __publicField(this, "channels", /* @__PURE__ */ new Map());
    __publicField(this, "queues", /* @__PURE__ */ new Map());
    __publicField(this, "trunks", /* @__PURE__ */ new Map());
    __publicField(this, "parking", /* @__PURE__ */ new Map());
    __publicField(this, "conferences", /* @__PURE__ */ new Map());
    __publicField(this, "bridges", /* @__PURE__ */ new Map());
    // bridgeId -> set of channels
    __publicField(this, "subscribers", /* @__PURE__ */ new Set());
    __publicField(this, "notifyTimer", null);
    __publicField(this, "initialized", false);
  }
  subscribe(cb) {
    this.subscribers.add(cb);
  }
  unsubscribe(cb) {
    this.subscribers.delete(cb);
  }
  notifyChange() {
    if (this.notifyTimer) return;
    this.notifyTimer = setTimeout(() => {
      this.notifyTimer = null;
      const snap = this.getSnapshot();
      for (const cb of this.subscribers) {
        try {
          cb(snap);
        } catch {
        }
      }
    }, 100);
  }
  getSnapshot() {
    return {
      extensions: Array.from(this.extensions.values()),
      queues: Array.from(this.queues.values()),
      trunks: Array.from(this.trunks.values()),
      parking: Array.from(this.parking.values()),
      conferences: Array.from(this.conferences.values())
    };
  }
  async seedFromAMI(ami) {
    this.channels.clear();
    this.bridges.clear();
    this.parking.clear();
    this.conferences.clear();
    for (const ext of this.extensions.values()) {
      ext.state = "unknown";
      ext.registered = false;
      ext.channel = "";
      ext.callerIdNum = "";
      ext.callerIdName = "";
      ext.talkingTo = "";
      ext.callStart = 0;
      ext.direction = "";
    }
    for (const q of this.queues.values()) {
      q.members = [];
      q.callers = [];
      q.calls = 0;
    }
    for (const t of this.trunks.values()) {
      t.activeChannels = [];
    }
    try {
      const rows = await mysqlQuery(
        "SELECT u.extension, IFNULL(u.name,''), IFNULL(d.tech,'SIP') FROM users u LEFT JOIN devices d ON d.id=u.extension ORDER BY u.extension"
      );
      for (const r of rows) {
        const [ext, name, tech] = r.split("	");
        if (!ext) continue;
        if (!this.extensions.has(ext)) {
          this.extensions.set(ext, {
            extension: ext,
            name: name || `Ext ${ext}`,
            tech: tech || "SIP",
            state: "unknown",
            registered: false,
            ip: "",
            channel: "",
            callerIdNum: "",
            callerIdName: "",
            talkingTo: "",
            callStart: 0,
            direction: ""
          });
        } else {
          const e = this.extensions.get(ext);
          e.name = name || e.name;
          e.tech = tech || e.tech;
        }
      }
    } catch (err) {
      console.error("[AMI State] Failed to load extensions from DB:", err);
    }
    try {
      const rows = await mysqlQuery(
        "SELECT trunkid, IFNULL(name,''), IFNULL(tech,''), IFNULL(channelid,'') FROM trunks ORDER BY trunkid"
      );
      for (const r of rows) {
        const [id, name, tech, channelid] = r.split("	");
        if (!this.trunks.has(id)) {
          this.trunks.set(id, { id, name: name || `Trunk ${id}`, tech, channelid, activeChannels: [] });
        }
      }
    } catch (err) {
      console.error("[AMI State] Failed to load trunks from DB:", err);
    }
    try {
      const rows = await mysqlQuery("SELECT extension, IFNULL(descr,'') FROM queues_config ORDER BY extension");
      for (const r of rows) {
        const [ext, descr] = r.split("	");
        if (!ext) continue;
        if (!this.queues.has(ext)) {
          this.queues.set(ext, {
            name: ext,
            description: descr || ext,
            strategy: "",
            calls: 0,
            holdtime: 0,
            talktime: 0,
            completed: 0,
            abandoned: 0,
            sl: "0.0%",
            members: [],
            callers: []
          });
        }
      }
    } catch (err) {
      console.error("[AMI State] Failed to load queues from DB:", err);
    }
    console.log(`[AMI State] Loaded ${this.extensions.size} extensions, ${this.trunks.size} trunks, ${this.queues.size} queues from DB`);
    this.notifyChange();
    try {
      await ami.sendAction("SIPpeers");
    } catch {
    }
    try {
      await ami.sendAction("Status");
    } catch {
    }
    try {
      await ami.sendAction("QueueStatus");
    } catch {
    }
    try {
      await ami.sendAction("ParkedCalls");
    } catch {
    }
    try {
      await ami.sendAction("ConfbridgeListRooms");
    } catch {
    }
    setTimeout(() => this.notifyChange(), 3e3);
  }
  handleEvent(evt) {
    const name = evt.event;
    switch (name) {
      case "PeerStatus":
        this.onPeerStatus(evt);
        break;
      case "PeerEntry":
        this.onPeerEntry(evt);
        break;
      case "DeviceStateChange":
      case "ExtensionStatus":
        this.onDeviceState(evt);
        break;
      case "Newchannel":
        this.onNewchannel(evt);
        break;
      case "Newstate":
        this.onNewstate(evt);
        break;
      case "Hangup":
        this.onHangup(evt);
        break;
      case "BridgeEnter":
        this.onBridgeEnter(evt);
        break;
      case "BridgeLeave":
        this.onBridgeLeave(evt);
        break;
      case "Status":
        this.onStatusResponse(evt);
        break;
      case "QueueParams":
        this.onQueueParams(evt);
        break;
      case "QueueMember":
      case "QueueMemberAdded":
      case "QueueMemberStatus":
        this.onQueueMember(evt);
        break;
      case "QueueMemberRemoved":
        this.onQueueMemberRemoved(evt);
        break;
      case "QueueMemberPause":
      case "QueueMemberPaused":
        this.onQueueMemberPause(evt);
        break;
      case "QueueCallerJoin":
      case "Join":
        this.onQueueCallerJoin(evt);
        break;
      case "QueueCallerLeave":
      case "Leave":
        this.onQueueCallerLeave(evt);
        break;
      case "ParkedCall":
        this.onParkedCall(evt);
        break;
      case "UnParkedCall":
      case "ParkedCallTimeOut":
        this.onUnParkedCall(evt);
        break;
      case "ParkedCallGiveUp":
        this.onUnParkedCall(evt);
        break;
      case "ConfbridgeJoin":
        this.onConfJoin(evt);
        break;
      case "ConfbridgeLeave":
        this.onConfLeave(evt);
        break;
      case "ConfbridgeMute":
      case "ConfbridgeUnmute":
        this.onConfMute(evt);
        break;
      default:
        return;
    }
    this.notifyChange();
  }
  // ======================== Event Handlers ========================
  extractExt(channel) {
    const m = channel.match(/^(?:SIP|PJSIP|IAX2)\/(\d+)/i);
    return m ? m[1] : "";
  }
  onPeerStatus(evt) {
    var _a;
    const peer = ((_a = evt.peer) == null ? void 0 : _a.replace(/^SIP\/|^PJSIP\/|^IAX2\//i, "")) || "";
    const ext = this.extensions.get(peer);
    if (!ext) return;
    const status = (evt.peerstatus || "").toLowerCase();
    ext.registered = status === "registered" || status === "reachable";
    if (!ext.registered && ext.state === "unknown") ext.state = "unavailable";
    if (ext.registered && ext.state === "unavailable") ext.state = "idle";
    if (evt.address) ext.ip = evt.address.split(":")[0];
  }
  onPeerEntry(evt) {
    const peer = evt.objectname || evt.name || "";
    const ext = this.extensions.get(peer);
    if (!ext) return;
    const status = (evt.status || "").toLowerCase();
    ext.registered = status.includes("ok") || status.includes("reachable");
    if (ext.registered) {
      if (ext.state === "unknown" || ext.state === "unavailable") ext.state = "idle";
    } else {
      ext.state = "unavailable";
    }
    if (evt.ipaddress && evt.ipaddress !== "-none-") ext.ip = evt.ipaddress.split(":")[0];
  }
  onDeviceState(evt) {
    const device = evt.device || evt.exten || "";
    const ext = this.extensions.get(device.replace(/^SIP\/|^PJSIP\/|^Custom:/i, ""));
    if (!ext) return;
    const s = (evt.state || evt.status || "").toLowerCase();
    if (s.includes("not_inuse") || s.includes("idle") || s === "0") ext.state = "idle";
    else if (s.includes("ringing") || s === "4" || s === "8") ext.state = "ringing";
    else if (s.includes("inuse") || s.includes("in use") || s === "1") ext.state = "inuse";
    else if (s.includes("busy") || s === "2") ext.state = "busy";
    else if (s.includes("unavailable") || s === "-1") ext.state = "unavailable";
    else if (s.includes("onhold") || s.includes("hold") || s === "16") ext.state = "onhold";
  }
  onNewchannel(evt) {
    var _a;
    const ch = evt.channel;
    if (!ch) return;
    this.channels.set(ch, {
      channel: ch,
      state: evt.channelstatedesc || evt.channelstate || "Down",
      callerIdNum: evt.calleridnum || "",
      callerIdName: evt.calleridname || "",
      connectedLineNum: evt.connectedlinenum || "",
      connectedLineName: evt.connectedlinename || "",
      extension: evt.exten || "",
      context: evt.context || "",
      bridgeId: "",
      bridgedChannel: "",
      startTime: Date.now(),
      application: ""
    });
    const extNum = this.extractExt(ch);
    if (extNum) {
      const ext = this.extensions.get(extNum);
      if (ext) {
        ext.channel = ch;
        ext.callerIdNum = evt.calleridnum || "";
        ext.callerIdName = evt.calleridname || "";
        if ((_a = evt.context) == null ? void 0 : _a.includes("from-internal")) ext.direction = "out";
        else ext.direction = "in";
      }
    }
  }
  onNewstate(evt) {
    const ch = this.channels.get(evt.channel || "");
    if (ch) {
      ch.state = evt.channelstatedesc || evt.channelstate || ch.state;
      ch.connectedLineNum = evt.connectedlinenum || ch.connectedLineNum;
      ch.connectedLineName = evt.connectedlinename || ch.connectedLineName;
    }
    const extNum = this.extractExt(evt.channel || "");
    if (extNum) {
      const ext = this.extensions.get(extNum);
      if (ext) {
        const state = (evt.channelstatedesc || "").toLowerCase();
        if (state === "up") {
          ext.state = "inuse";
          if (!ext.callStart) ext.callStart = Date.now();
          ext.callerIdNum = evt.connectedlinenum || ext.callerIdNum;
          ext.callerIdName = evt.connectedlinename || ext.callerIdName;
        } else if (state === "ringing" || state === "ring") {
          ext.state = "ringing";
        }
      }
    }
  }
  onHangup(evt) {
    const ch = evt.channel || "";
    this.channels.delete(ch);
    const extNum = this.extractExt(ch);
    if (extNum) {
      const ext = this.extensions.get(extNum);
      if (ext && ext.channel === ch) {
        ext.state = ext.registered ? "idle" : "unavailable";
        ext.channel = "";
        ext.callerIdNum = "";
        ext.callerIdName = "";
        ext.talkingTo = "";
        ext.callStart = 0;
        ext.direction = "";
      }
    }
    for (const [bid, members] of this.bridges) {
      if (members.has(ch)) {
        members.delete(ch);
        if (members.size === 0) this.bridges.delete(bid);
        for (const remaining of members) {
          const rExt = this.extractExt(remaining);
          if (rExt) {
            const re = this.extensions.get(rExt);
            if (re) re.talkingTo = "";
          }
        }
      }
    }
    for (const trunk of this.trunks.values()) {
      trunk.activeChannels = trunk.activeChannels.filter((c) => c !== ch);
    }
  }
  onBridgeEnter(evt) {
    const bid = evt.bridgeuniqueid || "";
    const ch = evt.channel || "";
    if (!bid || !ch) return;
    const chState = this.channels.get(ch);
    if (chState) chState.bridgeId = bid;
    if (!this.bridges.has(bid)) this.bridges.set(bid, /* @__PURE__ */ new Set());
    const members = this.bridges.get(bid);
    members.add(ch);
    if (members.size === 2) {
      const [ch1, ch2] = Array.from(members);
      const ext1 = this.extractExt(ch1);
      const ext2 = this.extractExt(ch2);
      if (ext1 && this.extensions.has(ext1)) {
        const e1 = this.extensions.get(ext1);
        e1.talkingTo = ext2 || ch2;
        e1.state = "inuse";
        if (!e1.callStart) e1.callStart = Date.now();
        const ch2s = this.channels.get(ch2);
        if (ch2s) {
          e1.callerIdNum = ch2s.callerIdNum;
          e1.callerIdName = ch2s.callerIdName;
        }
      }
      if (ext2 && this.extensions.has(ext2)) {
        const e2 = this.extensions.get(ext2);
        e2.talkingTo = ext1 || ch1;
        e2.state = "inuse";
        if (!e2.callStart) e2.callStart = Date.now();
        const ch1s = this.channels.get(ch1);
        if (ch1s) {
          e2.callerIdNum = ch1s.callerIdNum;
          e2.callerIdName = ch1s.callerIdName;
        }
      }
      const cs1 = this.channels.get(ch1);
      const cs2 = this.channels.get(ch2);
      if (cs1) cs1.bridgedChannel = ch2;
      if (cs2) cs2.bridgedChannel = ch1;
    }
    for (const trunk of this.trunks.values()) {
      if (ch.toLowerCase().includes(trunk.channelid.toLowerCase()) && !trunk.activeChannels.includes(ch)) {
        trunk.activeChannels.push(ch);
      }
    }
  }
  onBridgeLeave(evt) {
    const bid = evt.bridgeuniqueid || "";
    const ch = evt.channel || "";
    const members = this.bridges.get(bid);
    if (members) {
      members.delete(ch);
      if (members.size === 0) this.bridges.delete(bid);
    }
    const chState = this.channels.get(ch);
    if (chState) {
      chState.bridgeId = "";
      chState.bridgedChannel = "";
    }
  }
  onStatusResponse(evt) {
    if (!evt.channel) return;
    const ch = evt.channel;
    this.channels.set(ch, {
      channel: ch,
      state: evt.channelstatedesc || evt.state || "Up",
      callerIdNum: evt.calleridnum || "",
      callerIdName: evt.calleridname || "",
      connectedLineNum: evt.connectedlinenum || "",
      connectedLineName: evt.connectedlinename || "",
      extension: evt.extension || evt.exten || "",
      context: evt.context || "",
      bridgeId: evt.bridgeid || "",
      bridgedChannel: evt.bridgedchannel || "",
      startTime: evt.seconds ? Date.now() - parseInt(evt.seconds) * 1e3 : Date.now(),
      application: evt.application || ""
    });
    const extNum = this.extractExt(ch);
    if (extNum) {
      const ext = this.extensions.get(extNum);
      if (ext) {
        ext.channel = ch;
        ext.state = "inuse";
        ext.callStart = evt.seconds ? Date.now() - parseInt(evt.seconds) * 1e3 : Date.now();
        ext.callerIdNum = evt.connectedlinenum || evt.calleridnum || "";
        ext.callerIdName = evt.connectedlinename || evt.calleridname || "";
        ext.registered = true;
      }
    }
  }
  // ======================== Queue Events ========================
  onQueueParams(evt) {
    const qName = evt.queue || "";
    const q = this.queues.get(qName);
    if (!q) return;
    q.strategy = evt.strategy || q.strategy;
    q.calls = parseInt(evt.calls || "0");
    q.holdtime = parseInt(evt.holdtime || "0");
    q.talktime = parseInt(evt.talktime || "0");
    q.completed = parseInt(evt.completed || "0");
    q.abandoned = parseInt(evt.abandoned || "0");
    q.sl = evt.servicelevel || q.sl;
  }
  onQueueMember(evt) {
    const qName = evt.queue || "";
    const q = this.queues.get(qName);
    if (!q) return;
    const iface = evt.interface || evt.location || "";
    if (!iface) return;
    const idx = q.members.findIndex((m) => m.interface_ === iface);
    const member = {
      queue: qName,
      interface_: iface,
      name: evt.membername || evt.name || iface,
      penalty: parseInt(evt.penalty || "0"),
      callsTaken: parseInt(evt.callstaken || "0"),
      paused: evt.paused === "1",
      pauseReason: evt.pausedreason || "",
      status: parseInt(evt.status || "1"),
      inCall: parseInt(evt.status || "1") === 2 || parseInt(evt.status || "1") === 7,
      lastCall: parseInt(evt.lastcall || "0")
    };
    if (idx >= 0) q.members[idx] = member;
    else q.members.push(member);
  }
  onQueueMemberRemoved(evt) {
    const q = this.queues.get(evt.queue || "");
    if (!q) return;
    const iface = evt.interface || evt.location || "";
    q.members = q.members.filter((m) => m.interface_ !== iface);
  }
  onQueueMemberPause(evt) {
    const q = this.queues.get(evt.queue || "");
    if (!q) return;
    const iface = evt.interface || evt.location || "";
    const m = q.members.find((m2) => m2.interface_ === iface);
    if (m) {
      m.paused = evt.paused === "1";
      m.pauseReason = evt.reason || evt.pausedreason || "";
    }
  }
  onQueueCallerJoin(evt) {
    const q = this.queues.get(evt.queue || "");
    if (!q) return;
    q.callers.push({
      queue: evt.queue || "",
      position: parseInt(evt.position || "0"),
      channel: evt.channel || "",
      callerIdNum: evt.calleridnum || "",
      callerIdName: evt.calleridname || "",
      joinTime: Date.now()
    });
    q.calls = q.callers.length;
  }
  onQueueCallerLeave(evt) {
    const q = this.queues.get(evt.queue || "");
    if (!q) return;
    q.callers = q.callers.filter((c) => c.channel !== (evt.channel || ""));
    q.calls = q.callers.length;
  }
  // ======================== Parking Events ========================
  onParkedCall(evt) {
    const slot = evt.parkingspace || evt.exten || "";
    this.parking.set(slot, {
      slot,
      channel: evt.parkeechannel || evt.channel || "",
      callerIdNum: evt.parkeecalleridnum || evt.calleridnum || "",
      callerIdName: evt.parkeecalleridname || evt.calleridname || "",
      parkTime: Date.now(),
      timeout: parseInt(evt.parkingtimeout || evt.timeout || "0")
    });
  }
  onUnParkedCall(evt) {
    const slot = evt.parkingspace || evt.exten || "";
    this.parking.delete(slot);
  }
  // ======================== Conference Events ========================
  onConfJoin(evt) {
    const conf = evt.conference || "";
    if (!conf) return;
    if (!this.conferences.has(conf)) {
      this.conferences.set(conf, { conference: conf, participants: [] });
    }
    const room = this.conferences.get(conf);
    room.participants.push({
      channel: evt.channel || "",
      callerIdNum: evt.calleridnum || "",
      callerIdName: evt.calleridname || "",
      muted: false,
      admin: evt.admin === "Yes"
    });
  }
  onConfLeave(evt) {
    const room = this.conferences.get(evt.conference || "");
    if (!room) return;
    room.participants = room.participants.filter((p) => p.channel !== (evt.channel || ""));
    if (room.participants.length === 0) this.conferences.delete(evt.conference || "");
  }
  onConfMute(evt) {
    const room = this.conferences.get(evt.conference || "");
    if (!room) return;
    const p = room.participants.find((p2) => p2.channel === (evt.channel || ""));
    if (p) p.muted = evt.event === "ConfbridgeMute";
  }
}
let _state = null;
function getAmiState() {
  if (!_state) _state = new AmiStateManager();
  return _state;
}

const _pk4AcivQwxxQClQF1Fs11wPqP7UKsszfbLSOdFyng = defineNitroPlugin(() => {
  const ami = getAmiClient();
  const state = getAmiState();
  ami.on("ready", () => {
    console.log("[AMI Plugin] AMI ready, seeding state...");
    state.seedFromAMI(ami);
  });
  ami.on("event", (evt) => {
    state.handleEvent(evt);
  });
  ami.connect();
  console.log("[AMI Plugin] Started AMI connection");
});

const plugins = [
  _ZtmKUqR5HuKUjKurgUqIYJEoYg1fp1BxY8l2Mhbz7Ts,
_CnRx2Act_uFs0fOF97i_W6HWZbpMsp_e3Vi934jN4M,
_pk4AcivQwxxQClQF1Fs11wPqP7UKsszfbLSOdFyng
];

const assets = {
  "/_nuxt/1Mj2ImB2.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1361-iaYKXYVasbdd1jop5Ton1+QrteE\"",
    "mtime": "2026-04-09T20:04:21.494Z",
    "size": 4961,
    "path": "../public/_nuxt/1Mj2ImB2.js"
  },
  "/_nuxt/5-uBZI9j.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"a6a-62kNYvGn/i6w6RDu1LayL2DwR7Y\"",
    "mtime": "2026-04-09T20:04:21.494Z",
    "size": 2666,
    "path": "../public/_nuxt/5-uBZI9j.js"
  },
  "/_nuxt/B0p5cRDd.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2b17-IAoShLvkzA3vmGfFJfKyWWtlqXE\"",
    "mtime": "2026-04-09T20:04:21.494Z",
    "size": 11031,
    "path": "../public/_nuxt/B0p5cRDd.js"
  },
  "/_nuxt/B4J7NHeW.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"20de-g8AQi/96C502pfUefDLbI8J6Yks\"",
    "mtime": "2026-04-09T20:04:21.494Z",
    "size": 8414,
    "path": "../public/_nuxt/B4J7NHeW.js"
  },
  "/_nuxt/B57DxXov.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1da3-HWyt8c9LVdUnXgN7sxTn1q72Hw8\"",
    "mtime": "2026-04-09T20:04:21.494Z",
    "size": 7587,
    "path": "../public/_nuxt/B57DxXov.js"
  },
  "/_nuxt/B5FI5jE0.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1ba-rdcHYyhFRe3u368K34ju/S9/nkc\"",
    "mtime": "2026-04-09T20:04:21.494Z",
    "size": 442,
    "path": "../public/_nuxt/B5FI5jE0.js"
  },
  "/_nuxt/BN-oISFP.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"18e1-lFCqDM9syiQ33SHV87esHWRnBBM\"",
    "mtime": "2026-04-09T20:04:21.494Z",
    "size": 6369,
    "path": "../public/_nuxt/BN-oISFP.js"
  },
  "/_nuxt/BQkj8DdF.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2441-o58ihneG6R5n3gXZjhscC2GFQ94\"",
    "mtime": "2026-04-09T20:04:21.495Z",
    "size": 9281,
    "path": "../public/_nuxt/BQkj8DdF.js"
  },
  "/_nuxt/BQbAX_cz.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1ae8-Y9kKULUzWsAQ+dMHNM1zWqGDEmI\"",
    "mtime": "2026-04-09T20:04:21.494Z",
    "size": 6888,
    "path": "../public/_nuxt/BQbAX_cz.js"
  },
  "/_nuxt/BKzFeOW5.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"18b7-a20fLNmILJ3NCdf3EF7nca46ELc\"",
    "mtime": "2026-04-09T20:04:21.494Z",
    "size": 6327,
    "path": "../public/_nuxt/BKzFeOW5.js"
  },
  "/_nuxt/BCI-8Txf.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"14bf7-wPNTP3YlNAX8mKPpwTPmhf+Glio\"",
    "mtime": "2026-04-09T20:04:21.495Z",
    "size": 84983,
    "path": "../public/_nuxt/BCI-8Txf.js"
  },
  "/_nuxt/BW85DZqq.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"5ca5-zxBhH5sr5NdoduavNBg80aLDUFE\"",
    "mtime": "2026-04-09T20:04:21.494Z",
    "size": 23717,
    "path": "../public/_nuxt/BW85DZqq.js"
  },
  "/_nuxt/Bafouwnq.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3019-eTtsAWHFv2hKuTUgPODXXFN/l6g\"",
    "mtime": "2026-04-09T20:04:21.495Z",
    "size": 12313,
    "path": "../public/_nuxt/Bafouwnq.js"
  },
  "/_nuxt/BZ3R4pEo.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"6f-5BAKlm8z7I1Px0gfc5eg+zzwkzU\"",
    "mtime": "2026-04-09T20:04:21.495Z",
    "size": 111,
    "path": "../public/_nuxt/BZ3R4pEo.js"
  },
  "/_nuxt/BWKjaxDp.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"ff9-XgDZMyT6xXKjrfiy0osf2d4Conc\"",
    "mtime": "2026-04-09T20:04:21.495Z",
    "size": 4089,
    "path": "../public/_nuxt/BWKjaxDp.js"
  },
  "/_nuxt/BYqcSUUf.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"18f3-ueK7gMenZBEQIf9SzgblsD8BT0k\"",
    "mtime": "2026-04-09T20:04:21.495Z",
    "size": 6387,
    "path": "../public/_nuxt/BYqcSUUf.js"
  },
  "/_nuxt/Bjm-gxCv.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"db7-spGdnEvq32qLQmoT1DPaefZ6/KY\"",
    "mtime": "2026-04-09T20:04:21.495Z",
    "size": 3511,
    "path": "../public/_nuxt/Bjm-gxCv.js"
  },
  "/_nuxt/BoR2BHM0.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"102e2-hCahoG0zOn/+hm5Oras4a+/ZoqE\"",
    "mtime": "2026-04-09T20:04:21.495Z",
    "size": 66274,
    "path": "../public/_nuxt/BoR2BHM0.js"
  },
  "/_nuxt/Bpy0fIlH.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"16c6-xdo6+hDhVb52smC2/K2xPrxWIU8\"",
    "mtime": "2026-04-09T20:04:21.495Z",
    "size": 5830,
    "path": "../public/_nuxt/Bpy0fIlH.js"
  },
  "/_nuxt/BgBbA9Hy.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"479c-FyOWRyMfDvMiB+GcfXZN033FcDY\"",
    "mtime": "2026-04-09T20:04:21.495Z",
    "size": 18332,
    "path": "../public/_nuxt/BgBbA9Hy.js"
  },
  "/_nuxt/Bfm7aUt1.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"40-QPMtlh47nY3HJgczB6mA/H6Ji6Q\"",
    "mtime": "2026-04-09T20:04:21.495Z",
    "size": 64,
    "path": "../public/_nuxt/Bfm7aUt1.js"
  },
  "/_nuxt/BqQU43AW.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2cfd-dnDuv2QczUvF+hwpV13WeI8vN1s\"",
    "mtime": "2026-04-09T20:04:21.495Z",
    "size": 11517,
    "path": "../public/_nuxt/BqQU43AW.js"
  },
  "/_nuxt/BpzbH_zM.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"616-xea8mqFJyzrsGKTbBMvWw0o0f1M\"",
    "mtime": "2026-04-09T20:04:21.495Z",
    "size": 1558,
    "path": "../public/_nuxt/BpzbH_zM.js"
  },
  "/_nuxt/BrRPlvzI.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"312c-f6NQDyT7GsrD0PMNg7b+xYydy5A\"",
    "mtime": "2026-04-09T20:04:21.495Z",
    "size": 12588,
    "path": "../public/_nuxt/BrRPlvzI.js"
  },
  "/_nuxt/BtfJf_l8.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2302-asvgWDA0Xe3fGgjTVt2C0otIjJU\"",
    "mtime": "2026-04-09T20:04:21.495Z",
    "size": 8962,
    "path": "../public/_nuxt/BtfJf_l8.js"
  },
  "/_nuxt/BwIYJI37.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"19c2-FgDpPYXKl/YdY91iX8w9d95M/zE\"",
    "mtime": "2026-04-09T20:04:21.495Z",
    "size": 6594,
    "path": "../public/_nuxt/BwIYJI37.js"
  },
  "/_nuxt/ByAq7W2H.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1b9-EXBnJQvm3alxD0/rdLC5vfPbXSs\"",
    "mtime": "2026-04-09T20:04:21.496Z",
    "size": 441,
    "path": "../public/_nuxt/ByAq7W2H.js"
  },
  "/_nuxt/ByzwqLUz.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"239e-OKLNYIInr+FlkZss3rGwLzzxdkw\"",
    "mtime": "2026-04-09T20:04:21.496Z",
    "size": 9118,
    "path": "../public/_nuxt/ByzwqLUz.js"
  },
  "/_nuxt/C1USUhYM.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1c1-FiJdxnrFjv20m3jZyeZrtAJ9dPA\"",
    "mtime": "2026-04-09T20:04:21.496Z",
    "size": 449,
    "path": "../public/_nuxt/C1USUhYM.js"
  },
  "/_nuxt/C42ngxPz.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3362-6S0mQLXzyyRuvsdj6AHcM4d8hok\"",
    "mtime": "2026-04-09T20:04:21.496Z",
    "size": 13154,
    "path": "../public/_nuxt/C42ngxPz.js"
  },
  "/_nuxt/C4KM5xgT.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"e99-Qlg1o03f3xHwV47JM6dSA0Od2Ok\"",
    "mtime": "2026-04-09T20:04:21.496Z",
    "size": 3737,
    "path": "../public/_nuxt/C4KM5xgT.js"
  },
  "/_nuxt/C5oyUuCu.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"239c-CuV9Z41fCKUcv/e5Ra9tX03YJ6I\"",
    "mtime": "2026-04-09T20:04:21.496Z",
    "size": 9116,
    "path": "../public/_nuxt/C5oyUuCu.js"
  },
  "/_nuxt/CB74Pm_V.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"234a-+CHiGklSVpbTbQayGAKL57C3PTo\"",
    "mtime": "2026-04-09T20:04:21.496Z",
    "size": 9034,
    "path": "../public/_nuxt/CB74Pm_V.js"
  },
  "/_nuxt/CBSH8DvJ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1c61-SgXM5bUv/YBhIZTx5hpMIP93/Ws\"",
    "mtime": "2026-04-09T20:04:21.496Z",
    "size": 7265,
    "path": "../public/_nuxt/CBSH8DvJ.js"
  },
  "/_nuxt/CEsmrA7x.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2986-4gPzWHqoTsIJlUYTqTer95okUJc\"",
    "mtime": "2026-04-09T20:04:21.496Z",
    "size": 10630,
    "path": "../public/_nuxt/CEsmrA7x.js"
  },
  "/_nuxt/C8vJp5uv.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2229-xvGP48VUpCVfg6VJM4VOHJ4hn6M\"",
    "mtime": "2026-04-09T20:04:21.496Z",
    "size": 8745,
    "path": "../public/_nuxt/C8vJp5uv.js"
  },
  "/_nuxt/CUeniG4B.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"310-5FpsqHGMiss4QSXEksnjk94M1Vo\"",
    "mtime": "2026-04-09T20:04:21.496Z",
    "size": 784,
    "path": "../public/_nuxt/CUeniG4B.js"
  },
  "/_nuxt/CYknpjSB.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2064-vsNcqfuh211gTARdwtpP/m2Uues\"",
    "mtime": "2026-04-09T20:04:21.496Z",
    "size": 8292,
    "path": "../public/_nuxt/CYknpjSB.js"
  },
  "/_nuxt/CYsg4uL0.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"543-yez/r6nMChgYxlCadIlkscIcscY\"",
    "mtime": "2026-04-09T20:04:21.496Z",
    "size": 1347,
    "path": "../public/_nuxt/CYsg4uL0.js"
  },
  "/_nuxt/CYh88bqD.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"b8a-mGKj5vSsp4GOLl78KSSERILQR64\"",
    "mtime": "2026-04-09T20:04:21.496Z",
    "size": 2954,
    "path": "../public/_nuxt/CYh88bqD.js"
  },
  "/_nuxt/CvVeLb4s.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1af7-k39RqJOMLqxwgLStY3mMUZ0xOFc\"",
    "mtime": "2026-04-09T20:04:21.497Z",
    "size": 6903,
    "path": "../public/_nuxt/CvVeLb4s.js"
  },
  "/_nuxt/Cdz21DFl.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"17d4-XyxD14zkSSDKe3K5peRUUvYgR/8\"",
    "mtime": "2026-04-09T20:04:21.496Z",
    "size": 6100,
    "path": "../public/_nuxt/Cdz21DFl.js"
  },
  "/_nuxt/D-WZflOs.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1b6b-9co6wAhzIa5SJfCP5iI7UQxDb8U\"",
    "mtime": "2026-04-09T20:04:21.497Z",
    "size": 7019,
    "path": "../public/_nuxt/D-WZflOs.js"
  },
  "/_nuxt/D-3pioZg.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"166e-K1dAfYe3BxesPyjAqKBO4yWtx6M\"",
    "mtime": "2026-04-09T20:04:21.497Z",
    "size": 5742,
    "path": "../public/_nuxt/D-3pioZg.js"
  },
  "/_nuxt/D-XWrnEk.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"160a-6PepkIjAcfP9DLk8lpE+3ctN0H8\"",
    "mtime": "2026-04-09T20:04:21.497Z",
    "size": 5642,
    "path": "../public/_nuxt/D-XWrnEk.js"
  },
  "/_nuxt/D3Sie-ul.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1995-pMf9DT7dtDrjar3PSqzl+tjCitU\"",
    "mtime": "2026-04-09T20:04:21.497Z",
    "size": 6549,
    "path": "../public/_nuxt/D3Sie-ul.js"
  },
  "/_nuxt/D2_K0QDS.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"a08-qhz0DTsu8znemc8Q43gv3e6M0BM\"",
    "mtime": "2026-04-09T20:04:21.497Z",
    "size": 2568,
    "path": "../public/_nuxt/D2_K0QDS.js"
  },
  "/_nuxt/D5JBjp5f.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1458-W80Ma89n7zxT+oKa0NnSzI+yty8\"",
    "mtime": "2026-04-09T20:04:21.497Z",
    "size": 5208,
    "path": "../public/_nuxt/D5JBjp5f.js"
  },
  "/_nuxt/DJtPTz7f.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1e9d-XIzjhTRtWKS7HSKg2kZVPm+bHdI\"",
    "mtime": "2026-04-09T20:04:21.497Z",
    "size": 7837,
    "path": "../public/_nuxt/DJtPTz7f.js"
  },
  "/_nuxt/CmJfFmyd.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"5c1a2-EsPtk5V0Yhc4Dr1tXTGpCnNOm4s\"",
    "mtime": "2026-04-09T20:04:21.497Z",
    "size": 377250,
    "path": "../public/_nuxt/CmJfFmyd.js"
  },
  "/_nuxt/DPrvLcff.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"79ce-IZ7emIlqnI7NkUAIvuAmiSzu6oY\"",
    "mtime": "2026-04-09T20:04:21.497Z",
    "size": 31182,
    "path": "../public/_nuxt/DPrvLcff.js"
  },
  "/_nuxt/DUK7OCSe.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1a1e-SsVYpAutf+s35aDwKEdIu67kzlM\"",
    "mtime": "2026-04-09T20:04:21.497Z",
    "size": 6686,
    "path": "../public/_nuxt/DUK7OCSe.js"
  },
  "/_nuxt/DVoaqQ5Y.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"33be-PvMzfkKibufHT5x1Nb/4wKg3wMw\"",
    "mtime": "2026-04-09T20:04:21.497Z",
    "size": 13246,
    "path": "../public/_nuxt/DVoaqQ5Y.js"
  },
  "/_nuxt/DdyNhaqJ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"15f2-tNWfZaoD+I7gt2pM0fy11MZBRtU\"",
    "mtime": "2026-04-09T20:04:21.497Z",
    "size": 5618,
    "path": "../public/_nuxt/DdyNhaqJ.js"
  },
  "/_nuxt/Dhv3xS7P.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2cdb-eiY7+R0RDWhOLVtgaEWuh7j98aM\"",
    "mtime": "2026-04-09T20:04:21.497Z",
    "size": 11483,
    "path": "../public/_nuxt/Dhv3xS7P.js"
  },
  "/_nuxt/Dhz4NgUG.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"423-yDA1aJ8B/KRUemQr0qJDe72fGdI\"",
    "mtime": "2026-04-09T20:04:21.497Z",
    "size": 1059,
    "path": "../public/_nuxt/Dhz4NgUG.js"
  },
  "/_nuxt/DnWR7tJz.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"236a-GcrxWuFPGemu2jWq5BqGwM2Kf/4\"",
    "mtime": "2026-04-09T20:04:21.497Z",
    "size": 9066,
    "path": "../public/_nuxt/DnWR7tJz.js"
  },
  "/_nuxt/DnjoQW_X.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1a23-kFeXuJFQpaVme3b0XMB6YWXOu0k\"",
    "mtime": "2026-04-09T20:04:21.497Z",
    "size": 6691,
    "path": "../public/_nuxt/DnjoQW_X.js"
  },
  "/_nuxt/DrVYZR4W.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"713-ObZglgZuhfMkmLVUarIfRvb/edQ\"",
    "mtime": "2026-04-09T20:04:21.497Z",
    "size": 1811,
    "path": "../public/_nuxt/DrVYZR4W.js"
  },
  "/_nuxt/Drc5L-Z-.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1bbd-mFCTexSZFXV2ILcy7jr33cnuvrw\"",
    "mtime": "2026-04-09T20:04:21.497Z",
    "size": 7101,
    "path": "../public/_nuxt/Drc5L-Z-.js"
  },
  "/_nuxt/DsCYkMz4.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"275f-xxjC7Z8V0CaMDMMP3jDL61odIG8\"",
    "mtime": "2026-04-09T20:04:21.497Z",
    "size": 10079,
    "path": "../public/_nuxt/DsCYkMz4.js"
  },
  "/_nuxt/DzJq5ivm.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"170f-pV09Az68omelGxdot8geESQ3X84\"",
    "mtime": "2026-04-09T20:04:21.497Z",
    "size": 5903,
    "path": "../public/_nuxt/DzJq5ivm.js"
  },
  "/_nuxt/IRCwmATj.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"238d-bHU54glAwZ7CGXxVzZOYyfh1Fyk\"",
    "mtime": "2026-04-09T20:04:21.498Z",
    "size": 9101,
    "path": "../public/_nuxt/IRCwmATj.js"
  },
  "/_nuxt/P-gJzvLc.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"195e-SZnw+dxSQW9iA52+eltvqeYFHag\"",
    "mtime": "2026-04-09T20:04:21.498Z",
    "size": 6494,
    "path": "../public/_nuxt/P-gJzvLc.js"
  },
  "/_nuxt/QqYViJ1z.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"33a0-Kkgz4F+0mKG6143qnPI47In2af4\"",
    "mtime": "2026-04-09T20:04:21.498Z",
    "size": 13216,
    "path": "../public/_nuxt/QqYViJ1z.js"
  },
  "/_nuxt/Tq4A_9nl.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"75e-lpnXw9tFCbQZo9pUTl1YxgrDhf0\"",
    "mtime": "2026-04-09T20:04:21.498Z",
    "size": 1886,
    "path": "../public/_nuxt/Tq4A_9nl.js"
  },
  "/_nuxt/WXZk61fE.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"20ff-OMESeBgGCeBprBtIPQHhsOQXvCc\"",
    "mtime": "2026-04-09T20:04:21.498Z",
    "size": 8447,
    "path": "../public/_nuxt/WXZk61fE.js"
  },
  "/_nuxt/ZwOdMfFB.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"79-oA3vhZO2QZI7kTI5auUHmZRNgQ8\"",
    "mtime": "2026-04-09T20:04:21.498Z",
    "size": 121,
    "path": "../public/_nuxt/ZwOdMfFB.js"
  },
  "/_nuxt/cmHV_WsO.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"ea3-2pYJiyEBVEjpdngAK4o31I2IyaE\"",
    "mtime": "2026-04-09T20:04:21.498Z",
    "size": 3747,
    "path": "../public/_nuxt/cmHV_WsO.js"
  },
  "/_nuxt/eRkO_JMe.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"35c-/P57F2J+0adA7OrrcgYqP9z6URQ\"",
    "mtime": "2026-04-09T20:04:21.498Z",
    "size": 860,
    "path": "../public/_nuxt/eRkO_JMe.js"
  },
  "/_nuxt/entry.CItbgnJL.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"2f8f3-GFDh4k380Q2N7GCbwyBFup/zrhE\"",
    "mtime": "2026-04-09T20:04:21.498Z",
    "size": 194803,
    "path": "../public/_nuxt/entry.CItbgnJL.css"
  },
  "/_nuxt/error-404._yXoGkXB.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"97e-UvhxUpGzrIO+HDYB4qU9Txgu35A\"",
    "mtime": "2026-04-09T20:04:21.498Z",
    "size": 2430,
    "path": "../public/_nuxt/error-404._yXoGkXB.css"
  },
  "/_nuxt/error-500.BENb_mjk.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"773-BFLUend+w1t3SP3QDB+Z0A0V5pI\"",
    "mtime": "2026-04-09T20:04:21.498Z",
    "size": 1907,
    "path": "../public/_nuxt/error-500.BENb_mjk.css"
  },
  "/_nuxt/index.BrlKYhX7.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"a4-/+b1tgyiOrYWO63/Pk4tHiKxnU4\"",
    "mtime": "2026-04-09T20:04:21.498Z",
    "size": 164,
    "path": "../public/_nuxt/index.BrlKYhX7.css"
  },
  "/_nuxt/jX0Dxh-s.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"d7b-7mqSAvCDeEmf3WPqkAsq/XC6oiU\"",
    "mtime": "2026-04-09T20:04:21.498Z",
    "size": 3451,
    "path": "../public/_nuxt/jX0Dxh-s.js"
  },
  "/_nuxt/manager.B97u2gOC.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"a4-jCYmFMXrBDnLUC1m0yZsS3orr1E\"",
    "mtime": "2026-04-09T20:04:21.498Z",
    "size": 164,
    "path": "../public/_nuxt/manager.B97u2gOC.css"
  },
  "/_nuxt/l0AwP-lb.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1de9-UGGfUSE01RqQ3VE5HxBkNwhb6IE\"",
    "mtime": "2026-04-09T20:04:21.498Z",
    "size": 7657,
    "path": "../public/_nuxt/l0AwP-lb.js"
  },
  "/_nuxt/realtime-panel.CG6gqERi.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"b8-4Anhkv/eKsf8VAZ24xft9m9aHLw\"",
    "mtime": "2026-04-09T20:04:21.498Z",
    "size": 184,
    "path": "../public/_nuxt/realtime-panel.CG6gqERi.css"
  },
  "/_nuxt/builds/latest.json": {
    "type": "application/json",
    "etag": "\"47-GmhYDEXb9VTs139NxDezhM3Zdng\"",
    "mtime": "2026-04-09T20:04:21.487Z",
    "size": 71,
    "path": "../public/_nuxt/builds/latest.json"
  },
  "/_nuxt/zW78t1Dq.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1dce-wrGSQyxuPMhlCgYI3a7HP0RZLBk\"",
    "mtime": "2026-04-09T20:04:21.498Z",
    "size": 7630,
    "path": "../public/_nuxt/zW78t1Dq.js"
  },
  "/_nuxt/builds/meta/657bbfe8-f58c-4e57-9e3c-404d4f80083f.json": {
    "type": "application/json",
    "etag": "\"58-EFw4Rh1MskGLXnrqaRIKKP7+IiU\"",
    "mtime": "2026-04-09T20:04:21.485Z",
    "size": 88,
    "path": "../public/_nuxt/builds/meta/657bbfe8-f58c-4e57-9e3c-404d4f80083f.json"
  }
};

const _DRIVE_LETTER_START_RE = /^[A-Za-z]:\//;
function normalizeWindowsPath(input = "") {
  if (!input) {
    return input;
  }
  return input.replace(/\\/g, "/").replace(_DRIVE_LETTER_START_RE, (r) => r.toUpperCase());
}
const _IS_ABSOLUTE_RE = /^[/\\](?![/\\])|^[/\\]{2}(?!\.)|^[A-Za-z]:[/\\]/;
const _DRIVE_LETTER_RE = /^[A-Za-z]:$/;
function cwd() {
  if (typeof process !== "undefined" && typeof process.cwd === "function") {
    return process.cwd().replace(/\\/g, "/");
  }
  return "/";
}
const resolve = function(...arguments_) {
  arguments_ = arguments_.map((argument) => normalizeWindowsPath(argument));
  let resolvedPath = "";
  let resolvedAbsolute = false;
  for (let index = arguments_.length - 1; index >= -1 && !resolvedAbsolute; index--) {
    const path = index >= 0 ? arguments_[index] : cwd();
    if (!path || path.length === 0) {
      continue;
    }
    resolvedPath = `${path}/${resolvedPath}`;
    resolvedAbsolute = isAbsolute(path);
  }
  resolvedPath = normalizeString(resolvedPath, !resolvedAbsolute);
  if (resolvedAbsolute && !isAbsolute(resolvedPath)) {
    return `/${resolvedPath}`;
  }
  return resolvedPath.length > 0 ? resolvedPath : ".";
};
function normalizeString(path, allowAboveRoot) {
  let res = "";
  let lastSegmentLength = 0;
  let lastSlash = -1;
  let dots = 0;
  let char = null;
  for (let index = 0; index <= path.length; ++index) {
    if (index < path.length) {
      char = path[index];
    } else if (char === "/") {
      break;
    } else {
      char = "/";
    }
    if (char === "/") {
      if (lastSlash === index - 1 || dots === 1) ; else if (dots === 2) {
        if (res.length < 2 || lastSegmentLength !== 2 || res[res.length - 1] !== "." || res[res.length - 2] !== ".") {
          if (res.length > 2) {
            const lastSlashIndex = res.lastIndexOf("/");
            if (lastSlashIndex === -1) {
              res = "";
              lastSegmentLength = 0;
            } else {
              res = res.slice(0, lastSlashIndex);
              lastSegmentLength = res.length - 1 - res.lastIndexOf("/");
            }
            lastSlash = index;
            dots = 0;
            continue;
          } else if (res.length > 0) {
            res = "";
            lastSegmentLength = 0;
            lastSlash = index;
            dots = 0;
            continue;
          }
        }
        if (allowAboveRoot) {
          res += res.length > 0 ? "/.." : "..";
          lastSegmentLength = 2;
        }
      } else {
        if (res.length > 0) {
          res += `/${path.slice(lastSlash + 1, index)}`;
        } else {
          res = path.slice(lastSlash + 1, index);
        }
        lastSegmentLength = index - lastSlash - 1;
      }
      lastSlash = index;
      dots = 0;
    } else if (char === "." && dots !== -1) {
      ++dots;
    } else {
      dots = -1;
    }
  }
  return res;
}
const isAbsolute = function(p) {
  return _IS_ABSOLUTE_RE.test(p);
};
const dirname = function(p) {
  const segments = normalizeWindowsPath(p).replace(/\/$/, "").split("/").slice(0, -1);
  if (segments.length === 1 && _DRIVE_LETTER_RE.test(segments[0])) {
    segments[0] += "/";
  }
  return segments.join("/") || (isAbsolute(p) ? "/" : ".");
};
const basename = function(p, extension) {
  const segments = normalizeWindowsPath(p).split("/");
  let lastSegment = "";
  for (let i = segments.length - 1; i >= 0; i--) {
    const val = segments[i];
    if (val) {
      lastSegment = val;
      break;
    }
  }
  return extension && lastSegment.endsWith(extension) ? lastSegment.slice(0, -extension.length) : lastSegment;
};

function readAsset (id) {
  const serverDir = dirname(fileURLToPath$1(globalThis._importMeta_.url));
  return promises.readFile(resolve(serverDir, assets[id].path))
}

const publicAssetBases = {"/_nuxt/builds/meta/":{"maxAge":31536000},"/_nuxt/builds/":{"maxAge":1},"/_fonts/":{"maxAge":31536000},"/_nuxt/":{"maxAge":31536000}};

function isPublicAssetURL(id = '') {
  if (assets[id]) {
    return true
  }
  for (const base in publicAssetBases) {
    if (id.startsWith(base)) { return true }
  }
  return false
}

function getAsset (id) {
  return assets[id]
}

const METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
const EncodingMap = { gzip: ".gz", br: ".br" };
const _6kOD1J = eventHandler((event) => {
  if (event.method && !METHODS.has(event.method)) {
    return;
  }
  let id = decodePath(
    withLeadingSlash(withoutTrailingSlash(parseURL(event.path).pathname))
  );
  let asset;
  const encodingHeader = String(
    getRequestHeader(event, "accept-encoding") || ""
  );
  const encodings = [
    ...encodingHeader.split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(),
    ""
  ];
  for (const encoding of encodings) {
    for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
      const _asset = getAsset(_id);
      if (_asset) {
        asset = _asset;
        id = _id;
        break;
      }
    }
  }
  if (!asset) {
    if (isPublicAssetURL(id)) {
      removeResponseHeader(event, "Cache-Control");
      throw createError$1({ statusCode: 404 });
    }
    return;
  }
  if (asset.encoding !== void 0) {
    appendResponseHeader(event, "Vary", "Accept-Encoding");
  }
  const ifNotMatch = getRequestHeader(event, "if-none-match") === asset.etag;
  if (ifNotMatch) {
    setResponseStatus(event, 304, "Not Modified");
    return "";
  }
  const ifModifiedSinceH = getRequestHeader(event, "if-modified-since");
  const mtimeDate = new Date(asset.mtime);
  if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
    setResponseStatus(event, 304, "Not Modified");
    return "";
  }
  if (asset.type && !getResponseHeader(event, "Content-Type")) {
    setResponseHeader(event, "Content-Type", asset.type);
  }
  if (asset.etag && !getResponseHeader(event, "ETag")) {
    setResponseHeader(event, "ETag", asset.etag);
  }
  if (asset.mtime && !getResponseHeader(event, "Last-Modified")) {
    setResponseHeader(event, "Last-Modified", mtimeDate.toUTCString());
  }
  if (asset.encoding && !getResponseHeader(event, "Content-Encoding")) {
    setResponseHeader(event, "Content-Encoding", asset.encoding);
  }
  if (asset.size > 0 && !getResponseHeader(event, "Content-Length")) {
    setResponseHeader(event, "Content-Length", asset.size);
  }
  return readAsset(id);
});

const _nL1EmJ = defineEventHandler((event) => {
  const path = getRequestURL(event).pathname;
  if (path.startsWith("/api/license/") || path === "/api/auth/login" || path === "/api/auth/me" || !path.startsWith("/api/")) {
    return;
  }
  if (!isLicenseValid()) {
    throw createError$1({
      statusCode: 403,
      statusMessage: "No valid license. Please activate your SoftCall Plus license."
    });
  }
});

const _SxA8c9 = defineEventHandler(() => {});

function defineRenderHandler(render) {
  const runtimeConfig = useRuntimeConfig();
  return eventHandler(async (event) => {
    const nitroApp = useNitroApp();
    const ctx = { event, render, response: void 0 };
    await nitroApp.hooks.callHook("render:before", ctx);
    if (!ctx.response) {
      if (event.path === `${runtimeConfig.app.baseURL}favicon.ico`) {
        setResponseHeader(event, "Content-Type", "image/x-icon");
        return send(
          event,
          "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
        );
      }
      ctx.response = await ctx.render(event);
      if (!ctx.response) {
        const _currentStatus = getResponseStatus(event);
        setResponseStatus(event, _currentStatus === 200 ? 500 : _currentStatus);
        return send(
          event,
          "No response returned from render handler: " + event.path
        );
      }
    }
    await nitroApp.hooks.callHook("render:response", ctx.response, ctx);
    if (ctx.response.headers) {
      setResponseHeaders(event, ctx.response.headers);
    }
    if (ctx.response.statusCode || ctx.response.statusMessage) {
      setResponseStatus(
        event,
        ctx.response.statusCode,
        ctx.response.statusMessage
      );
    }
    return ctx.response.body;
  });
}

function baseURL() {
	// TODO: support passing event to `useRuntimeConfig`
	return useRuntimeConfig().app.baseURL;
}
function buildAssetsDir() {
	// TODO: support passing event to `useRuntimeConfig`
	return useRuntimeConfig().app.buildAssetsDir;
}
function buildAssetsURL(...path) {
	return joinRelativeURL(publicAssetsURL(), buildAssetsDir(), ...path);
}
function publicAssetsURL(...path) {
	// TODO: support passing event to `useRuntimeConfig`
	const app = useRuntimeConfig().app;
	const publicBase = app.cdnURL || app.baseURL;
	return path.length ? joinRelativeURL(publicBase, ...path) : publicBase;
}

const getTodayAbandonedStats = async () => {
  const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  const rows = await mysqlQuery(
    `SELECT
       COUNT(DISTINCT channel) AS total_calls,
       COUNT(DISTINCT CASE WHEN disposition = 'ANSWERED' THEN channel END) AS answered_calls
     FROM cdr
     WHERE calldate >= '${today} 00:00:00'
       AND channel NOT LIKE 'Local/%'
       AND lastapp IN ('Queue', 'Dial')`,
    "asteriskcdrdb"
  );
  if (!rows.length || !rows[0]) {
    return { totalInbound: 0, answered: 0, abandoned: 0, abandonRate: 0 };
  }
  const parts = rows[0].split("	");
  const totalInbound = parseInt(parts[0]) || 0;
  parseInt(parts[1]) || 0;
  const abandonedRows = await mysqlQuery(
    `SELECT COUNT(*) FROM (
       SELECT channel
       FROM cdr
       WHERE calldate >= '${today} 00:00:00'
         AND channel NOT LIKE 'Local/%'
         AND lastapp IN ('Queue', 'Dial')
       GROUP BY channel
       HAVING SUM(CASE WHEN disposition = 'ANSWERED' THEN 1 ELSE 0 END) = 0
     ) AS abandoned_calls`,
    "asteriskcdrdb"
  );
  const abandoned = parseInt(abandonedRows[0] || "0");
  return {
    totalInbound,
    answered: totalInbound - abandoned,
    abandoned,
    abandonRate: totalInbound > 0 ? Math.round(abandoned / totalInbound * 100) : 0
  };
};
const getTodayQueueAbandonedStats = async () => {
  const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  const rows = await mysqlQuery(
    `SELECT
       SUBSTRING_INDEX(lastdata, ',', 1) AS queue_name,
       channel,
       MAX(CASE WHEN disposition = 'ANSWERED' THEN 1 ELSE 0 END) AS was_answered
     FROM cdr
     WHERE calldate >= '${today} 00:00:00'
       AND channel NOT LIKE 'Local/%'
       AND lastapp = 'Queue'
       AND lastdata != ''
     GROUP BY queue_name, channel`,
    "asteriskcdrdb"
  );
  const queueMap = /* @__PURE__ */ new Map();
  for (const row of rows) {
    const parts = row.split("	");
    const queueName = parts[0] || "";
    const wasAnswered = parseInt(parts[2] || "0");
    if (!queueName) continue;
    if (!queueMap.has(queueName)) {
      queueMap.set(queueName, { total: 0, answered: 0 });
    }
    const stats = queueMap.get(queueName);
    stats.total++;
    if (wasAnswered) stats.answered++;
  }
  const result = [];
  for (const [queue, stats] of queueMap) {
    const abandoned = stats.total - stats.answered;
    result.push({
      queue,
      totalCalls: stats.total,
      answered: stats.answered,
      abandoned,
      abandonRate: stats.total > 0 ? Math.round(abandoned / stats.total * 100) : 0
    });
  }
  return result;
};
const getAbandonedStatsForRange = async (startDate, endDate) => {
  const abandonedRows = await mysqlQuery(
    `SELECT COUNT(*) FROM (
       SELECT channel
       FROM cdr
       WHERE calldate >= '${startDate}'
         AND calldate <= '${endDate}'
         AND channel NOT LIKE 'Local/%'
         AND lastapp IN ('Queue', 'Dial')
       GROUP BY channel
       HAVING SUM(CASE WHEN disposition = 'ANSWERED' THEN 1 ELSE 0 END) = 0
     ) AS abandoned_calls`,
    "asteriskcdrdb"
  );
  const totalRows = await mysqlQuery(
    `SELECT COUNT(DISTINCT channel) FROM cdr
     WHERE calldate >= '${startDate}'
       AND calldate <= '${endDate}'
       AND channel NOT LIKE 'Local/%'
       AND lastapp IN ('Queue', 'Dial')`,
    "asteriskcdrdb"
  );
  const abandoned = parseInt(abandonedRows[0] || "0");
  const totalInbound = parseInt(totalRows[0] || "0");
  const answered = totalInbound - abandoned;
  return {
    totalInbound,
    answered,
    abandoned,
    abandonRate: totalInbound > 0 ? Math.round(abandoned / totalInbound * 100) : 0
  };
};
const getQueueLogAbandoned = async () => {
  const result = /* @__PURE__ */ new Map();
  const todayStart = Math.floor((/* @__PURE__ */ new Date()).setHours(0, 0, 0, 0) / 1e3);
  try {
    const content = await readFile$1("/var/log/asterisk/queue_log", "utf-8");
    const seenCallIds = /* @__PURE__ */ new Set();
    for (const line of content.split("\n")) {
      if (!line) continue;
      const parts = line.split("|");
      if (parts.length < 5) continue;
      const timestamp = parseInt(parts[0]);
      if (timestamp < todayStart) continue;
      const callId = parts[1];
      const queue = parts[2];
      const event = parts[4];
      if (event === "ABANDON") {
        const key = `${callId}:${queue}`;
        if (!seenCallIds.has(key)) {
          seenCallIds.add(key);
          result.set(queue, (result.get(queue) || 0) + 1);
        }
      }
    }
  } catch {
  }
  return result;
};
const getBestQueueAbandoned = async (asteriskCounts) => {
  const cdrStats = await getTodayQueueAbandonedStats();
  const queueLogCounts = await getQueueLogAbandoned();
  const result = /* @__PURE__ */ new Map();
  const allQueues = /* @__PURE__ */ new Set([
    ...cdrStats.map((s) => s.queue),
    ...queueLogCounts.keys(),
    ...asteriskCounts.keys()
  ]);
  for (const queue of allQueues) {
    const cdrStat = cdrStats.find((s) => s.queue === queue);
    const qlogCount = queueLogCounts.get(queue) || 0;
    const astCount = asteriskCounts.get(queue) || 0;
    if (cdrStat && cdrStat.totalCalls > 0) {
      result.set(queue, cdrStat.abandoned);
    } else {
      result.set(queue, Math.max(qlogCount, astCount));
    }
  }
  return result;
};

const DB = "/var/www/db/acl.db";
const sqliteQuery$1 = async (query) => {
  const result = await execCmd("sqlite3", [DB, query]);
  if (result.code !== 0) return [];
  return result.stdout.trim().split("\n").filter(Boolean);
};
const sqliteExec = async (query) => {
  const result = await execCmd("sqlite3", [DB, query]);
  return { ok: result.code === 0, error: result.stderr };
};
const listGroups = async () => {
  const rows = await sqliteQuery$1("SELECT id, name, description FROM acl_group ORDER BY id");
  return rows.map((r) => {
    const [id, name, description] = r.split("|");
    return { id: parseInt(id), name, description: description || "" };
  });
};
const createGroup = async (name, description) => {
  var _a;
  const res = await sqliteExec(`INSERT INTO acl_group (name, description) VALUES ('${name}','${description}')`);
  if (!res.ok) return { ok: false, error: res.error };
  const rows = await sqliteQuery$1(`SELECT id FROM acl_group WHERE name='${name}'`);
  return { ok: true, id: parseInt((_a = rows[0]) != null ? _a : "0") };
};
const updateGroup = async (id, name, description) => {
  return sqliteExec(`UPDATE acl_group SET name='${name}', description='${description}' WHERE id=${id}`);
};
const deleteGroup = async (id) => {
  var _a;
  const members = await sqliteQuery$1(`SELECT COUNT(*) FROM acl_membership WHERE id_group=${id}`);
  const count = parseInt((_a = members[0]) != null ? _a : "0");
  if (count > 0) return { ok: false, error: "Group has users assigned. Remove users from group first." };
  await sqliteExec(`DELETE FROM acl_group_permission WHERE id_group=${id}`);
  await sqliteExec(`DELETE FROM acl_module_group_permissions WHERE id_group=${id}`);
  return sqliteExec(`DELETE FROM acl_group WHERE id=${id}`);
};
const listResources = async () => {
  const rows = await sqliteQuery$1("SELECT id, name, description FROM acl_resource ORDER BY name");
  return rows.map((r) => {
    const [id, name, description] = r.split("|");
    return { id: parseInt(id), name, description: description || name };
  });
};
const getGroupPermissions = async (groupId) => {
  const rows = await sqliteQuery$1(
    `SELECT gp.id_resource, r.name, r.description, a.name AS action_name
     FROM acl_group_permission gp
     JOIN acl_resource r ON gp.id_resource=r.id
     JOIN acl_action a ON gp.id_action=a.id
     WHERE gp.id_group=${groupId}
     ORDER BY r.name`
  );
  const perms = /* @__PURE__ */ new Map();
  for (const row of rows) {
    const [resId, resName, desc, action] = row.split("|");
    const rid = parseInt(resId);
    if (!perms.has(rid)) {
      perms.set(rid, { resourceId: rid, resourceName: resName, description: desc || resName, actions: [] });
    }
    perms.get(rid).actions.push(action);
  }
  return Array.from(perms.values());
};
const setGroupPermissions = async (groupId, resourceIds) => {
  await sqliteExec(`DELETE FROM acl_group_permission WHERE id_group=${groupId}`);
  const accessActionId = 1;
  for (const resId of resourceIds) {
    await sqliteExec(
      `INSERT INTO acl_group_permission (id_action, id_group, id_resource) VALUES (${accessActionId},${groupId},${resId})`
    );
  }
  if (groupId === 1) {
    const protectedResources = ["usermgr", "grouplist", "userlist", "group_permission"];
    for (const resName of protectedResources) {
      const rows = await sqliteQuery$1(`SELECT id FROM acl_resource WHERE name='${resName}'`);
      if (rows.length) {
        const resId = parseInt(rows[0]);
        if (!resourceIds.includes(resId)) {
          await sqliteExec(
            `INSERT INTO acl_group_permission (id_action, id_group, id_resource) VALUES (${accessActionId},1,${resId})`
          );
        }
      }
    }
  }
  return { ok: true };
};
const getAllModulePrivileges = async () => {
  const rows = await sqliteQuery$1(
    `SELECT mp.id, mp.privilege, mp.desc_privilege, r.name AS module, r.description AS module_desc
     FROM acl_module_privileges mp
     JOIN acl_resource r ON mp.id_resource = r.id
     ORDER BY r.name, mp.id`
  );
  const grouped = /* @__PURE__ */ new Map();
  for (const row of rows) {
    const [id, privilege, desc, module, moduleDesc] = row.split("|");
    if (!grouped.has(module)) {
      grouped.set(module, { module, moduleDesc: moduleDesc || module, privileges: [] });
    }
    grouped.get(module).privileges.push({ id: parseInt(id), privilege, description: desc || privilege });
  }
  return Array.from(grouped.values());
};
const getGroupModulePrivileges = async (groupId) => {
  const rows = await sqliteQuery$1(
    `SELECT mgp.id_module_privilege
     FROM acl_module_group_permissions mgp
     WHERE mgp.id_group = ${groupId}`
  );
  return rows.map((r) => parseInt(r.split("|")[0] || r));
};
const setGroupModulePrivileges = async (groupId, privilegeIds) => {
  await sqliteExec(`DELETE FROM acl_module_group_permissions WHERE id_group=${groupId}`);
  for (const pid of privilegeIds) {
    await sqliteExec(
      `INSERT INTO acl_module_group_permissions (id_group, id_module_privilege) VALUES (${groupId},${pid})`
    );
  }
  return { ok: true };
};

const STALE_THRESHOLD_MS = 6e4;
const heartbeats = /* @__PURE__ */ new Map();
function recordHeartbeat(agentId, extension) {
  heartbeats.set(agentId, { lastBeat: Date.now(), extension });
}
function removeHeartbeat(agentId) {
  heartbeats.delete(agentId);
}
const MEMBER_INTERFACES = (ext) => [
  `Local/${ext}@from-queue/n`,
  `SIP/${ext}`,
  `PJSIP/${ext}`,
  `IAX2/${ext}`
];
async function getAssignedQueues(ext) {
  const allQueues = await mysqlQuery("SELECT extension FROM queues_config ORDER BY extension");
  const assigned = [];
  for (const qRow of allQueues) {
    const qExt = qRow.trim();
    if (!qExt) continue;
    const staticRows = await mysqlQuery(
      `SELECT id FROM queues_details WHERE keyword='member' AND id='${qExt}' AND (data LIKE '%Local/${ext}@%' OR data LIKE '%SIP/${ext}%' OR data LIKE '%PJSIP/${ext}%' OR data LIKE '%IAX2/${ext}%')`
    );
    if (staticRows.length) {
      assigned.push(qExt);
      continue;
    }
    try {
      const result = await execCmd("asterisk", ["-rx", `database show QPENALTY/${qExt}/agents/${ext}`]);
      const dbOut = `${result.stdout}
${result.stderr}`;
      if (!dbOut.includes("0 results found") && !dbOut.includes("not found") && dbOut.includes(ext)) {
        assigned.push(qExt);
      }
    } catch {
    }
  }
  return assigned;
}
async function pauseInAllQueues(ext, reason) {
  const assigned = await getAssignedQueues(ext);
  let count = 0;
  const esc = (s) => (s || "").replace(/'/g, "\\'");
  for (const q of assigned) {
    for (const iface of MEMBER_INTERFACES(ext)) {
      try {
        await execCmd("asterisk", ["-rx", `queue pause member ${iface} queue ${q} reason "${esc(reason)}"`]);
        count++;
      } catch {
      }
    }
  }
  return count;
}
async function closeStaleSession(agentId) {
  const entry = heartbeats.get(agentId);
  const ext = entry == null ? void 0 : entry.extension;
  if (ext) {
    try {
      const paused = await pauseInAllQueues(ext, "Session timeout");
      console.log(`[Heartbeat] Paused stale agent ${ext} (id=${agentId}) in ${paused} queue interfaces`);
    } catch (err) {
      console.error(`[Heartbeat] Failed to pause agent ${ext} in queues:`, err);
    }
  }
  await mysqlExec(
    `UPDATE audit SET datetime_end=NOW(), duration=TIMEDIFF(NOW(), datetime_init)
     WHERE id_agent=${agentId} AND id_break IS NOT NULL AND datetime_end IS NULL`,
    "call_center"
  );
  await mysqlExec(
    `UPDATE audit SET datetime_end=NOW(), duration=TIMEDIFF(NOW(), datetime_init)
     WHERE id_agent=${agentId} AND id_break IS NULL AND datetime_end IS NULL`,
    "call_center"
  );
  heartbeats.delete(agentId);
}
async function cleanupStaleSessions() {
  const now = Date.now();
  const staleAgents = [];
  for (const [agentId, entry] of heartbeats.entries()) {
    if (now - entry.lastBeat > STALE_THRESHOLD_MS) {
      staleAgents.push(agentId);
    }
  }
  for (const agentId of staleAgents) {
    console.log(`[Heartbeat] Agent ${agentId} stale (no heartbeat for ${STALE_THRESHOLD_MS / 1e3}s), cleaning up...`);
    await closeStaleSession(agentId);
  }
  return staleAgents.length;
}

const SESSION_FILE = "/tmp/issabel-ui-sessions.json";
const loadSessions = () => {
  try {
    const raw = readFileSync(SESSION_FILE, "utf-8");
    const obj = JSON.parse(raw);
    return new Map(Object.entries(obj));
  } catch {
    return /* @__PURE__ */ new Map();
  }
};
const saveSessions = (sessions) => {
  try {
    writeFileSync$1(SESSION_FILE, JSON.stringify(Object.fromEntries(sessions)), "utf-8");
  } catch {
  }
};
let SESSIONS = loadSessions();
const sqliteQuery = async (query) => {
  const result = await execCmd("sqlite3", ["/var/www/db/acl.db", query]);
  if (result.code !== 0) return [];
  return result.stdout.trim().split("\n").filter(Boolean);
};
const authenticateUser = async (username, password) => {
  const md5 = createHash("md5").update(password).digest("hex");
  const rows = await sqliteQuery(
    `SELECT id, name, md5_password FROM acl_user WHERE name='${username}'`
  );
  if (!rows.length) return null;
  const [idStr, name, storedHash] = rows[0].split("|");
  if (storedHash !== md5) return null;
  const userId = parseInt(idStr);
  const memberRows = await sqliteQuery(
    `SELECT g.id, g.name FROM acl_group g JOIN acl_membership m ON m.id_group=g.id WHERE m.id_user=${userId}`
  );
  const [groupId, groupName] = memberRows.length ? memberRows[0].split("|") : ["0", "none"];
  const extRows = await sqliteQuery(`SELECT extension FROM acl_user WHERE id=${userId}`);
  const extension = extRows[0] || "";
  const token = createHash("sha256").update(`${userId}-${Date.now()}-${Math.random()}`).digest("hex");
  SESSIONS = loadSessions();
  SESSIONS.set(token, {
    userId,
    username: name,
    groupId: parseInt(groupId),
    groupName,
    extension,
    exp: Date.now() + 24 * 60 * 60 * 1e3
  });
  saveSessions(SESSIONS);
  return { token, userId, username: name, groupId: parseInt(groupId), groupName, extension };
};
const getSession = (token) => {
  SESSIONS = loadSessions();
  const session = SESSIONS.get(token);
  if (!session) return null;
  if (Date.now() > session.exp) {
    SESSIONS.delete(token);
    saveSessions(SESSIONS);
    return null;
  }
  return session;
};
const destroySession = (token) => {
  SESSIONS = loadSessions();
  SESSIONS.delete(token);
  saveSessions(SESSIONS);
};
const requireAuth = (event) => {
  var _a;
  const authHeader = (_a = getHeader(event, "authorization")) != null ? _a : "";
  const token = authHeader.replace(/^Bearer\s+/i, "").trim() || getCookie(event, "issabel_token") || "";
  const session = getSession(token);
  if (!session) {
    throw createError$1({ statusCode: 401, statusMessage: "Unauthorized" });
  }
  return session;
};
const listUsers = async () => {
  const rows = await sqliteQuery(
    `SELECT u.id, u.name, u.description, u.extension, IFNULL(g.name,'none')
     FROM acl_user u LEFT JOIN acl_membership m ON m.id_user=u.id
     LEFT JOIN acl_group g ON g.id=m.id_group ORDER BY u.id`
  );
  return rows.map((r) => {
    const [id, name, description, extension, group] = r.split("|");
    return { id: parseInt(id), name, description, extension, group };
  });
};
const createUser = async (username, password, description, extension, groupId) => {
  var _a;
  const md5 = createHash("md5").update(password).digest("hex");
  await execCmd("sqlite3", [
    "/var/www/db/acl.db",
    `INSERT INTO acl_user (name, description, md5_password, extension) VALUES ('${username}','${description}','${md5}','${extension}')`
  ]);
  const idRows = await sqliteQuery(`SELECT id FROM acl_user WHERE name='${username}'`);
  const userId = parseInt((_a = idRows[0]) != null ? _a : "0");
  if (userId && groupId) {
    await execCmd("sqlite3", [
      "/var/www/db/acl.db",
      `INSERT INTO acl_membership (id_user, id_group) VALUES (${userId},${groupId})`
    ]);
  }
  return userId;
};
const updateUser = async (id, fields) => {
  if (fields.description !== void 0) {
    await execCmd("sqlite3", ["/var/www/db/acl.db", `UPDATE acl_user SET description='${fields.description}' WHERE id=${id}`]);
  }
  if (fields.extension !== void 0) {
    await execCmd("sqlite3", ["/var/www/db/acl.db", `UPDATE acl_user SET extension='${fields.extension}' WHERE id=${id}`]);
  }
  if (fields.password) {
    const md5 = createHash("md5").update(fields.password).digest("hex");
    await execCmd("sqlite3", ["/var/www/db/acl.db", `UPDATE acl_user SET md5_password='${md5}' WHERE id=${id}`]);
  }
  if (fields.groupId !== void 0) {
    await execCmd("sqlite3", ["/var/www/db/acl.db", `DELETE FROM acl_membership WHERE id_user=${id}`]);
    if (fields.groupId > 0) {
      await execCmd("sqlite3", ["/var/www/db/acl.db", `INSERT INTO acl_membership (id_user, id_group) VALUES (${id},${fields.groupId})`]);
    }
  }
};
const deleteUser = async (id) => {
  await execCmd("sqlite3", ["/var/www/db/acl.db", `DELETE FROM acl_membership WHERE id_user=${id}`]);
  await execCmd("sqlite3", ["/var/www/db/acl.db", `DELETE FROM acl_user WHERE id=${id}`]);
};

const ECCP_HOST = "127.0.0.1";
const ECCP_PORT = 20005;
const ECCP_TIMEOUT = 5e3;
function buildXml(action, params = {}) {
  let xml = `<request id="1"><${action}>`;
  for (const [k, v] of Object.entries(params)) {
    xml += `<${k}>${escapeXml(v)}</${k}>`;
  }
  xml += `</${action}></request>`;
  return xml;
}
function escapeXml(s) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function parseSimpleXml(xml) {
  const result = {};
  const tagRegex = /<(\w+)(?:\s[^>]*)?>([^<]*)<\/\1>/g;
  let match;
  while ((match = tagRegex.exec(xml)) !== null) {
    result[match[1]] = match[2];
  }
  const nestedRegex = /<(\w+)(?:\s[^>]*)?>(<[\s\S]*?)<\/\1>/g;
  while ((match = nestedRegex.exec(xml)) !== null) {
    if (match[2].includes("<")) {
      result[match[1]] = parseSimpleXml(match[2]);
    }
  }
  const listItems = {};
  const itemRegex = /<(\w+)(?:\s[^>]*)?>(<[\s\S]*?)<\/\1>/g;
  while ((match = itemRegex.exec(xml)) !== null) {
    if (!listItems[match[1]]) listItems[match[1]] = [];
    if (match[2].includes("<")) {
      listItems[match[1]].push(parseSimpleXml(match[2]));
    } else {
      listItems[match[1]].push(match[2]);
    }
  }
  for (const [k, v] of Object.entries(listItems)) {
    if (v.length > 1) result[k] = v;
  }
  return result;
}
async function eccpRequest(action, params = {}) {
  return new Promise((resolve) => {
    const socket = new Socket();
    let responseData = "";
    let settled = false;
    const finish = (success, data = {}) => {
      if (settled) return;
      settled = true;
      try {
        socket.destroy();
      } catch {
      }
      resolve({ success, action, data, rawXml: responseData });
    };
    const timer = setTimeout(() => finish(false, { error: "Timeout" }), ECCP_TIMEOUT);
    socket.connect(ECCP_PORT, ECCP_HOST, () => {
      socket.write(buildXml(action, params) + "\n");
    });
    socket.on("data", (chunk) => {
      responseData += chunk.toString();
      if (responseData.includes("</response>")) {
        clearTimeout(timer);
        const data = parseSimpleXml(responseData);
        const success = !responseData.includes("<failure>") && !responseData.includes("<error>");
        finish(success, data);
      }
    });
    socket.on("error", (err) => {
      clearTimeout(timer);
      finish(false, { error: err.message });
    });
    socket.on("close", () => {
      clearTimeout(timer);
      if (!settled) finish(false, { error: "Connection closed" });
    });
  });
}
async function eccpIsAvailable() {
  try {
    const res = await eccpRequest("getmultipleagentstatus");
    return res.success || res.rawXml.includes("<response");
  } catch {
    return false;
  }
}

const collections = {
  'lucide': () => import('../_/icons.mjs').then(m => m.default),
};

const DEFAULT_ENDPOINT = "https://api.iconify.design";
const _EU3s4P = defineCachedEventHandler(async (event) => {
  const url = getRequestURL(event);
  if (!url)
    return createError$1({ status: 400, message: "Invalid icon request" });
  const options = useAppConfig().icon;
  const collectionName = event.context.params?.collection?.replace(/\.json$/, "");
  const collection = collectionName ? await collections[collectionName]?.() : null;
  const apiEndPoint = options.iconifyApiEndpoint || DEFAULT_ENDPOINT;
  const icons = url.searchParams.get("icons")?.split(",");
  if (collection) {
    if (icons?.length) {
      const data = getIcons(
        collection,
        icons
      );
      consola.debug(`[Icon] serving ${(icons || []).map((i) => "`" + collectionName + ":" + i + "`").join(",")} from bundled collection`);
      return data;
    }
  }
  if (options.fallbackToApi === true || options.fallbackToApi === "server-only") {
    const apiUrl = new URL("./" + basename(url.pathname) + url.search, apiEndPoint);
    consola.debug(`[Icon] fetching ${(icons || []).map((i) => "`" + collectionName + ":" + i + "`").join(",")} from iconify api`);
    if (apiUrl.host !== new URL(apiEndPoint).host) {
      return createError$1({ status: 400, message: "Invalid icon request" });
    }
    try {
      const data = await $fetch(apiUrl.href);
      return data;
    } catch (e) {
      consola.error(e);
      if (e.status === 404)
        return createError$1({ status: 404 });
      else
        return createError$1({ status: 500, message: "Failed to fetch fallback icon" });
    }
  }
  return createError$1({ status: 404 });
}, {
  group: "nuxt",
  name: "icon",
  getKey(event) {
    const collection = event.context.params?.collection?.replace(/\.json$/, "") || "unknown";
    const icons = String(getQuery(event).icons || "");
    return `${collection}_${icons.split(",")[0]}_${icons.length}_${hash$1(icons)}`;
  },
  swr: true,
  maxAge: 60 * 60 * 24 * 7
  // 1 week
});

const _lazy_kPRNXQ = () => import('../routes/api/admin/groups.get.mjs');
const _lazy_fWdKOX = () => import('../routes/api/admin/groups.post.mjs');
const _lazy_q2g3tV = () => import('../routes/api/admin/groups/_id_.delete.mjs');
const _lazy_J3IW1U = () => import('../routes/api/admin/groups/_id_.put.mjs');
const _lazy_7oUjp4 = () => import('../routes/api/admin/permissions/_groupId_.get.mjs');
const _lazy_i5ccWu = () => import('../routes/api/admin/permissions/_groupId_.put.mjs');
const _lazy_h2r_sU = () => import('../routes/api/admin/permissions/module-privileges/_groupId_.get.mjs');
const _lazy_HcNczJ = () => import('../routes/api/admin/permissions/module-privileges/_groupId_.put.mjs');
const _lazy_Vx8oAl = () => import('../routes/api/admin/permissions/privileges.get.mjs');
const _lazy_sRyixN = () => import('../routes/api/admin/permissions/resources.get.mjs');
const _lazy_I50hhJ = () => import('../routes/api/admin/users.get.mjs');
const _lazy_LNexJI = () => import('../routes/api/admin/users.post.mjs');
const _lazy_iamYba = () => import('../routes/api/admin/users/_id_.delete.mjs');
const _lazy_KljhrS = () => import('../routes/api/admin/users/_id_.put.mjs');
const _lazy_kgIykl = () => import('../routes/api/auth/login.post.mjs');
const _lazy_9kUGHB = () => import('../routes/api/auth/logout.post.mjs');
const _lazy_11WyW_ = () => import('../routes/api/auth/me.get.mjs');
const _lazy_AtRCh9 = () => import('../routes/api/auth/permissions.get.mjs');
const _lazy_1gHaLt = () => import('../routes/api/callcenter/agent-console/action.post.mjs');
const _lazy_KimZrd = () => import('../routes/api/callcenter/agent-console/agents-list.get.mjs');
const _lazy_uKcQIz = () => import('../routes/api/callcenter/agent-console/login.post.mjs');
const _lazy_bITdv6 = () => import('../routes/api/callcenter/agent-console/logout.post.mjs');
const _lazy_YmSaQ9 = () => import('../routes/api/callcenter/agent-console/status.get.mjs');
const _lazy_9ziMxA = () => import('../routes/api/callcenter/agents.get.mjs');
const _lazy_vpWbVo = () => import('../routes/api/callcenter/agents.post.mjs');
const _lazy_KaELiN = () => import('../routes/api/callcenter/breaks.get.mjs');
const _lazy_Gbepf_ = () => import('../routes/api/callcenter/breaks.post.mjs');
const _lazy_XjGk2u = () => import('../routes/api/callcenter/breaks/_id_.delete.mjs');
const _lazy_eI3Qg2 = () => import('../routes/api/callcenter/breaks/_id_.put.mjs');
const _lazy_zvnkwB = () => import('../routes/api/callcenter/campaign-monitor.get.mjs');
const _lazy_vvUfJ_ = () => import('../routes/api/callcenter/campaigns-in.get.mjs');
const _lazy_3wq1Jd = () => import('../routes/api/callcenter/campaigns-in.post.mjs');
const _lazy_7CbOjW = () => import('../routes/api/callcenter/campaigns-in/_id_.delete.mjs');
const _lazy_nhqH7F = () => import('../routes/api/callcenter/campaigns-in/_id_.put.mjs');
const _lazy_33Ft1d = () => import('../routes/api/callcenter/campaigns-out.get.mjs');
const _lazy_vlYN9z = () => import('../routes/api/callcenter/campaigns-out.post.mjs');
const _lazy_Md9DQn = () => import('../routes/api/callcenter/campaigns-out/_id_.delete.mjs');
const _lazy_dFfgeq = () => import('../routes/api/callcenter/campaigns-out/_id_.get.mjs');
const _lazy_Yc7v4K = () => import('../routes/api/callcenter/campaigns-out/_id_.put.mjs');
const _lazy_AkMlWy = () => import('../routes/api/callcenter/campaigns-out/_id/upload-csv.post.mjs');
const _lazy_h7CnWt = () => import('../routes/api/callcenter/cb-extensions.get.mjs');
const _lazy_sCURo2 = () => import('../routes/api/callcenter/cb-extensions.post.mjs');
const _lazy_sUKBdW = () => import('../routes/api/callcenter/cb-extensions/_id_.delete.mjs');
const _lazy_zwXfvH = () => import('../routes/api/callcenter/cb-extensions/_id_.put.mjs');
const _lazy_yW8Z8n = () => import('../routes/api/callcenter/cb-extensions/_id/disconnect.post.mjs');
const _lazy_mGS1T0 = () => import('../routes/api/callcenter/cb-extensions/available.get.mjs');
const _lazy_v2SBlA = () => import('../routes/api/callcenter/cc-agents.get.mjs');
const _lazy_GyTagF = () => import('../routes/api/callcenter/cc-agents.post.mjs');
const _lazy_mvPIEw = () => import('../routes/api/callcenter/cc-agents/_id_.delete.mjs');
const _lazy_tpiJd6 = () => import('../routes/api/callcenter/cc-agents/_id_.put.mjs');
const _lazy_RddPtU = () => import('../routes/api/callcenter/config.get.mjs');
const _lazy_tWxG5b = () => import('../routes/api/callcenter/config.put.mjs');
const _lazy_lNIBv8 = () => import('../routes/api/callcenter/dashboard.get.mjs');
const _lazy_FJeTn6 = () => import('../routes/api/callcenter/dialer-service.post.mjs');
const _lazy_qlHIBn = () => import('../routes/api/callcenter/dnc.get.mjs');
const _lazy_iAUcjI = () => import('../routes/api/callcenter/dnc.post.mjs');
const _lazy_dBJBU_ = () => import('../routes/api/callcenter/dnc/_id_.delete.mjs');
const _lazy_UVdq7V = () => import('../routes/api/callcenter/eccp-users.get.mjs');
const _lazy_YKyTxm = () => import('../routes/api/callcenter/eccp-users.post.mjs');
const _lazy_DHIVND = () => import('../routes/api/callcenter/eccp-users/_id_.delete.mjs');
const _lazy_qhSyT5 = () => import('../routes/api/callcenter/eccp-users/_id_.put.mjs');
const _lazy_HjP_HY = () => import('../routes/api/callcenter/external-urls.get.mjs');
const _lazy_nUN63b = () => import('../routes/api/callcenter/external-urls.post.mjs');
const _lazy_pChEnK = () => import('../routes/api/callcenter/external-urls/_id_.delete.mjs');
const _lazy_KMl26K = () => import('../routes/api/callcenter/external-urls/_id_.put.mjs');
const _lazy_5oHSov = () => import('../routes/api/callcenter/forms.get.mjs');
const _lazy_UPX0q5 = () => import('../routes/api/callcenter/forms.post.mjs');
const _lazy_eNQaGL = () => import('../routes/api/callcenter/forms/_id_.delete.mjs');
const _lazy_PPHjJn = () => import('../routes/api/callcenter/forms/_id_.get.mjs');
const _lazy_srnh9P = () => import('../routes/api/callcenter/forms/_id_.put.mjs');
const _lazy_1kYisk = () => import('../routes/api/callcenter/queues.get.mjs');
const _lazy_rAZxAY = () => import('../routes/api/callcenter/queues.post.mjs');
const _lazy__62JaX = () => import('../routes/api/callcenter/queues/_id_.put.mjs');
const _lazy__WJ6kG = () => import('../routes/api/callcenter/queues/_id/toggle-status.post.mjs');
const _lazy_Pq4JXE = () => import('../routes/api/callcenter/queues/available.get.mjs');
const _lazy_1qGen6 = () => import('../routes/api/callcenter/reports/agent-sessions.get.mjs');
const _lazy_4Qrhvl = () => import('../routes/api/callcenter/reports/breaks.get.mjs');
const _lazy_I3X9pF = () => import('../routes/api/callcenter/reports/calls-per-agent.get.mjs');
const _lazy_lvzbKB = () => import('../routes/api/callcenter/reports/campaign-stats.get.mjs');
const _lazy_rmVenB = () => import('../routes/api/license/activate.post.mjs');
const _lazy_7GQHuD = () => import('../routes/api/license/deactivate.post.mjs');
const _lazy_fCw07Y = () => import('../routes/api/license/status.get.mjs');
const _lazy_UA3fa4 = () => import('../routes/api/operator/action.post.mjs');
const _lazy_eA0h_o = () => import('../routes/api/operator/events.get.mjs');
const _lazy_xxwwzB = () => import('../routes/api/operator/panel.get.mjs');
const _lazy_tpSTUe = () => import('../routes/api/pbx/announcements.get.mjs');
const _lazy_d8vNnI = () => import('../routes/api/pbx/announcements.post.mjs');
const _lazy_VEVaqJ = () => import('../routes/api/pbx/announcements/_id_.delete.mjs');
const _lazy_6wSpYb = () => import('../routes/api/pbx/announcements/_id_.get.mjs');
const _lazy_Q0_2aU = () => import('../routes/api/pbx/announcements/_id_.put.mjs');
const _lazy_y8HIuz = () => import('../routes/api/pbx/call-recording.get.mjs');
const _lazy_6E0kaD = () => import('../routes/api/pbx/call-recording.post.mjs');
const _lazy_xHkhVG = () => import('../routes/api/pbx/call-recording/_id_.delete.mjs');
const _lazy_w4XwVd = () => import('../routes/api/pbx/call-recording/_id_.get.mjs');
const _lazy_wKerWD = () => import('../routes/api/pbx/call-recording/_id_.put.mjs');
const _lazy_6v6IBT = () => import('../routes/api/pbx/cid-lookup.get.mjs');
const _lazy_ULKnAr = () => import('../routes/api/pbx/cid-lookup.post.mjs');
const _lazy_LYO0Dw = () => import('../routes/api/pbx/cid-lookup/_id_.delete.mjs');
const _lazy_1wCgX5 = () => import('../routes/api/pbx/cid-lookup/_id_.get.mjs');
const _lazy_Wvc7p8 = () => import('../routes/api/pbx/cid-lookup/_id_.put.mjs');
const _lazy_7xCzA9 = () => import('../routes/api/pbx/conferences.get.mjs');
const _lazy_Hppdn3 = () => import('../routes/api/pbx/conferences.post.mjs');
const _lazy_FX0cYB = () => import('../routes/api/pbx/conferences/_id_.delete.mjs');
const _lazy_Jg1O8h = () => import('../routes/api/pbx/conferences/_id_.get.mjs');
const _lazy_VCpcJI = () => import('../routes/api/pbx/conferences/_id_.put.mjs');
const _lazy_kbwQmM = () => import('../routes/api/pbx/dashboard.get.mjs');
const _lazy_RpGETJ = () => import('../routes/api/pbx/destinations.get.mjs');
const _lazy_IUk1_v = () => import('../routes/api/pbx/disa.get.mjs');
const _lazy_xZ9_iz = () => import('../routes/api/pbx/disa.post.mjs');
const _lazy_1Qp24e = () => import('../routes/api/pbx/disa/_id_.delete.mjs');
const _lazy_fdhE9l = () => import('../routes/api/pbx/disa/_id_.get.mjs');
const _lazy_fJs0U8 = () => import('../routes/api/pbx/disa/_id_.put.mjs');
const _lazy_uVQWj7 = () => import('../routes/api/pbx/extensions.get.mjs');
const _lazy_Wv9I7i = () => import('../routes/api/pbx/extensions.post.mjs');
const _lazy_g6lN2z = () => import('../routes/api/pbx/extensions/_id_.delete.mjs');
const _lazy_HIilb8 = () => import('../routes/api/pbx/extensions/_id_.get.mjs');
const _lazy_7jbaFQ = () => import('../routes/api/pbx/extensions/_id_.put.mjs');
const _lazy_rTaDA9 = () => import('../routes/api/pbx/inbound-routes.get.mjs');
const _lazy_bGDT_K = () => import('../routes/api/pbx/inbound-routes.post.mjs');
const _lazy_zz7Zca = () => import('../routes/api/pbx/inbound-routes/_ext_.delete.mjs');
const _lazy_MaRIBT = () => import('../routes/api/pbx/inbound-routes/_id_.get.mjs');
const _lazy_7b5OnB = () => import('../routes/api/pbx/inbound-routes/_id_.put.mjs');
const _lazy_3VJKWq = () => import('../routes/api/pbx/ivr.get.mjs');
const _lazy_8ZXESn = () => import('../routes/api/pbx/ivr.post.mjs');
const _lazy_BJlBqq = () => import('../routes/api/pbx/ivr/_id_.delete.mjs');
const _lazy_NggU43 = () => import('../routes/api/pbx/ivr/_id_.get.mjs');
const _lazy_llTSSz = () => import('../routes/api/pbx/ivr/_id_.put.mjs');
const _lazy_jVP9US = () => import('../routes/api/pbx/outbound-routes.get.mjs');
const _lazy_oxG2fT = () => import('../routes/api/pbx/outbound-routes.post.mjs');
const _lazy_ieeQtW = () => import('../routes/api/pbx/outbound-routes/_id_.delete.mjs');
const _lazy_SGMBY9 = () => import('../routes/api/pbx/outbound-routes/_id_.get.mjs');
const _lazy_cRDx_H = () => import('../routes/api/pbx/outbound-routes/_id_.put.mjs');
const _lazy_BnjrpX = () => import('../routes/api/pbx/queues.get.mjs');
const _lazy_kNs3A4 = () => import('../routes/api/pbx/queues.post.mjs');
const _lazy_ekXTUC = () => import('../routes/api/pbx/queues/_id_.delete.mjs');
const _lazy_KGxL3k = () => import('../routes/api/pbx/queues/_id_.get.mjs');
const _lazy_pYYXPy = () => import('../routes/api/pbx/queues/_id_.put.mjs');
const _lazy_u4Pq8k = () => import('../routes/api/pbx/recordings.get.mjs');
const _lazy_EGYNnU = () => import('../routes/api/pbx/recordings.post.mjs');
const _lazy_2GJXUs = () => import('../routes/api/pbx/recordings/_id_.delete.mjs');
const _lazy_CJ0ftP = () => import('../routes/api/pbx/recordings/_id_.put.mjs');
const _lazy_7yjmDc = () => import('../routes/api/pbx/ring-groups.get.mjs');
const _lazy_Mfw_mS = () => import('../routes/api/pbx/ring-groups.post.mjs');
const _lazy_3KoCi4 = () => import('../routes/api/pbx/ring-groups/_id_.delete.mjs');
const _lazy_UYbNx6 = () => import('../routes/api/pbx/ring-groups/_id_.get.mjs');
const _lazy_yiGgOb = () => import('../routes/api/pbx/ring-groups/_id_.put.mjs');
const _lazy_6SXjwQ = () => import('../routes/api/pbx/set-callerid.get.mjs');
const _lazy_ive6x2 = () => import('../routes/api/pbx/set-callerid.post.mjs');
const _lazy_fuTd4e = () => import('../routes/api/pbx/set-callerid/_id_.delete.mjs');
const _lazy_yVpLwB = () => import('../routes/api/pbx/set-callerid/_id_.get.mjs');
const _lazy_JNDkk7 = () => import('../routes/api/pbx/set-callerid/_id_.put.mjs');
const _lazy_IrnTgn = () => import('../routes/api/pbx/system-status.get.mjs');
const _lazy_NpdXPp = () => import('../routes/api/pbx/time-conditions.get.mjs');
const _lazy_cUhrcB = () => import('../routes/api/pbx/time-conditions.post.mjs');
const _lazy_r6uqLP = () => import('../routes/api/pbx/time-conditions/_id_.delete.mjs');
const _lazy_9bS0N8 = () => import('../routes/api/pbx/time-conditions/_id_.get.mjs');
const _lazy_9pW_Xt = () => import('../routes/api/pbx/time-conditions/_id_.put.mjs');
const _lazy_SYhMSW = () => import('../routes/api/pbx/time-groups.get.mjs');
const _lazy_60ACph = () => import('../routes/api/pbx/time-groups.post.mjs');
const _lazy_b5KY3G = () => import('../routes/api/pbx/time-groups/_id_.delete.mjs');
const _lazy_hJpwWh = () => import('../routes/api/pbx/time-groups/_id_.get.mjs');
const _lazy_ggYA6v = () => import('../routes/api/pbx/time-groups/_id_.put.mjs');
const _lazy_l0527n = () => import('../routes/api/pbx/trunks.get.mjs');
const _lazy_W7ohXP = () => import('../routes/api/pbx/trunks.post.mjs');
const _lazy_mneq5t = () => import('../routes/api/pbx/trunks/_id_.delete.mjs');
const _lazy_wHv19n = () => import('../routes/api/pbx/trunks/_id_.get.mjs');
const _lazy_QCIEtT = () => import('../routes/api/pbx/trunks/_id_.put.mjs');
const _lazy_YALpJz = () => import('../routes/api/reports/cdr.get.mjs');
const _lazy_eL_zIB = () => import('../routes/api/reports/channel-usage.get.mjs');
const _lazy_4gKDd7 = () => import('../routes/api/reports/queue-stats.get.mjs');
const _lazy_as0fiT = () => import('../routes/renderer.mjs').then(function (n) { return n.r; });

const handlers = [
  { route: '', handler: _6kOD1J, lazy: false, middleware: true, method: undefined },
  { route: '', handler: _nL1EmJ, lazy: false, middleware: true, method: undefined },
  { route: '/api/admin/groups', handler: _lazy_kPRNXQ, lazy: true, middleware: false, method: "get" },
  { route: '/api/admin/groups', handler: _lazy_fWdKOX, lazy: true, middleware: false, method: "post" },
  { route: '/api/admin/groups/:id', handler: _lazy_q2g3tV, lazy: true, middleware: false, method: "delete" },
  { route: '/api/admin/groups/:id', handler: _lazy_J3IW1U, lazy: true, middleware: false, method: "put" },
  { route: '/api/admin/permissions/:groupId', handler: _lazy_7oUjp4, lazy: true, middleware: false, method: "get" },
  { route: '/api/admin/permissions/:groupId', handler: _lazy_i5ccWu, lazy: true, middleware: false, method: "put" },
  { route: '/api/admin/permissions/module-privileges/:groupId', handler: _lazy_h2r_sU, lazy: true, middleware: false, method: "get" },
  { route: '/api/admin/permissions/module-privileges/:groupId', handler: _lazy_HcNczJ, lazy: true, middleware: false, method: "put" },
  { route: '/api/admin/permissions/privileges', handler: _lazy_Vx8oAl, lazy: true, middleware: false, method: "get" },
  { route: '/api/admin/permissions/resources', handler: _lazy_sRyixN, lazy: true, middleware: false, method: "get" },
  { route: '/api/admin/users', handler: _lazy_I50hhJ, lazy: true, middleware: false, method: "get" },
  { route: '/api/admin/users', handler: _lazy_LNexJI, lazy: true, middleware: false, method: "post" },
  { route: '/api/admin/users/:id', handler: _lazy_iamYba, lazy: true, middleware: false, method: "delete" },
  { route: '/api/admin/users/:id', handler: _lazy_KljhrS, lazy: true, middleware: false, method: "put" },
  { route: '/api/auth/login', handler: _lazy_kgIykl, lazy: true, middleware: false, method: "post" },
  { route: '/api/auth/logout', handler: _lazy_9kUGHB, lazy: true, middleware: false, method: "post" },
  { route: '/api/auth/me', handler: _lazy_11WyW_, lazy: true, middleware: false, method: "get" },
  { route: '/api/auth/permissions', handler: _lazy_AtRCh9, lazy: true, middleware: false, method: "get" },
  { route: '/api/callcenter/agent-console/action', handler: _lazy_1gHaLt, lazy: true, middleware: false, method: "post" },
  { route: '/api/callcenter/agent-console/agents-list', handler: _lazy_KimZrd, lazy: true, middleware: false, method: "get" },
  { route: '/api/callcenter/agent-console/login', handler: _lazy_uKcQIz, lazy: true, middleware: false, method: "post" },
  { route: '/api/callcenter/agent-console/logout', handler: _lazy_bITdv6, lazy: true, middleware: false, method: "post" },
  { route: '/api/callcenter/agent-console/status', handler: _lazy_YmSaQ9, lazy: true, middleware: false, method: "get" },
  { route: '/api/callcenter/agents', handler: _lazy_9ziMxA, lazy: true, middleware: false, method: "get" },
  { route: '/api/callcenter/agents', handler: _lazy_vpWbVo, lazy: true, middleware: false, method: "post" },
  { route: '/api/callcenter/breaks', handler: _lazy_KaELiN, lazy: true, middleware: false, method: "get" },
  { route: '/api/callcenter/breaks', handler: _lazy_Gbepf_, lazy: true, middleware: false, method: "post" },
  { route: '/api/callcenter/breaks/:id', handler: _lazy_XjGk2u, lazy: true, middleware: false, method: "delete" },
  { route: '/api/callcenter/breaks/:id', handler: _lazy_eI3Qg2, lazy: true, middleware: false, method: "put" },
  { route: '/api/callcenter/campaign-monitor', handler: _lazy_zvnkwB, lazy: true, middleware: false, method: "get" },
  { route: '/api/callcenter/campaigns-in', handler: _lazy_vvUfJ_, lazy: true, middleware: false, method: "get" },
  { route: '/api/callcenter/campaigns-in', handler: _lazy_3wq1Jd, lazy: true, middleware: false, method: "post" },
  { route: '/api/callcenter/campaigns-in/:id', handler: _lazy_7CbOjW, lazy: true, middleware: false, method: "delete" },
  { route: '/api/callcenter/campaigns-in/:id', handler: _lazy_nhqH7F, lazy: true, middleware: false, method: "put" },
  { route: '/api/callcenter/campaigns-out', handler: _lazy_33Ft1d, lazy: true, middleware: false, method: "get" },
  { route: '/api/callcenter/campaigns-out', handler: _lazy_vlYN9z, lazy: true, middleware: false, method: "post" },
  { route: '/api/callcenter/campaigns-out/:id', handler: _lazy_Md9DQn, lazy: true, middleware: false, method: "delete" },
  { route: '/api/callcenter/campaigns-out/:id', handler: _lazy_dFfgeq, lazy: true, middleware: false, method: "get" },
  { route: '/api/callcenter/campaigns-out/:id', handler: _lazy_Yc7v4K, lazy: true, middleware: false, method: "put" },
  { route: '/api/callcenter/campaigns-out/:id/upload-csv', handler: _lazy_AkMlWy, lazy: true, middleware: false, method: "post" },
  { route: '/api/callcenter/cb-extensions', handler: _lazy_h7CnWt, lazy: true, middleware: false, method: "get" },
  { route: '/api/callcenter/cb-extensions', handler: _lazy_sCURo2, lazy: true, middleware: false, method: "post" },
  { route: '/api/callcenter/cb-extensions/:id', handler: _lazy_sUKBdW, lazy: true, middleware: false, method: "delete" },
  { route: '/api/callcenter/cb-extensions/:id', handler: _lazy_zwXfvH, lazy: true, middleware: false, method: "put" },
  { route: '/api/callcenter/cb-extensions/:id/disconnect', handler: _lazy_yW8Z8n, lazy: true, middleware: false, method: "post" },
  { route: '/api/callcenter/cb-extensions/available', handler: _lazy_mGS1T0, lazy: true, middleware: false, method: "get" },
  { route: '/api/callcenter/cc-agents', handler: _lazy_v2SBlA, lazy: true, middleware: false, method: "get" },
  { route: '/api/callcenter/cc-agents', handler: _lazy_GyTagF, lazy: true, middleware: false, method: "post" },
  { route: '/api/callcenter/cc-agents/:id', handler: _lazy_mvPIEw, lazy: true, middleware: false, method: "delete" },
  { route: '/api/callcenter/cc-agents/:id', handler: _lazy_tpiJd6, lazy: true, middleware: false, method: "put" },
  { route: '/api/callcenter/config', handler: _lazy_RddPtU, lazy: true, middleware: false, method: "get" },
  { route: '/api/callcenter/config', handler: _lazy_tWxG5b, lazy: true, middleware: false, method: "put" },
  { route: '/api/callcenter/dashboard', handler: _lazy_lNIBv8, lazy: true, middleware: false, method: "get" },
  { route: '/api/callcenter/dialer-service', handler: _lazy_FJeTn6, lazy: true, middleware: false, method: "post" },
  { route: '/api/callcenter/dnc', handler: _lazy_qlHIBn, lazy: true, middleware: false, method: "get" },
  { route: '/api/callcenter/dnc', handler: _lazy_iAUcjI, lazy: true, middleware: false, method: "post" },
  { route: '/api/callcenter/dnc/:id', handler: _lazy_dBJBU_, lazy: true, middleware: false, method: "delete" },
  { route: '/api/callcenter/eccp-users', handler: _lazy_UVdq7V, lazy: true, middleware: false, method: "get" },
  { route: '/api/callcenter/eccp-users', handler: _lazy_YKyTxm, lazy: true, middleware: false, method: "post" },
  { route: '/api/callcenter/eccp-users/:id', handler: _lazy_DHIVND, lazy: true, middleware: false, method: "delete" },
  { route: '/api/callcenter/eccp-users/:id', handler: _lazy_qhSyT5, lazy: true, middleware: false, method: "put" },
  { route: '/api/callcenter/external-urls', handler: _lazy_HjP_HY, lazy: true, middleware: false, method: "get" },
  { route: '/api/callcenter/external-urls', handler: _lazy_nUN63b, lazy: true, middleware: false, method: "post" },
  { route: '/api/callcenter/external-urls/:id', handler: _lazy_pChEnK, lazy: true, middleware: false, method: "delete" },
  { route: '/api/callcenter/external-urls/:id', handler: _lazy_KMl26K, lazy: true, middleware: false, method: "put" },
  { route: '/api/callcenter/forms', handler: _lazy_5oHSov, lazy: true, middleware: false, method: "get" },
  { route: '/api/callcenter/forms', handler: _lazy_UPX0q5, lazy: true, middleware: false, method: "post" },
  { route: '/api/callcenter/forms/:id', handler: _lazy_eNQaGL, lazy: true, middleware: false, method: "delete" },
  { route: '/api/callcenter/forms/:id', handler: _lazy_PPHjJn, lazy: true, middleware: false, method: "get" },
  { route: '/api/callcenter/forms/:id', handler: _lazy_srnh9P, lazy: true, middleware: false, method: "put" },
  { route: '/api/callcenter/queues', handler: _lazy_1kYisk, lazy: true, middleware: false, method: "get" },
  { route: '/api/callcenter/queues', handler: _lazy_rAZxAY, lazy: true, middleware: false, method: "post" },
  { route: '/api/callcenter/queues/:id', handler: _lazy__62JaX, lazy: true, middleware: false, method: "put" },
  { route: '/api/callcenter/queues/:id/toggle-status', handler: _lazy__WJ6kG, lazy: true, middleware: false, method: "post" },
  { route: '/api/callcenter/queues/available', handler: _lazy_Pq4JXE, lazy: true, middleware: false, method: "get" },
  { route: '/api/callcenter/reports/agent-sessions', handler: _lazy_1qGen6, lazy: true, middleware: false, method: "get" },
  { route: '/api/callcenter/reports/breaks', handler: _lazy_4Qrhvl, lazy: true, middleware: false, method: "get" },
  { route: '/api/callcenter/reports/calls-per-agent', handler: _lazy_I3X9pF, lazy: true, middleware: false, method: "get" },
  { route: '/api/callcenter/reports/campaign-stats', handler: _lazy_lvzbKB, lazy: true, middleware: false, method: "get" },
  { route: '/api/license/activate', handler: _lazy_rmVenB, lazy: true, middleware: false, method: "post" },
  { route: '/api/license/deactivate', handler: _lazy_7GQHuD, lazy: true, middleware: false, method: "post" },
  { route: '/api/license/status', handler: _lazy_fCw07Y, lazy: true, middleware: false, method: "get" },
  { route: '/api/operator/action', handler: _lazy_UA3fa4, lazy: true, middleware: false, method: "post" },
  { route: '/api/operator/events', handler: _lazy_eA0h_o, lazy: true, middleware: false, method: "get" },
  { route: '/api/operator/panel', handler: _lazy_xxwwzB, lazy: true, middleware: false, method: "get" },
  { route: '/api/pbx/announcements', handler: _lazy_tpSTUe, lazy: true, middleware: false, method: "get" },
  { route: '/api/pbx/announcements', handler: _lazy_d8vNnI, lazy: true, middleware: false, method: "post" },
  { route: '/api/pbx/announcements/:id', handler: _lazy_VEVaqJ, lazy: true, middleware: false, method: "delete" },
  { route: '/api/pbx/announcements/:id', handler: _lazy_6wSpYb, lazy: true, middleware: false, method: "get" },
  { route: '/api/pbx/announcements/:id', handler: _lazy_Q0_2aU, lazy: true, middleware: false, method: "put" },
  { route: '/api/pbx/call-recording', handler: _lazy_y8HIuz, lazy: true, middleware: false, method: "get" },
  { route: '/api/pbx/call-recording', handler: _lazy_6E0kaD, lazy: true, middleware: false, method: "post" },
  { route: '/api/pbx/call-recording/:id', handler: _lazy_xHkhVG, lazy: true, middleware: false, method: "delete" },
  { route: '/api/pbx/call-recording/:id', handler: _lazy_w4XwVd, lazy: true, middleware: false, method: "get" },
  { route: '/api/pbx/call-recording/:id', handler: _lazy_wKerWD, lazy: true, middleware: false, method: "put" },
  { route: '/api/pbx/cid-lookup', handler: _lazy_6v6IBT, lazy: true, middleware: false, method: "get" },
  { route: '/api/pbx/cid-lookup', handler: _lazy_ULKnAr, lazy: true, middleware: false, method: "post" },
  { route: '/api/pbx/cid-lookup/:id', handler: _lazy_LYO0Dw, lazy: true, middleware: false, method: "delete" },
  { route: '/api/pbx/cid-lookup/:id', handler: _lazy_1wCgX5, lazy: true, middleware: false, method: "get" },
  { route: '/api/pbx/cid-lookup/:id', handler: _lazy_Wvc7p8, lazy: true, middleware: false, method: "put" },
  { route: '/api/pbx/conferences', handler: _lazy_7xCzA9, lazy: true, middleware: false, method: "get" },
  { route: '/api/pbx/conferences', handler: _lazy_Hppdn3, lazy: true, middleware: false, method: "post" },
  { route: '/api/pbx/conferences/:id', handler: _lazy_FX0cYB, lazy: true, middleware: false, method: "delete" },
  { route: '/api/pbx/conferences/:id', handler: _lazy_Jg1O8h, lazy: true, middleware: false, method: "get" },
  { route: '/api/pbx/conferences/:id', handler: _lazy_VCpcJI, lazy: true, middleware: false, method: "put" },
  { route: '/api/pbx/dashboard', handler: _lazy_kbwQmM, lazy: true, middleware: false, method: "get" },
  { route: '/api/pbx/destinations', handler: _lazy_RpGETJ, lazy: true, middleware: false, method: "get" },
  { route: '/api/pbx/disa', handler: _lazy_IUk1_v, lazy: true, middleware: false, method: "get" },
  { route: '/api/pbx/disa', handler: _lazy_xZ9_iz, lazy: true, middleware: false, method: "post" },
  { route: '/api/pbx/disa/:id', handler: _lazy_1Qp24e, lazy: true, middleware: false, method: "delete" },
  { route: '/api/pbx/disa/:id', handler: _lazy_fdhE9l, lazy: true, middleware: false, method: "get" },
  { route: '/api/pbx/disa/:id', handler: _lazy_fJs0U8, lazy: true, middleware: false, method: "put" },
  { route: '/api/pbx/extensions', handler: _lazy_uVQWj7, lazy: true, middleware: false, method: "get" },
  { route: '/api/pbx/extensions', handler: _lazy_Wv9I7i, lazy: true, middleware: false, method: "post" },
  { route: '/api/pbx/extensions/:id', handler: _lazy_g6lN2z, lazy: true, middleware: false, method: "delete" },
  { route: '/api/pbx/extensions/:id', handler: _lazy_HIilb8, lazy: true, middleware: false, method: "get" },
  { route: '/api/pbx/extensions/:id', handler: _lazy_7jbaFQ, lazy: true, middleware: false, method: "put" },
  { route: '/api/pbx/inbound-routes', handler: _lazy_rTaDA9, lazy: true, middleware: false, method: "get" },
  { route: '/api/pbx/inbound-routes', handler: _lazy_bGDT_K, lazy: true, middleware: false, method: "post" },
  { route: '/api/pbx/inbound-routes/:ext', handler: _lazy_zz7Zca, lazy: true, middleware: false, method: "delete" },
  { route: '/api/pbx/inbound-routes/:id', handler: _lazy_MaRIBT, lazy: true, middleware: false, method: "get" },
  { route: '/api/pbx/inbound-routes/:id', handler: _lazy_7b5OnB, lazy: true, middleware: false, method: "put" },
  { route: '/api/pbx/ivr', handler: _lazy_3VJKWq, lazy: true, middleware: false, method: "get" },
  { route: '/api/pbx/ivr', handler: _lazy_8ZXESn, lazy: true, middleware: false, method: "post" },
  { route: '/api/pbx/ivr/:id', handler: _lazy_BJlBqq, lazy: true, middleware: false, method: "delete" },
  { route: '/api/pbx/ivr/:id', handler: _lazy_NggU43, lazy: true, middleware: false, method: "get" },
  { route: '/api/pbx/ivr/:id', handler: _lazy_llTSSz, lazy: true, middleware: false, method: "put" },
  { route: '/api/pbx/outbound-routes', handler: _lazy_jVP9US, lazy: true, middleware: false, method: "get" },
  { route: '/api/pbx/outbound-routes', handler: _lazy_oxG2fT, lazy: true, middleware: false, method: "post" },
  { route: '/api/pbx/outbound-routes/:id', handler: _lazy_ieeQtW, lazy: true, middleware: false, method: "delete" },
  { route: '/api/pbx/outbound-routes/:id', handler: _lazy_SGMBY9, lazy: true, middleware: false, method: "get" },
  { route: '/api/pbx/outbound-routes/:id', handler: _lazy_cRDx_H, lazy: true, middleware: false, method: "put" },
  { route: '/api/pbx/queues', handler: _lazy_BnjrpX, lazy: true, middleware: false, method: "get" },
  { route: '/api/pbx/queues', handler: _lazy_kNs3A4, lazy: true, middleware: false, method: "post" },
  { route: '/api/pbx/queues/:id', handler: _lazy_ekXTUC, lazy: true, middleware: false, method: "delete" },
  { route: '/api/pbx/queues/:id', handler: _lazy_KGxL3k, lazy: true, middleware: false, method: "get" },
  { route: '/api/pbx/queues/:id', handler: _lazy_pYYXPy, lazy: true, middleware: false, method: "put" },
  { route: '/api/pbx/recordings', handler: _lazy_u4Pq8k, lazy: true, middleware: false, method: "get" },
  { route: '/api/pbx/recordings', handler: _lazy_EGYNnU, lazy: true, middleware: false, method: "post" },
  { route: '/api/pbx/recordings/:id', handler: _lazy_2GJXUs, lazy: true, middleware: false, method: "delete" },
  { route: '/api/pbx/recordings/:id', handler: _lazy_CJ0ftP, lazy: true, middleware: false, method: "put" },
  { route: '/api/pbx/ring-groups', handler: _lazy_7yjmDc, lazy: true, middleware: false, method: "get" },
  { route: '/api/pbx/ring-groups', handler: _lazy_Mfw_mS, lazy: true, middleware: false, method: "post" },
  { route: '/api/pbx/ring-groups/:id', handler: _lazy_3KoCi4, lazy: true, middleware: false, method: "delete" },
  { route: '/api/pbx/ring-groups/:id', handler: _lazy_UYbNx6, lazy: true, middleware: false, method: "get" },
  { route: '/api/pbx/ring-groups/:id', handler: _lazy_yiGgOb, lazy: true, middleware: false, method: "put" },
  { route: '/api/pbx/set-callerid', handler: _lazy_6SXjwQ, lazy: true, middleware: false, method: "get" },
  { route: '/api/pbx/set-callerid', handler: _lazy_ive6x2, lazy: true, middleware: false, method: "post" },
  { route: '/api/pbx/set-callerid/:id', handler: _lazy_fuTd4e, lazy: true, middleware: false, method: "delete" },
  { route: '/api/pbx/set-callerid/:id', handler: _lazy_yVpLwB, lazy: true, middleware: false, method: "get" },
  { route: '/api/pbx/set-callerid/:id', handler: _lazy_JNDkk7, lazy: true, middleware: false, method: "put" },
  { route: '/api/pbx/system-status', handler: _lazy_IrnTgn, lazy: true, middleware: false, method: "get" },
  { route: '/api/pbx/time-conditions', handler: _lazy_NpdXPp, lazy: true, middleware: false, method: "get" },
  { route: '/api/pbx/time-conditions', handler: _lazy_cUhrcB, lazy: true, middleware: false, method: "post" },
  { route: '/api/pbx/time-conditions/:id', handler: _lazy_r6uqLP, lazy: true, middleware: false, method: "delete" },
  { route: '/api/pbx/time-conditions/:id', handler: _lazy_9bS0N8, lazy: true, middleware: false, method: "get" },
  { route: '/api/pbx/time-conditions/:id', handler: _lazy_9pW_Xt, lazy: true, middleware: false, method: "put" },
  { route: '/api/pbx/time-groups', handler: _lazy_SYhMSW, lazy: true, middleware: false, method: "get" },
  { route: '/api/pbx/time-groups', handler: _lazy_60ACph, lazy: true, middleware: false, method: "post" },
  { route: '/api/pbx/time-groups/:id', handler: _lazy_b5KY3G, lazy: true, middleware: false, method: "delete" },
  { route: '/api/pbx/time-groups/:id', handler: _lazy_hJpwWh, lazy: true, middleware: false, method: "get" },
  { route: '/api/pbx/time-groups/:id', handler: _lazy_ggYA6v, lazy: true, middleware: false, method: "put" },
  { route: '/api/pbx/trunks', handler: _lazy_l0527n, lazy: true, middleware: false, method: "get" },
  { route: '/api/pbx/trunks', handler: _lazy_W7ohXP, lazy: true, middleware: false, method: "post" },
  { route: '/api/pbx/trunks/:id', handler: _lazy_mneq5t, lazy: true, middleware: false, method: "delete" },
  { route: '/api/pbx/trunks/:id', handler: _lazy_wHv19n, lazy: true, middleware: false, method: "get" },
  { route: '/api/pbx/trunks/:id', handler: _lazy_QCIEtT, lazy: true, middleware: false, method: "put" },
  { route: '/api/reports/cdr', handler: _lazy_YALpJz, lazy: true, middleware: false, method: "get" },
  { route: '/api/reports/channel-usage', handler: _lazy_eL_zIB, lazy: true, middleware: false, method: "get" },
  { route: '/api/reports/queue-stats', handler: _lazy_4gKDd7, lazy: true, middleware: false, method: "get" },
  { route: '/__nuxt_error', handler: _lazy_as0fiT, lazy: true, middleware: false, method: undefined },
  { route: '/__nuxt_island/**', handler: _SxA8c9, lazy: false, middleware: false, method: undefined },
  { route: '/api/_nuxt_icon/:collection', handler: _EU3s4P, lazy: false, middleware: false, method: undefined },
  { route: '/**', handler: _lazy_as0fiT, lazy: true, middleware: false, method: undefined }
];

function createNitroApp() {
  const config = useRuntimeConfig();
  const hooks = createHooks();
  const captureError = (error, context = {}) => {
    const promise = hooks.callHookParallel("error", error, context).catch((error_) => {
      console.error("Error while capturing another error", error_);
    });
    if (context.event && isEvent(context.event)) {
      const errors = context.event.context.nitro?.errors;
      if (errors) {
        errors.push({ error, context });
      }
      if (context.event.waitUntil) {
        context.event.waitUntil(promise);
      }
    }
  };
  const h3App = createApp({
    debug: destr(false),
    onError: (error, event) => {
      captureError(error, { event, tags: ["request"] });
      return errorHandler(error, event);
    },
    onRequest: async (event) => {
      event.context.nitro = event.context.nitro || { errors: [] };
      const fetchContext = event.node.req?.__unenv__;
      if (fetchContext?._platform) {
        event.context = {
          _platform: fetchContext?._platform,
          // #3335
          ...fetchContext._platform,
          ...event.context
        };
      }
      if (!event.context.waitUntil && fetchContext?.waitUntil) {
        event.context.waitUntil = fetchContext.waitUntil;
      }
      event.fetch = (req, init) => fetchWithEvent(event, req, init, { fetch: localFetch });
      event.$fetch = (req, init) => fetchWithEvent(event, req, init, {
        fetch: $fetch
      });
      event.waitUntil = (promise) => {
        if (!event.context.nitro._waitUntilPromises) {
          event.context.nitro._waitUntilPromises = [];
        }
        event.context.nitro._waitUntilPromises.push(promise);
        if (event.context.waitUntil) {
          event.context.waitUntil(promise);
        }
      };
      event.captureError = (error, context) => {
        captureError(error, { event, ...context });
      };
      await nitroApp$1.hooks.callHook("request", event).catch((error) => {
        captureError(error, { event, tags: ["request"] });
      });
    },
    onBeforeResponse: async (event, response) => {
      await nitroApp$1.hooks.callHook("beforeResponse", event, response).catch((error) => {
        captureError(error, { event, tags: ["request", "response"] });
      });
    },
    onAfterResponse: async (event, response) => {
      await nitroApp$1.hooks.callHook("afterResponse", event, response).catch((error) => {
        captureError(error, { event, tags: ["request", "response"] });
      });
    }
  });
  const router = createRouter({
    preemptive: true
  });
  const nodeHandler = toNodeListener(h3App);
  const localCall = (aRequest) => b(
    nodeHandler,
    aRequest
  );
  const localFetch = (input, init) => {
    if (!input.toString().startsWith("/")) {
      return globalThis.fetch(input, init);
    }
    return C(
      nodeHandler,
      input,
      init
    ).then((response) => normalizeFetchResponse(response));
  };
  const $fetch = createFetch({
    fetch: localFetch,
    Headers: Headers$1,
    defaults: { baseURL: config.app.baseURL }
  });
  globalThis.$fetch = $fetch;
  h3App.use(createRouteRulesHandler({ localFetch }));
  for (const h of handlers) {
    let handler = h.lazy ? lazyEventHandler(h.handler) : h.handler;
    if (h.middleware || !h.route) {
      const middlewareBase = (config.app.baseURL + (h.route || "/")).replace(
        /\/+/g,
        "/"
      );
      h3App.use(middlewareBase, handler);
    } else {
      const routeRules = getRouteRulesForPath(
        h.route.replace(/:\w+|\*\*/g, "_")
      );
      if (routeRules.cache) {
        handler = cachedEventHandler(handler, {
          group: "nitro/routes",
          ...routeRules.cache
        });
      }
      router.use(h.route, handler, h.method);
    }
  }
  h3App.use(config.app.baseURL, router.handler);
  const app = {
    hooks,
    h3App,
    router,
    localCall,
    localFetch,
    captureError
  };
  return app;
}
function runNitroPlugins(nitroApp2) {
  for (const plugin of plugins) {
    try {
      plugin(nitroApp2);
    } catch (error) {
      nitroApp2.captureError(error, { tags: ["plugin"] });
      throw error;
    }
  }
}
const nitroApp$1 = createNitroApp();
function useNitroApp() {
  return nitroApp$1;
}
runNitroPlugins(nitroApp$1);

const debug = (...args) => {
};
function GracefulShutdown(server, opts) {
  opts = opts || {};
  const options = Object.assign(
    {
      signals: "SIGINT SIGTERM",
      timeout: 3e4,
      development: false,
      forceExit: true,
      onShutdown: (signal) => Promise.resolve(signal),
      preShutdown: (signal) => Promise.resolve(signal)
    },
    opts
  );
  let isShuttingDown = false;
  const connections = {};
  let connectionCounter = 0;
  const secureConnections = {};
  let secureConnectionCounter = 0;
  let failed = false;
  let finalRun = false;
  function onceFactory() {
    let called = false;
    return (emitter, events, callback) => {
      function call() {
        if (!called) {
          called = true;
          return Reflect.apply(callback, this, arguments);
        }
      }
      for (const e of events) {
        emitter.on(e, call);
      }
    };
  }
  const signals = options.signals.split(" ").map((s) => s.trim()).filter((s) => s.length > 0);
  const once = onceFactory();
  once(process, signals, (signal) => {
    debug("received shut down signal", signal);
    shutdown(signal).then(() => {
      if (options.forceExit) {
        process.exit(failed ? 1 : 0);
      }
    }).catch((error) => {
      debug("server shut down error occurred", error);
      process.exit(1);
    });
  });
  function isFunction(functionToCheck) {
    const getType = Object.prototype.toString.call(functionToCheck);
    return /^\[object\s([A-Za-z]+)?Function]$/.test(getType);
  }
  function destroy(socket, force = false) {
    if (socket._isIdle && isShuttingDown || force) {
      socket.destroy();
      if (socket.server instanceof http.Server) {
        delete connections[socket._connectionId];
      } else {
        delete secureConnections[socket._connectionId];
      }
    }
  }
  function destroyAllConnections(force = false) {
    debug("Destroy Connections : " + (force ? "forced close" : "close"));
    let counter = 0;
    let secureCounter = 0;
    for (const key of Object.keys(connections)) {
      const socket = connections[key];
      const serverResponse = socket._httpMessage;
      if (serverResponse && !force) {
        if (!serverResponse.headersSent) {
          serverResponse.setHeader("connection", "close");
        }
      } else {
        counter++;
        destroy(socket);
      }
    }
    debug("Connections destroyed : " + counter);
    debug("Connection Counter    : " + connectionCounter);
    for (const key of Object.keys(secureConnections)) {
      const socket = secureConnections[key];
      const serverResponse = socket._httpMessage;
      if (serverResponse && !force) {
        if (!serverResponse.headersSent) {
          serverResponse.setHeader("connection", "close");
        }
      } else {
        secureCounter++;
        destroy(socket);
      }
    }
    debug("Secure Connections destroyed : " + secureCounter);
    debug("Secure Connection Counter    : " + secureConnectionCounter);
  }
  server.on("request", (req, res) => {
    req.socket._isIdle = false;
    if (isShuttingDown && !res.headersSent) {
      res.setHeader("connection", "close");
    }
    res.on("finish", () => {
      req.socket._isIdle = true;
      destroy(req.socket);
    });
  });
  server.on("connection", (socket) => {
    if (isShuttingDown) {
      socket.destroy();
    } else {
      const id = connectionCounter++;
      socket._isIdle = true;
      socket._connectionId = id;
      connections[id] = socket;
      socket.once("close", () => {
        delete connections[socket._connectionId];
      });
    }
  });
  server.on("secureConnection", (socket) => {
    if (isShuttingDown) {
      socket.destroy();
    } else {
      const id = secureConnectionCounter++;
      socket._isIdle = true;
      socket._connectionId = id;
      secureConnections[id] = socket;
      socket.once("close", () => {
        delete secureConnections[socket._connectionId];
      });
    }
  });
  process.on("close", () => {
    debug("closed");
  });
  function shutdown(sig) {
    function cleanupHttp() {
      destroyAllConnections();
      debug("Close http server");
      return new Promise((resolve, reject) => {
        server.close((err) => {
          if (err) {
            return reject(err);
          }
          return resolve(true);
        });
      });
    }
    debug("shutdown signal - " + sig);
    if (options.development) {
      debug("DEV-Mode - immediate forceful shutdown");
      return process.exit(0);
    }
    function finalHandler() {
      if (!finalRun) {
        finalRun = true;
        if (options.finally && isFunction(options.finally)) {
          debug("executing finally()");
          options.finally();
        }
      }
      return Promise.resolve();
    }
    function waitForReadyToShutDown(totalNumInterval) {
      debug(`waitForReadyToShutDown... ${totalNumInterval}`);
      if (totalNumInterval === 0) {
        debug(
          `Could not close connections in time (${options.timeout}ms), will forcefully shut down`
        );
        return Promise.resolve(true);
      }
      const allConnectionsClosed = Object.keys(connections).length === 0 && Object.keys(secureConnections).length === 0;
      if (allConnectionsClosed) {
        debug("All connections closed. Continue to shutting down");
        return Promise.resolve(false);
      }
      debug("Schedule the next waitForReadyToShutdown");
      return new Promise((resolve) => {
        setTimeout(() => {
          resolve(waitForReadyToShutDown(totalNumInterval - 1));
        }, 250);
      });
    }
    if (isShuttingDown) {
      return Promise.resolve();
    }
    debug("shutting down");
    return options.preShutdown(sig).then(() => {
      isShuttingDown = true;
      cleanupHttp();
    }).then(() => {
      const pollIterations = options.timeout ? Math.round(options.timeout / 250) : 0;
      return waitForReadyToShutDown(pollIterations);
    }).then((force) => {
      debug("Do onShutdown now");
      if (force) {
        destroyAllConnections(force);
      }
      return options.onShutdown(sig);
    }).then(finalHandler).catch((error) => {
      const errString = typeof error === "string" ? error : JSON.stringify(error);
      debug(errString);
      failed = true;
      throw errString;
    });
  }
  function shutdownManual() {
    return shutdown("manual");
  }
  return shutdownManual;
}

function getGracefulShutdownConfig() {
  return {
    disabled: !!process.env.NITRO_SHUTDOWN_DISABLED,
    signals: (process.env.NITRO_SHUTDOWN_SIGNALS || "SIGTERM SIGINT").split(" ").map((s) => s.trim()),
    timeout: Number.parseInt(process.env.NITRO_SHUTDOWN_TIMEOUT || "", 10) || 3e4,
    forceExit: !process.env.NITRO_SHUTDOWN_NO_FORCE_EXIT
  };
}
function setupGracefulShutdown(listener, nitroApp) {
  const shutdownConfig = getGracefulShutdownConfig();
  if (shutdownConfig.disabled) {
    return;
  }
  GracefulShutdown(listener, {
    signals: shutdownConfig.signals.join(" "),
    timeout: shutdownConfig.timeout,
    forceExit: shutdownConfig.forceExit,
    onShutdown: async () => {
      await new Promise((resolve) => {
        const timeout = setTimeout(() => {
          console.warn("Graceful shutdown timeout, force exiting...");
          resolve();
        }, shutdownConfig.timeout);
        nitroApp.hooks.callHook("close").catch((error) => {
          console.error(error);
        }).finally(() => {
          clearTimeout(timeout);
          resolve();
        });
      });
    }
  });
}

const cert = process.env.NITRO_SSL_CERT;
const key = process.env.NITRO_SSL_KEY;
const nitroApp = useNitroApp();
const server = cert && key ? new Server({ key, cert }, toNodeListener(nitroApp.h3App)) : new Server$1(toNodeListener(nitroApp.h3App));
const port = destr(process.env.NITRO_PORT || process.env.PORT) || 3e3;
const host = process.env.NITRO_HOST || process.env.HOST;
const path = process.env.NITRO_UNIX_SOCKET;
const listener = server.listen(path ? { path } : { port, host }, (err) => {
  if (err) {
    console.error(err);
    process.exit(1);
  }
  const protocol = cert && key ? "https" : "http";
  const addressInfo = listener.address();
  if (typeof addressInfo === "string") {
    console.log(`Listening on unix socket ${addressInfo}`);
    return;
  }
  const baseURL = (useRuntimeConfig().app.baseURL || "").replace(/\/$/, "");
  const url = `${protocol}://${addressInfo.family === "IPv6" ? `[${addressInfo.address}]` : addressInfo.address}:${addressInfo.port}${baseURL}`;
  console.log(`Listening on ${url}`);
});
trapUnhandledNodeErrors();
setupGracefulShutdown(listener, nitroApp);
const nodeServer = {};

export { useRuntimeConfig as $, getHeader as A, getSession as B, runAsterisk as C, mysqlExec as D, execCmd as E, mysqlQuery as F, closeStaleSession as G, recordHeartbeat as H, removeHeartbeat as I, getQuery as J, cleanupStaleSessions as K, eccpIsAvailable as L, isDialerRunning as M, getTodayAbandonedStats as N, getBestQueueAbandoned as O, isLicenseValid as P, activateLicense as Q, deactivateLicense as R, getLicenseStatus as S, getMachineId as T, getAmiClient as U, getAmiState as V, reloadAsterisk as W, serviceIsActive as X, readMultipartFormData as Y, getAbandonedStatsForRange as Z, buildAssetsURL as _, readBody as a, getResponseStatusText as a0, getResponseStatus as a1, defineRenderHandler as a2, publicAssetsURL as a3, destr as a4, getRouteRules as a5, joinURL as a6, useNitroApp as a7, serialize$1 as a8, hasProtocol as a9, isScriptProtocol as aa, defu as ab, klona as ac, isEqual as ad, withQuery as ae, sanitizeStatusCode as af, parseURL as ag, encodePath as ah, decodePath as ai, parseQuery as aj, defuFn as ak, getRequestHeaders as al, getContext as am, withTrailingSlash as an, withoutTrailingSlash as ao, $fetch$1 as ap, baseURL as aq, executeAsync as ar, upperFirst as as, nodeServer as at, createGroup as b, createError$1 as c, defineEventHandler as d, deleteGroup as e, listResources as f, getRouterParam as g, getGroupPermissions as h, setGroupPermissions as i, getGroupModulePrivileges as j, setGroupModulePrivileges as k, listGroups as l, getAllModulePrivileges as m, listUsers as n, createUser as o, sqliteExec as p, deleteUser as q, requireAuth as r, sqliteQuery$1 as s, updateUser as t, updateGroup as u, authenticateUser as v, setCookie as w, getCookie as x, destroySession as y, deleteCookie as z };
//# sourceMappingURL=nitro.mjs.map
