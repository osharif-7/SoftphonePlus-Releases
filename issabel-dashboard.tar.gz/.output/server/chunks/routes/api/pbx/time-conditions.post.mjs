import { d as defineEventHandler, a as readBody, c as createError, D as mysqlExec, W as reloadAsterisk } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const timeConditions_post = defineEventHandler(async (event) => {
  var _a, _b, _c, _d;
  const body = await readBody(event);
  const name = String((_a = body.name) != null ? _a : "").trim();
  const timeGroupId = Number((_b = body.timeGroupId) != null ? _b : 0);
  const trueDest = String((_c = body.trueDest) != null ? _c : "").trim();
  const falseDest = String((_d = body.falseDest) != null ? _d : "").trim();
  if (!name) throw createError({ statusCode: 400, statusMessage: "Name required" });
  const r = await mysqlExec(
    `INSERT INTO timeconditions (displayname, time, truegoto, falsegoto, priority) VALUES ('${name}',${timeGroupId},'${trueDest}','${falseDest}','0')`
  );
  if (!r.ok) throw createError({ statusCode: 500, statusMessage: r.error });
  await reloadAsterisk();
  return { ok: true };
});

export { timeConditions_post as default };
//# sourceMappingURL=time-conditions.post.mjs.map
