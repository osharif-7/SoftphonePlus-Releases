import { d as defineEventHandler, g as getRouterParam, F as mysqlQuery, c as createError } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _id__get = defineEventHandler(async (event) => {
  const id = getRouterParam(event, "id");
  const rows = await mysqlQuery(`SELECT grpnum, IFNULL(strategy,'ringall'), grptime, IFNULL(grppre,''), IFNULL(grplist,''), IFNULL(annmsg_id,''), IFNULL(postdest,''), IFNULL(description,''), IFNULL(alertinfo,''), IFNULL(needsconf,''), IFNULL(ringing,''), IFNULL(cwignore,''), IFNULL(cfignore,''), IFNULL(cpickup,''), IFNULL(recording,'dontcare') FROM ringgroups WHERE grpnum='${id}'`);
  if (!rows.length) throw createError({ statusCode: 404, statusMessage: "Ring group not found" });
  const c = rows[0].split("	");
  return { grpnum: c[0], strategy: c[1], grptime: Number(c[2]), grppre: c[3], grplist: c[4], annmsg_id: c[5], postdest: c[6], description: c[7], alertinfo: c[8], needsconf: c[9], ringing: c[10], cwignore: c[11], cfignore: c[12], cpickup: c[13], recording: c[14] };
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
