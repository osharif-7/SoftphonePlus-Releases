import { d as defineEventHandler, g as getRouterParam, a as readBody, D as mysqlExec, W as reloadAsterisk } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _id__put = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m;
  const id = getRouterParam(event, "id");
  const b = await readBody(event);
  const fields = [
    `strategy='${(_a = b.strategy) != null ? _a : ""}'`,
    `grptime=${Number((_b = b.grptime) != null ? _b : 20)}`,
    `grppre='${(_c = b.grppre) != null ? _c : ""}'`,
    `grplist='${(_d = b.grplist) != null ? _d : ""}'`,
    `postdest='${(_e = b.postdest) != null ? _e : ""}'`,
    `description='${(_f = b.description) != null ? _f : ""}'`,
    `alertinfo='${(_g = b.alertinfo) != null ? _g : ""}'`,
    `needsconf='${(_h = b.needsconf) != null ? _h : ""}'`,
    `ringing='${(_i = b.ringing) != null ? _i : ""}'`,
    `cwignore='${(_j = b.cwignore) != null ? _j : ""}'`,
    `cfignore='${(_k = b.cfignore) != null ? _k : ""}'`,
    `cpickup='${(_l = b.cpickup) != null ? _l : ""}'`,
    `recording='${(_m = b.recording) != null ? _m : "dontcare"}'`
  ];
  await mysqlExec(`UPDATE ringgroups SET ${fields.join(",")} WHERE grpnum='${id}'`);
  await reloadAsterisk();
  return { ok: true };
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
