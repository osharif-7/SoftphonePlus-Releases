import { d as defineEventHandler, g as getRouterParam, a as readBody, D as mysqlExec, W as reloadAsterisk } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _id__put = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e, _f, _g;
  const id = getRouterParam(event, "id");
  const b = await readBody(event);
  await mysqlExec(`UPDATE disa SET displayname='${(_a = b.displayname) != null ? _a : ""}', pin='${(_b = b.pin) != null ? _b : ""}', cid='${(_c = b.cid) != null ? _c : ""}', context='${(_d = b.context) != null ? _d : "from-internal"}', digittimeout=${Number((_e = b.digittimeout) != null ? _e : 5)}, resptimeout=${Number((_f = b.resptimeout) != null ? _f : 10)}, hangup='${(_g = b.hangup) != null ? _g : "no"}', keepcid=${b.keepcid ? 1 : 0} WHERE disa_id=${id}`);
  await reloadAsterisk();
  return { ok: true };
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
