import { d as defineEventHandler, g as getRouterParam, F as mysqlQuery, c as createError } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _id__get = defineEventHandler(async (event) => {
  const id = getRouterParam(event, "id");
  const rows = await mysqlQuery(`SELECT exten, IFNULL(options,''), IFNULL(userpin,''), IFNULL(adminpin,''), IFNULL(description,''), IFNULL(joinmsg_id,''), IFNULL(music,'default'), IFNULL(users,0) FROM meetme WHERE exten='${id}'`);
  if (!rows.length) throw createError({ statusCode: 404, statusMessage: "Conference not found" });
  const c = rows[0].split("	");
  return { exten: c[0], options: c[1], userpin: c[2], adminpin: c[3], description: c[4], joinmsg_id: c[5], music: c[6], users: Number(c[7]) };
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
