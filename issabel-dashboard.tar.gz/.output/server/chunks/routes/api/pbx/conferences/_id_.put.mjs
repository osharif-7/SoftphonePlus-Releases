import { d as defineEventHandler, g as getRouterParam, a as readBody, D as mysqlExec, W as reloadAsterisk } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _id__put = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e, _f;
  const id = getRouterParam(event, "id");
  const b = await readBody(event);
  await mysqlExec(`UPDATE meetme SET description='${(_a = b.description) != null ? _a : ""}', userpin='${(_b = b.userpin) != null ? _b : ""}', adminpin='${(_c = b.adminpin) != null ? _c : ""}', options='${(_d = b.options) != null ? _d : ""}', music='${(_e = b.music) != null ? _e : "default"}', users=${Number((_f = b.users) != null ? _f : 0)} WHERE exten='${id}'`);
  await reloadAsterisk();
  return { ok: true };
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
