import { d as defineEventHandler, a as readBody, c as createError, D as mysqlExec, W as reloadAsterisk } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const extensions_post = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e;
  const body = await readBody(event);
  const ext = String((_a = body.extension) != null ? _a : "").trim();
  const name = String((_c = (_b = body.displayName) != null ? _b : body.name) != null ? _c : "").trim();
  const tech = String((_d = body.tech) != null ? _d : "sip").trim().toLowerCase();
  const secret = String((_e = body.secret) != null ? _e : "").trim();
  if (!ext || !name) {
    throw createError({ statusCode: 400, statusMessage: "Extension number and display name are required" });
  }
  const insertUser = `INSERT INTO users (extension, password, name, voicemail, ringtimer, noanswer, recording, outboundcid, sipname, noanswer_cid, busy_cid, chanunavail_cid, noanswer_dest, busy_dest, chanunavail_dest) VALUES ('${ext}','','${name}','novm',0,'','overwrite','','','','','','','','')`;
  const insertDevice = `INSERT INTO devices (id, tech, dial, devicetype, user, description, emergency_cid) VALUES ('${ext}','${tech}','${tech.toUpperCase()}/${ext}','fixed','${ext}','${name}','')`;
  const sipData = [
    { keyword: "secret", data: secret || ext },
    { keyword: "dtmfmode", data: "rfc2833" },
    { keyword: "canreinvite", data: "no" },
    { keyword: "context", data: "from-internal" },
    { keyword: "host", data: "dynamic" },
    { keyword: "type", data: "friend" },
    { keyword: "nat", data: "yes" },
    { keyword: "port", data: "5060" },
    { keyword: "qualify", data: "yes" },
    { keyword: "callgroup", data: "" },
    { keyword: "pickupgroup", data: "" },
    { keyword: "disallow", data: "all" },
    { keyword: "allow", data: "ulaw&alaw" },
    { keyword: "dial", data: `SIP/${ext}` },
    { keyword: "account", data: ext },
    { keyword: "callerid", data: `device <${ext}>` }
  ];
  const sipInserts = sipData.map((d) => `('${ext}','${d.keyword}','${d.data}',0)`).join(",");
  const insertSip = `INSERT INTO sip (id, keyword, data, flags) VALUES ${sipInserts}`;
  const r1 = await mysqlExec(insertUser);
  if (!r1.ok) throw createError({ statusCode: 500, statusMessage: `Failed to create user: ${r1.error}` });
  const r2 = await mysqlExec(insertDevice);
  if (!r2.ok) throw createError({ statusCode: 500, statusMessage: `Failed to create device: ${r2.error}` });
  const r3 = await mysqlExec(insertSip);
  if (!r3.ok) throw createError({ statusCode: 500, statusMessage: `Failed to create SIP config: ${r3.error}` });
  await reloadAsterisk();
  return { ok: true, extension: ext };
});

export { extensions_post as default };
//# sourceMappingURL=extensions.post.mjs.map
