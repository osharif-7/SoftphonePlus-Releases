import { d as defineEventHandler, a as readBody, c as createError, D as mysqlExec, W as reloadAsterisk } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const announcements_post = defineEventHandler(async (event) => {
  var _a, _b, _c;
  const body = await readBody(event);
  const description = String((_a = body.description) != null ? _a : "").trim();
  const recordingId = Number((_b = body.recordingId) != null ? _b : 0);
  const postDest = String((_c = body.postDest) != null ? _c : "").trim();
  if (!description) throw createError({ statusCode: 400, statusMessage: "Description required" });
  const r = await mysqlExec(
    `INSERT INTO announcement (description, recording_id, allow_skip, post_dest, repeat_msg) VALUES ('${description}',${recordingId},0,'${postDest}','')`
  );
  if (!r.ok) throw createError({ statusCode: 500, statusMessage: r.error });
  await reloadAsterisk();
  return { ok: true };
});

export { announcements_post as default };
//# sourceMappingURL=announcements.post.mjs.map
