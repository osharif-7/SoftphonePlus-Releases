import { d as defineEventHandler, F as mysqlQuery } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const announcements_get = defineEventHandler(async () => {
  const rows = await mysqlQuery(
    "SELECT a.announcement_id, IFNULL(a.description,''), IFNULL(r.displayname,'none'), IFNULL(a.post_dest,'') FROM announcement a LEFT JOIN recordings r ON r.id=a.recording_id ORDER BY a.announcement_id"
  );
  return rows.map((r) => {
    const [id, description, recording, postDest] = r.split("	");
    return { id, description, recording, postDest };
  });
});

export { announcements_get as default };
//# sourceMappingURL=announcements.get.mjs.map
