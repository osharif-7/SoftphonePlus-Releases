import { d as defineEventHandler, Y as readMultipartFormData, c as createError, D as mysqlExec, W as reloadAsterisk } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const recordings_post = defineEventHandler(async (event) => {
  const formData = await readMultipartFormData(event);
  if (!formData) throw createError({ statusCode: 400, statusMessage: "Form data required" });
  let displayname = "";
  let description = "";
  let fileData = null;
  let fileName = "";
  for (const field of formData) {
    if (field.name === "displayname") displayname = field.data.toString().trim();
    else if (field.name === "description") description = field.data.toString().trim();
    else if (field.name === "file") {
      fileData = field.data;
      fileName = field.filename || "recording.wav";
    }
  }
  if (!displayname) throw createError({ statusCode: 400, statusMessage: "Display name is required" });
  const safeName = displayname.replace(/[^a-zA-Z0-9_-]/g, "_").toLowerCase();
  const ext = fileName.split(".").pop() || "wav";
  const destFile = `custom/${safeName}`;
  const fullPath = `/var/lib/asterisk/sounds/${destFile}.${ext}`;
  if (fileData) {
    const { writeFile, chmod } = await import('node:fs/promises');
    await writeFile(fullPath, fileData);
    await chmod(fullPath, 420);
  }
  const dn = displayname.replace(/'/g, "''");
  const desc = description.replace(/'/g, "''");
  const fn = fileData ? destFile : "";
  const result = await mysqlExec(
    `INSERT INTO recordings (displayname, filename, description, fcode) VALUES ('${dn}','${fn}','${desc}',0)`
  );
  if (!result.ok) throw createError({ statusCode: 500, statusMessage: result.error });
  await reloadAsterisk();
  return { ok: true };
});

export { recordings_post as default };
//# sourceMappingURL=recordings.post.mjs.map
