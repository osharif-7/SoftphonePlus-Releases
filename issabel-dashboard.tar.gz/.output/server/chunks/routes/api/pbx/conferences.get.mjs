import { d as defineEventHandler, F as mysqlQuery } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const conferences_get = defineEventHandler(async () => {
  const rows = await mysqlQuery("SELECT exten, IFNULL(description,''), IFNULL(userpin,''), IFNULL(adminpin,''), IFNULL(options,''), IFNULL(users,0) FROM meetme ORDER BY exten");
  return rows.map((r) => {
    const [exten, description, userpin, adminpin, options, users] = r.split("	");
    return { exten, description, userpin, adminpin, options, users: Number(users) };
  });
});

export { conferences_get as default };
//# sourceMappingURL=conferences.get.mjs.map
