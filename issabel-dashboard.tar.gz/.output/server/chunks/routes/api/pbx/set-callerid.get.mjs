import { d as defineEventHandler, F as mysqlQuery } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const setCallerid_get = defineEventHandler(async () => {
  const rows = await mysqlQuery("SELECT callerid_id, IFNULL(description,''), IFNULL(cid_name,''), IFNULL(cid_num,'') FROM setcid ORDER BY callerid_id").catch(() => []);
  return rows.map((r) => {
    const [id, description, cidName, cidNum] = r.split("	");
    return { id, description, cidName, cidNum };
  });
});

export { setCallerid_get as default };
//# sourceMappingURL=set-callerid.get.mjs.map
