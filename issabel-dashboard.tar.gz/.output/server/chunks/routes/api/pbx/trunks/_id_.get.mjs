import { d as defineEventHandler, g as getRouterParam, c as createError, F as mysqlQuery } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _id__get = defineEventHandler(async (event) => {
  var _a, _b, _c;
  const id = getRouterParam(event, "id");
  if (!id) throw createError({ statusCode: 400, statusMessage: "Trunk ID required" });
  const rows = await mysqlQuery(`SELECT trunkid, IFNULL(name,''), IFNULL(tech,''), IFNULL(outcid,''), IFNULL(keepcid,'off'), IFNULL(maxchans,''), IFNULL(failscript,''), IFNULL(dialoutprefix,''), IFNULL(channelid,''), IFNULL(usercontext,''), IFNULL(provider,''), IFNULL(disabled,'off'), IFNULL(\`continue\`,'off') FROM trunks WHERE trunkid=${id}`);
  if (!rows.length) throw createError({ statusCode: 404, statusMessage: "Trunk not found" });
  const c = rows[0].split("	");
  const trunk = {
    trunkid: c[0],
    name: c[1],
    tech: c[2],
    outcid: c[3],
    keepcid: c[4],
    maxchans: c[5],
    failscript: c[6],
    dialoutprefix: c[7],
    channelid: c[8],
    usercontext: c[9],
    provider: c[10],
    disabled: c[11],
    continue: c[12]
  };
  const tech = ((_a = trunk.tech) == null ? void 0 : _a.toLowerCase()) || "";
  if (tech === "sip" || tech === "iax" || tech === "iax2") {
    const table = tech === "sip" ? "sip" : "iax";
    const peerRows = await mysqlQuery(`SELECT keyword, data FROM ${table} WHERE id='tr-peer-${id}' ORDER BY flags, keyword DESC`);
    trunk.peerdetails = peerRows.map((r) => {
      const [kw, data] = r.split("	");
      return kw !== "account" ? `${kw}=${data}` : null;
    }).filter(Boolean).join("\n");
    const userRows = await mysqlQuery(`SELECT keyword, data FROM ${table} WHERE id='tr-user-${id}' ORDER BY flags, keyword DESC`);
    trunk.userconfig = userRows.map((r) => {
      const [kw, data] = r.split("	");
      return kw !== "account" ? `${kw}=${data}` : null;
    }).filter(Boolean).join("\n");
    const regRows = await mysqlQuery(`SELECT data FROM ${table} WHERE id='tr-reg-${id}'`);
    trunk.register = ((_b = regRows[0]) == null ? void 0 : _b.split("	").pop()) || "";
  }
  if (tech === "pjsip") {
    const pjRows = await mysqlQuery(`SELECT keyword, data FROM sip WHERE id='pjsip-${id}' ORDER BY flags, keyword DESC`);
    const pjSettings = {};
    for (const r of pjRows) {
      const [kw, data] = r.split("	");
      if (kw !== "account") pjSettings[kw] = data;
    }
    trunk.pjsip = pjSettings;
    const regRows = await mysqlQuery(`SELECT data FROM sip WHERE id='tr-reg-${id}'`);
    trunk.register = ((_c = regRows[0]) == null ? void 0 : _c.split("	").pop()) || "";
  }
  const dpRows = await mysqlQuery(`SELECT prepend_digits, match_pattern_prefix, match_pattern_pass, seq FROM trunk_dialpatterns WHERE trunkid=${id} ORDER BY seq`);
  trunk.dialpatterns = dpRows.map((r) => {
    const [prepend, prefix, pattern, seq] = r.split("	");
    return { prepend: prepend || "", prefix: prefix || "", pattern: pattern || "", seq: parseInt(seq || "0") };
  });
  return trunk;
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
