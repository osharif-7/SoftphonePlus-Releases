import { d as defineEventHandler, g as getRouterParam, c as createError, D as mysqlExec, W as reloadAsterisk } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _id__delete = defineEventHandler(async (event) => {
  const id = getRouterParam(event, "id");
  if (!id) throw createError({ statusCode: 400, statusMessage: "Trunk ID required" });
  await Promise.all([
    mysqlExec(`DELETE FROM trunks WHERE trunkid='${id}'`),
    mysqlExec(`DELETE FROM sip WHERE id='tr-peer-${id}'`),
    mysqlExec(`DELETE FROM sip WHERE id='tr-user-${id}'`),
    mysqlExec(`DELETE FROM sip WHERE id='tr-reg-${id}'`),
    mysqlExec(`DELETE FROM sip WHERE id='pjsip-${id}'`),
    mysqlExec(`DELETE FROM iax WHERE id='tr-peer-${id}'`),
    mysqlExec(`DELETE FROM iax WHERE id='tr-user-${id}'`),
    mysqlExec(`DELETE FROM iax WHERE id='tr-reg-${id}'`),
    mysqlExec(`DELETE FROM trunk_dialpatterns WHERE trunkid=${id}`),
    mysqlExec(`DELETE FROM outbound_route_trunks WHERE trunkid=${id}`)
  ]);
  await reloadAsterisk();
  return { ok: true, deleted: id };
});

export { _id__delete as default };
//# sourceMappingURL=_id_.delete.mjs.map
