import { d as defineEventHandler, g as getRouterParam, c as createError, a as readBody, D as mysqlExec, W as reloadAsterisk } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _id__put = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n;
  const id = getRouterParam(event, "id");
  if (!id) throw createError({ statusCode: 400, statusMessage: "Trunk ID required" });
  const b = await readBody(event);
  const tech = String((_a = b.tech) != null ? _a : "sip").toLowerCase();
  const fields = [
    `name='${(_b = b.name) != null ? _b : ""}'`,
    `tech='${tech}'`,
    `outcid='${(_c = b.outcid) != null ? _c : ""}'`,
    `keepcid='${(_d = b.keepcid) != null ? _d : "off"}'`,
    `maxchans='${(_e = b.maxchans) != null ? _e : ""}'`,
    `dialoutprefix='${(_f = b.dialoutprefix) != null ? _f : ""}'`,
    `channelid='${(_g = b.channelid) != null ? _g : ""}'`,
    `usercontext='${(_h = b.usercontext) != null ? _h : ""}'`,
    `disabled='${(_i = b.disabled) != null ? _i : "off"}'`,
    `\`continue\`='${(_j = b.continue) != null ? _j : "off"}'`
  ];
  await mysqlExec(`UPDATE trunks SET ${fields.join(",")} WHERE trunkid=${id}`);
  if (tech === "sip" || tech === "iax" || tech === "iax2") {
    const table = tech === "sip" ? "sip" : "iax";
    await mysqlExec(`DELETE FROM ${table} WHERE id='tr-peer-${id}'`);
    await mysqlExec(`DELETE FROM ${table} WHERE id='tr-user-${id}'`);
    await mysqlExec(`DELETE FROM ${table} WHERE id='tr-reg-${id}'`);
    const peerdetails = String((_k = b.peerdetails) != null ? _k : "").trim();
    if (peerdetails) {
      const lines = peerdetails.split("\n");
      for (let i = 0; i < lines.length; i++) {
        const [kw, ...rest] = lines[i].split("=");
        const data = rest.join("=").trim();
        if (kw == null ? void 0 : kw.trim()) {
          await mysqlExec(`INSERT INTO ${table} (id, keyword, data, flags) VALUES ('tr-peer-${id}','${kw.trim()}','${data}',${i})`);
        }
      }
      await mysqlExec(`INSERT INTO ${table} (id, keyword, data, flags) VALUES ('tr-peer-${id}','account','tr-peer-${id}',0) ON DUPLICATE KEY UPDATE data='tr-peer-${id}'`);
    }
    const userconfig = String((_l = b.userconfig) != null ? _l : "").trim();
    if (userconfig) {
      const lines = userconfig.split("\n");
      for (let i = 0; i < lines.length; i++) {
        const [kw, ...rest] = lines[i].split("=");
        const data = rest.join("=").trim();
        if (kw == null ? void 0 : kw.trim()) {
          await mysqlExec(`INSERT INTO ${table} (id, keyword, data, flags) VALUES ('tr-user-${id}','${kw.trim()}','${data}',${i})`);
        }
      }
      await mysqlExec(`INSERT INTO ${table} (id, keyword, data, flags) VALUES ('tr-user-${id}','account','tr-user-${id}',0) ON DUPLICATE KEY UPDATE data='tr-user-${id}'`);
    }
    const register = String((_m = b.register) != null ? _m : "").trim();
    if (register) {
      await mysqlExec(`INSERT INTO ${table} (id, keyword, data, flags) VALUES ('tr-reg-${id}','register','${register}',0)`);
    }
  }
  if (tech === "pjsip") {
    await mysqlExec(`DELETE FROM sip WHERE id='pjsip-${id}'`);
    await mysqlExec(`DELETE FROM sip WHERE id='tr-reg-${id}'`);
    const pjsip = b.pjsip || {};
    const entries = Object.entries(pjsip);
    for (let i = 0; i < entries.length; i++) {
      const [kw, data] = entries[i];
      if (kw && data !== void 0) {
        await mysqlExec(`INSERT INTO sip (id, keyword, data, flags) VALUES ('pjsip-${id}','${kw}','${data}',${i})`);
      }
    }
    if (entries.length) {
      await mysqlExec(`INSERT INTO sip (id, keyword, data, flags) VALUES ('pjsip-${id}','account','pjsip-${id}',0) ON DUPLICATE KEY UPDATE data='pjsip-${id}'`);
    }
    const register = String((_n = b.register) != null ? _n : "").trim();
    if (register) {
      await mysqlExec(`INSERT INTO sip (id, keyword, data, flags) VALUES ('tr-reg-${id}','register','${register}',0)`);
    }
  }
  await mysqlExec(`DELETE FROM trunk_dialpatterns WHERE trunkid=${id}`);
  const patterns = b.dialpatterns || [];
  for (let i = 0; i < patterns.length; i++) {
    const p = patterns[i];
    if (p.prepend || p.prefix || p.pattern) {
      await mysqlExec(`INSERT INTO trunk_dialpatterns (trunkid, match_pattern_prefix, match_pattern_pass, prepend_digits, seq) VALUES (${id},'${p.prefix || ""}','${p.pattern || ""}','${p.prepend || ""}',${i})`);
    }
  }
  await reloadAsterisk();
  return { ok: true };
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
