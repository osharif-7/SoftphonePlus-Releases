import { d as defineEventHandler, X as serviceIsActive, C as runAsterisk } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const diskUsage = async () => {
  const out = await runAsterisk("core show uptime");
  return out ? "CLI reachable" : "CLI unavailable";
};
const systemStatus_get = defineEventHandler(async () => {
  const [asteriskRunning, mysqlRunning, httpRunning, uptime, managerStatus] = await Promise.all([
    serviceIsActive("asterisk"),
    serviceIsActive("mariadb"),
    serviceIsActive("httpd"),
    diskUsage(),
    runAsterisk("manager show connected")
  ]);
  const amiConnected = managerStatus.toLowerCase().includes("users connected");
  return [
    { name: "Asterisk", value: asteriskRunning ? "Running" : "Stopped", level: asteriskRunning ? "ok" : "error" },
    { name: "MySQL", value: mysqlRunning ? "Running" : "Stopped", level: mysqlRunning ? "ok" : "error" },
    { name: "Web (httpd)", value: httpRunning ? "Running" : "Stopped", level: httpRunning ? "ok" : "warn" },
    { name: "AMI", value: amiConnected ? "Reachable" : "No active sessions", level: amiConnected ? "ok" : "warn" },
    { name: "Asterisk CLI", value: uptime, level: uptime.includes("reachable") ? "ok" : "warn" }
  ];
});

export { systemStatus_get as default };
//# sourceMappingURL=system-status.get.mjs.map
