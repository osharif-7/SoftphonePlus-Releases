import { d as defineEventHandler, g as getRouterParam, F as mysqlQuery, c as createError } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _id__get = defineEventHandler(async (event) => {
  const id = getRouterParam(event, "id");
  const rows = await mysqlQuery(`SELECT cidlookup_id, IFNULL(description,''), IFNULL(sourcetype,''), IFNULL(cache,0), IFNULL(http_host,''), IFNULL(http_port,''), IFNULL(http_username,''), IFNULL(http_password,''), IFNULL(http_path,''), IFNULL(http_query,''), IFNULL(mysql_host,''), IFNULL(mysql_dbname,''), IFNULL(mysql_query,''), IFNULL(mysql_username,''), IFNULL(mysql_password,''), IFNULL(mysql_charset,''), IFNULL(opencnam_account_sid,''), IFNULL(opencnam_auth_token,'') FROM cidlookup WHERE cidlookup_id=${id}`);
  if (!rows.length) throw createError({ statusCode: 404, statusMessage: "CID lookup not found" });
  const c = rows[0].split("	");
  return { id: c[0], description: c[1], sourcetype: c[2], cache: c[3] === "1", http_host: c[4], http_port: c[5], http_username: c[6], http_password: c[7], http_path: c[8], http_query: c[9], mysql_host: c[10], mysql_dbname: c[11], mysql_query: c[12], mysql_username: c[13], mysql_password: c[14], mysql_charset: c[15], opencnam_account_sid: c[16], opencnam_auth_token: c[17] };
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
