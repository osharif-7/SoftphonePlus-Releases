import { d as defineEventHandler, g as getRouterParam, a as readBody, D as mysqlExec, W as reloadAsterisk } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _id__put = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p;
  const id = getRouterParam(event, "id");
  const b = await readBody(event);
  const fields = [
    `description='${(_a = b.description) != null ? _a : ""}'`,
    `sourcetype='${(_b = b.sourcetype) != null ? _b : ""}'`,
    `cache=${b.cache ? 1 : 0}`,
    `http_host='${(_c = b.http_host) != null ? _c : ""}'`,
    `http_port='${(_d = b.http_port) != null ? _d : ""}'`,
    `http_username='${(_e = b.http_username) != null ? _e : ""}'`,
    `http_password='${(_f = b.http_password) != null ? _f : ""}'`,
    `http_path='${(_g = b.http_path) != null ? _g : ""}'`,
    `http_query='${(_h = b.http_query) != null ? _h : ""}'`,
    `mysql_host='${(_i = b.mysql_host) != null ? _i : ""}'`,
    `mysql_dbname='${(_j = b.mysql_dbname) != null ? _j : ""}'`,
    `mysql_query='${((_k = b.mysql_query) != null ? _k : "").replace(/'/g, "''")}'`,
    `mysql_username='${(_l = b.mysql_username) != null ? _l : ""}'`,
    `mysql_password='${(_m = b.mysql_password) != null ? _m : ""}'`,
    `mysql_charset='${(_n = b.mysql_charset) != null ? _n : ""}'`,
    `opencnam_account_sid='${(_o = b.opencnam_account_sid) != null ? _o : ""}'`,
    `opencnam_auth_token='${(_p = b.opencnam_auth_token) != null ? _p : ""}'`
  ];
  await mysqlExec(`UPDATE cidlookup SET ${fields.join(",")} WHERE cidlookup_id=${id}`);
  await reloadAsterisk();
  return { ok: true };
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
