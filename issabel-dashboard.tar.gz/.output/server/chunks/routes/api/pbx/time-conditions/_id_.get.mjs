import { d as defineEventHandler, g as getRouterParam, F as mysqlQuery, c as createError } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _id__get = defineEventHandler(async (event) => {
  const id = getRouterParam(event, "id");
  const rows = await mysqlQuery(`SELECT timeconditions_id, IFNULL(displayname,''), IFNULL(time,0), IFNULL(truegoto,''), IFNULL(falsegoto,''), IFNULL(priority,0), IFNULL(generate_hint,0) FROM timeconditions WHERE timeconditions_id=${id}`);
  if (!rows.length) throw createError({ statusCode: 404, statusMessage: "Time condition not found" });
  const c = rows[0].split("	");
  return { id: c[0], displayname: c[1], time: Number(c[2]), truegoto: c[3], falsegoto: c[4], priority: c[5], generate_hint: c[6] === "1" };
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
