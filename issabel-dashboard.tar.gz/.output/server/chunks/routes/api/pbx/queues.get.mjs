import { d as defineEventHandler, F as mysqlQuery, C as runAsterisk } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const parseQueueRuntime = async () => {
  const out = await runAsterisk("queue show");
  const lines = out.split("\n");
  const runtime = /* @__PURE__ */ new Map();
  let currentQueue = "";
  for (const rawLine of lines) {
    const line = rawLine.trim();
    if (!line || line.startsWith("No queues")) continue;
    const queueHeader = line.match(/^([A-Za-z0-9_\-]+)\s+has\s+(\d+)\s+calls/i);
    if (queueHeader) {
      currentQueue = queueHeader[1];
      runtime.set(currentQueue, { members: 0, waiting: Number(queueHeader[2]) });
      continue;
    }
    if (currentQueue && line.match(/^\S+\/\S+\s+\(/)) {
      const item = runtime.get(currentQueue);
      if (item) item.members += 1;
    }
  }
  return runtime;
};
const queues_get = defineEventHandler(async () => {
  const rows = await mysqlQuery("SELECT extension, IFNULL(descr,'') FROM queues_config ORDER BY extension");
  const runtime = await parseQueueRuntime();
  return rows.map((line) => {
    var _a;
    const [extension = "", descr = ""] = line.split("	");
    const live = (_a = runtime.get(extension)) != null ? _a : { members: 0, waiting: 0 };
    return {
      extension,
      name: extension,
      description: descr,
      members: live.members,
      waiting: live.waiting
    };
  });
});

export { queues_get as default };
//# sourceMappingURL=queues.get.mjs.map
