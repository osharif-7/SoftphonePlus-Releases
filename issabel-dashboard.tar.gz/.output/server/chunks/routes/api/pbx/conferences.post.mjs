import { d as defineEventHandler, a as readBody, c as createError, D as mysqlExec, W as reloadAsterisk } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const conferences_post = defineEventHandler(async (event) => {
  var _a, _b, _c, _d;
  const body = await readBody(event);
  const exten = String((_a = body.exten) != null ? _a : "").trim();
  const description = String((_b = body.description) != null ? _b : "").trim();
  const userpin = String((_c = body.userpin) != null ? _c : "").trim();
  const adminpin = String((_d = body.adminpin) != null ? _d : "").trim();
  if (!exten) throw createError({ statusCode: 400, statusMessage: "Conference number required" });
  const r = await mysqlExec(`INSERT INTO meetme (exten, description, userpin, adminpin, options, users) VALUES ('${exten}','${description}','${userpin}','${adminpin}','',0)`);
  if (!r.ok) throw createError({ statusCode: 500, statusMessage: r.error });
  await reloadAsterisk();
  return { ok: true };
});

export { conferences_post as default };
//# sourceMappingURL=conferences.post.mjs.map
