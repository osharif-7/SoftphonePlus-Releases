import { d as defineEventHandler, g as getRouterParam, F as mysqlQuery, c as createError } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _id__get = defineEventHandler(async (event) => {
  const id = getRouterParam(event, "id");
  const rows = await mysqlQuery(`SELECT route_id, IFNULL(name,''), IFNULL(outcid,''), IFNULL(outcid_mode,''), IFNULL(password,''), IFNULL(emergency_route,''), IFNULL(intracompany_route,''), IFNULL(mohclass,''), IFNULL(time_group_id,''), IFNULL(dest,'') FROM outbound_routes WHERE route_id=${id}`);
  if (!rows.length) throw createError({ statusCode: 404, statusMessage: "Route not found" });
  const c = rows[0].split("	");
  const patterns = await mysqlQuery(`SELECT IFNULL(prepend,''), IFNULL(prefix,''), IFNULL(match_pattern_pass,''), IFNULL(match_cid,'') FROM outbound_route_patterns WHERE route_id=${id}`);
  const trunks = await mysqlQuery(`SELECT trunk_id, \`rank\` FROM outbound_route_trunks WHERE route_id=${id} ORDER BY \`rank\``);
  return {
    route_id: c[0],
    name: c[1],
    outcid: c[2],
    outcid_mode: c[3],
    password: c[4],
    emergency_route: c[5],
    intracompany_route: c[6],
    mohclass: c[7],
    time_group_id: c[8],
    dest: c[9],
    patterns: patterns.map((p) => {
      const [prepend, prefix, match, cid] = p.split("	");
      return { prepend, prefix, match, cid };
    }),
    trunks: trunks.map((t) => {
      const [tid, rank] = t.split("	");
      return { trunk_id: Number(tid), rank: Number(rank) };
    })
  };
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
