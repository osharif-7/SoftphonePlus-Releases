import { d as defineEventHandler, g as getRouterParam, a as readBody, D as mysqlExec, W as reloadAsterisk } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _id__put = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l;
  const id = getRouterParam(event, "id");
  const b = await readBody(event);
  await mysqlExec(`UPDATE outbound_routes SET name='${(_a = b.name) != null ? _a : ""}', outcid='${(_b = b.outcid) != null ? _b : ""}', password='${(_c = b.password) != null ? _c : ""}', emergency_route='${(_d = b.emergency_route) != null ? _d : ""}' WHERE route_id=${id}`);
  await mysqlExec(`DELETE FROM outbound_route_patterns WHERE route_id=${id}`);
  for (const p of (_e = b.patterns) != null ? _e : []) {
    await mysqlExec(`INSERT INTO outbound_route_patterns (route_id, prepend, prefix, match_pattern_pass, match_cid) VALUES (${id},'${(_f = p.prepend) != null ? _f : ""}','${(_g = p.prefix) != null ? _g : ""}','${(_h = p.match) != null ? _h : ""}','${(_i = p.cid) != null ? _i : ""}')`);
  }
  await mysqlExec(`DELETE FROM outbound_route_trunks WHERE route_id=${id}`);
  const trunkIds = (_l = (_k = b.trunkIds) != null ? _k : (_j = b.trunks) == null ? void 0 : _j.map((t) => t.trunk_id)) != null ? _l : [];
  for (let i = 0; i < trunkIds.length; i++) {
    await mysqlExec(`INSERT INTO outbound_route_trunks (route_id, trunk_id, \`rank\`) VALUES (${id},${trunkIds[i]},${i})`);
  }
  await reloadAsterisk();
  return { ok: true };
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
