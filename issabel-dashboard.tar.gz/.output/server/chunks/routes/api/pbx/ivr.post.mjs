import { d as defineEventHandler, a as readBody, c as createError, D as mysqlExec, W as reloadAsterisk } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const ivr_post = defineEventHandler(async (event) => {
  var _a, _b, _c;
  const body = await readBody(event);
  const name = String((_a = body.name) != null ? _a : "").trim();
  const description = String((_b = body.description) != null ? _b : "").trim();
  const timeout = Number((_c = body.timeout) != null ? _c : 10);
  if (!name) throw createError({ statusCode: 400, statusMessage: "IVR name is required" });
  const r = await mysqlExec(
    `INSERT INTO ivr_details (name, description, timeout_time, timeout_loops, invalid_loops, directdial, retvm) VALUES ('${name}','${description}',${timeout},3,3,'','no')`
  );
  if (!r.ok) throw createError({ statusCode: 500, statusMessage: r.error });
  await reloadAsterisk();
  return { ok: true };
});

export { ivr_post as default };
//# sourceMappingURL=ivr.post.mjs.map
