import { d as defineEventHandler, g as getRouterParam, F as mysqlQuery, c as createError } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _id__get = defineEventHandler(async (event) => {
  const id = getRouterParam(event, "id");
  const rows = await mysqlQuery(`SELECT announcement_id, IFNULL(description,''), IFNULL(recording_id,0), IFNULL(allow_skip,0), IFNULL(post_dest,''), IFNULL(return_ivr,0), IFNULL(noanswer,0), IFNULL(repeat_msg,'') FROM announcement WHERE announcement_id=${id}`);
  if (!rows.length) throw createError({ statusCode: 404, statusMessage: "Announcement not found" });
  const c = rows[0].split("	");
  return { id: c[0], description: c[1], recording_id: c[2], allow_skip: c[3] === "1", post_dest: c[4], return_ivr: c[5] === "1", noanswer: c[6] === "1", repeat_msg: c[7] };
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
