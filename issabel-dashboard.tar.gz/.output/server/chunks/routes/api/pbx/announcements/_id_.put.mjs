import { d as defineEventHandler, g as getRouterParam, a as readBody, D as mysqlExec, W as reloadAsterisk } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _id__put = defineEventHandler(async (event) => {
  var _a, _b, _c, _d;
  const id = getRouterParam(event, "id");
  const b = await readBody(event);
  await mysqlExec(`UPDATE announcement SET description='${(_a = b.description) != null ? _a : ""}', recording_id=${Number((_b = b.recording_id) != null ? _b : 0)}, allow_skip=${b.allow_skip ? 1 : 0}, post_dest='${(_c = b.post_dest) != null ? _c : ""}', return_ivr=${b.return_ivr ? 1 : 0}, noanswer=${b.noanswer ? 1 : 0}, repeat_msg='${(_d = b.repeat_msg) != null ? _d : ""}' WHERE announcement_id=${id}`);
  await reloadAsterisk();
  return { ok: true };
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
