import { d as defineEventHandler, F as mysqlQuery } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const inboundRoutes_get = defineEventHandler(async () => {
  const rows = await mysqlQuery(
    "SELECT extension, IFNULL(cidnum,''), IFNULL(description,''), IFNULL(destination,'') FROM incoming ORDER BY extension"
  );
  return rows.map((r) => {
    const [extension, cidnum, description, destination] = r.split("	");
    return { extension, cidnum, description, destination };
  });
});

export { inboundRoutes_get as default };
//# sourceMappingURL=inbound-routes.get.mjs.map
