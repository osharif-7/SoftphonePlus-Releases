import { d as defineEventHandler, F as mysqlQuery } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const recordings_get = defineEventHandler(async () => {
  const rows = await mysqlQuery(
    "SELECT id, IFNULL(displayname,''), CAST(IFNULL(filename,'') AS CHAR), IFNULL(description,''), IFNULL(fcode,0), IFNULL(fcode_pass,'') FROM recordings WHERE displayname <> '__invalid' ORDER BY displayname"
  );
  return rows.map((r) => {
    const [id, displayname, filename, description, fcode, fcode_pass] = r.split("	");
    return { id: parseInt(id), displayname, filename, description, fcode: fcode === "1", fcode_pass };
  });
});

export { recordings_get as default };
//# sourceMappingURL=recordings.get.mjs.map
