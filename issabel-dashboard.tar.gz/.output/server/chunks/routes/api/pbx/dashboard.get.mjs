import { d as defineEventHandler, E as execCmd, X as serviceIsActive } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const getCpuPercent = async () => {
  const r = await execCmd("sh", ["-c", "top -bn1 | head -5"]);
  const match = r.stdout.match(/(\d+\.\d+)\s*id/);
  if (match) return Math.round(100 - parseFloat(match[1]));
  const match2 = r.stdout.match(/(\d+\.\d+)%?\s*us/);
  if (match2) return Math.round(parseFloat(match2[1]));
  return 0;
};
const getMemInfo = async () => {
  const r = await execCmd("sh", ["-c", "free -m | head -4"]);
  const lines = r.stdout.split("\n");
  let ramTotal = 0, ramUsed = 0, swapTotal = 0, swapUsed = 0;
  for (const line of lines) {
    const parts = line.trim().split(/\s+/);
    if (line.toLowerCase().startsWith("mem:")) {
      ramTotal = parseInt(parts[1]) || 0;
      ramUsed = parseInt(parts[2]) || 0;
    }
    if (line.toLowerCase().startsWith("swap:")) {
      swapTotal = parseInt(parts[1]) || 0;
      swapUsed = parseInt(parts[2]) || 0;
    }
  }
  return {
    ramPercent: ramTotal > 0 ? Math.round(ramUsed / ramTotal * 100) : 0,
    swapPercent: swapTotal > 0 ? Math.round(swapUsed / swapTotal * 100) : 0,
    ramTotal: `${(ramTotal / 1024).toFixed(2)} GB`,
    swapTotal: `${(swapTotal / 1024).toFixed(2)} GB`
  };
};
const getCpuInfo = async () => {
  const r = await execCmd("sh", ["-c", "cat /proc/cpuinfo | grep 'model name' | head -1"]);
  const match = r.stdout.match(/:\s*(.+)/);
  const cpuInfo = match ? match[1].trim() : "Unknown CPU";
  const r2 = await execCmd("sh", ["-c", "cat /proc/cpuinfo | grep 'cpu MHz' | head -1"]);
  const mhzMatch = r2.stdout.match(/:\s*(.+)/);
  const cpuSpeed = mhzMatch ? `${parseFloat(mhzMatch[1]).toFixed(2)} MHz` : "N/A";
  return { cpuInfo, cpuSpeed };
};
const getUptime = async () => {
  const r = await execCmd("uptime", ["-p"]);
  return r.stdout.trim().replace("up ", "") || "N/A";
};
const getLastLogin = async () => {
  var _a, _b;
  const r = await execCmd("last", ["-1", "-R"]);
  const line = (_b = (_a = r.stdout.split("\n")[0]) == null ? void 0 : _a.trim()) != null ? _b : "";
  return line || "N/A";
};
const getDiskInfo = async () => {
  const r = await execCmd("df", ["-h", "--output=source,size,used,avail,pcent,target", "-x", "tmpfs", "-x", "devtmpfs"]);
  const lines = r.stdout.trim().split("\n").slice(1);
  return lines.map((line) => {
    var _a, _b, _c, _d, _e;
    const parts = line.trim().split(/\s+/);
    return {
      filesystem: (_a = parts[0]) != null ? _a : "",
      size: (_b = parts[1]) != null ? _b : "",
      used: (_c = parts[2]) != null ? _c : "",
      available: (_d = parts[3]) != null ? _d : "",
      usePercent: parseInt(parts[4]) || 0,
      mountPoint: (_e = parts[5]) != null ? _e : ""
    };
  });
};
const getServices = async () => {
  const names = [
    { id: "asterisk", label: "Telephony Service" },
    { id: "mariadb", label: "Database Service" },
    { id: "httpd", label: "Web Server" },
    { id: "postfix", label: "Email Service" },
    { id: "hylafax", label: "Fax Service" },
    { id: "issabel-callcenterd", label: "SoftCall Plus Call Center Service" }
  ];
  const results = await Promise.all(
    names.map(async (s) => {
      const status = await serviceIsActive(s.id);
      return { name: s.label, ...status };
    })
  );
  return results;
};
const dashboard_get = defineEventHandler(async () => {
  const [cpuPercent, memInfo, cpuDetails, uptime, lastLogin, disks, services] = await Promise.all([
    getCpuPercent(),
    getMemInfo(),
    getCpuInfo(),
    getUptime(),
    getLastLogin(),
    getDiskInfo(),
    getServices()
  ]);
  return {
    resources: {
      cpuPercent,
      ramPercent: memInfo.ramPercent,
      swapPercent: memInfo.swapPercent,
      cpuInfo: cpuDetails.cpuInfo,
      cpuSpeed: cpuDetails.cpuSpeed,
      uptime,
      ramTotal: memInfo.ramTotal,
      swapTotal: memInfo.swapTotal,
      lastLogin
    },
    disks,
    services
  };
});

export { dashboard_get as default };
//# sourceMappingURL=dashboard.get.mjs.map
