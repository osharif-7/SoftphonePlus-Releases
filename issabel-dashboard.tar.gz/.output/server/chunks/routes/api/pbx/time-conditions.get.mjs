import { d as defineEventHandler, F as mysqlQuery } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const timeConditions_get = defineEventHandler(async () => {
  const rows = await mysqlQuery(
    "SELECT tc.timeconditions_id, IFNULL(tc.displayname,''), IFNULL(tg.description,''), IFNULL(tc.truegoto,''), IFNULL(tc.falsegoto,'') FROM timeconditions tc LEFT JOIN timegroups_groups tg ON tg.id=tc.time ORDER BY tc.timeconditions_id"
  );
  return rows.map((r) => {
    const [id, name, timeGroup, trueDest, falseDest] = r.split("	");
    return { id, name, timeGroup, trueDest, falseDest };
  });
});

export { timeConditions_get as default };
//# sourceMappingURL=time-conditions.get.mjs.map
