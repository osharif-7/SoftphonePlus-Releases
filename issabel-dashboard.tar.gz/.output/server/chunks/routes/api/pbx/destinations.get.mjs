import { d as defineEventHandler, F as mysqlQuery } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const destinations_get = defineEventHandler(async () => {
  const [
    extensions,
    queues,
    ivrs,
    ringGroups,
    timeConditions,
    announcements,
    conferences,
    recordings,
    trunks,
    miscdests,
    disa,
    languages,
    setcid
  ] = await Promise.all([
    mysqlQuery("SELECT extension, IFNULL(name,'') FROM users ORDER BY extension"),
    mysqlQuery("SELECT extension, IFNULL(descr,'') FROM queues_config ORDER BY extension"),
    mysqlQuery("SELECT id, IFNULL(name,'') FROM ivr_details ORDER BY id"),
    mysqlQuery("SELECT grpnum, IFNULL(description,'') FROM ringgroups ORDER BY grpnum"),
    mysqlQuery("SELECT timeconditions_id, IFNULL(displayname,'') FROM timeconditions ORDER BY timeconditions_id"),
    mysqlQuery("SELECT announcement_id, IFNULL(description,'') FROM announcement ORDER BY announcement_id"),
    mysqlQuery("SELECT exten, IFNULL(description,'') FROM meetme ORDER BY exten"),
    mysqlQuery("SELECT id, IFNULL(displayname,'') FROM recordings ORDER BY id"),
    mysqlQuery("SELECT trunkid, IFNULL(name,''), IFNULL(tech,'') FROM trunks ORDER BY trunkid"),
    mysqlQuery("SELECT id, IFNULL(description,''), IFNULL(destdial,'') FROM miscdests ORDER BY id"),
    mysqlQuery("SELECT id, IFNULL(displayname,'') FROM disa ORDER BY id").catch(() => []),
    mysqlQuery("SELECT language_id, IFNULL(description,'') FROM languages ORDER BY language_id").catch(() => []),
    mysqlQuery("SELECT callerid_id, IFNULL(description,'') FROM setcid ORDER BY callerid_id").catch(() => [])
  ]);
  const groups = [];
  const parse = (rows, type, label, prefix, sep = ",") => {
    if (!rows.length) return;
    const items = rows.map((r) => {
      var _a;
      const parts = r.split("	");
      const id = (_a = parts[0]) != null ? _a : "";
      const name = parts[1] || id;
      return { label: `${name} <${id}>`, value: `${prefix}${id}${sep}1` };
    });
    groups.push({ label, type, items });
  };
  parse(announcements, "announcements", "Announcements", "app-announcement-");
  parse([], "callrecording", "Call Recording", "");
  groups.push({ label: "Callback", type: "callback", items: [] });
  groups.push({ label: "Class of Service", type: "cos", items: [] });
  parse(conferences, "conferences", "Conferences", "ext-meetme,");
  groups.push({ label: "Custom Applications", type: "custom", items: [] });
  parse(disa, "disa", "DISA", "disa,");
  groups.push({ label: "Dynamic Routes", type: "dynroute", items: [] });
  if (extensions.length) {
    const extItems = extensions.map((r) => {
      const [ext, name] = r.split("	");
      return { label: `${name || ext} <${ext}>`, value: `from-did-direct,${ext},1` };
    });
    groups.push({ label: "Extensions", type: "extensions", items: extItems });
  }
  groups.push({ label: "Feature Code Admin", type: "featurecodeadmin", items: [] });
  if (ivrs.length) {
    const ivrItems = ivrs.map((r) => {
      const [id, name] = r.split("	");
      return { label: `${name || id} <${id}>`, value: `ivr-${id},s,1` };
    });
    groups.push({ label: "IVR", type: "ivr", items: ivrItems });
  }
  parse(languages, "languages", "Languages", "app-languages,");
  if (miscdests.length) {
    const mdItems = miscdests.map((r) => {
      const [id, desc] = r.split("	");
      return { label: `${desc || id}`, value: `ext-miscdests,${id},1` };
    });
    groups.push({ label: "Misc Destinations", type: "miscdests", items: mdItems });
  }
  groups.push({ label: "Paging and Intercom", type: "paging", items: [] });
  groups.push({ label: "Phonebook Directory", type: "phonebook", items: [] });
  if (queues.length) {
    const qItems = queues.map((r) => {
      const [ext, desc] = r.split("	");
      return { label: `${desc || ext} <${ext}>`, value: `ext-queues,${ext},1` };
    });
    groups.push({ label: "Queues", type: "queues", items: qItems });
  }
  groups.push({ label: "Queue Priorities", type: "queuepriority", items: [] });
  if (ringGroups.length) {
    const rgItems = ringGroups.map((r) => {
      const [num, desc] = r.split("	");
      return { label: `${desc || num} <${num}>`, value: `ext-group,${num},1` };
    });
    groups.push({ label: "Ring Groups", type: "ringgroups", items: rgItems });
  }
  if (setcid.length) {
    const cidItems = setcid.map((r) => {
      const [id, desc] = r.split("	");
      return { label: `${desc || id}`, value: `app-setcid,${id},1` };
    });
    groups.push({ label: "Set Caller ID", type: "setcid", items: cidItems });
  }
  groups.push({
    label: "Terminate Call",
    type: "terminate",
    items: [
      { label: "Hangup", value: "app-blackhole,hangup,1" },
      { label: "Congestion", value: "app-blackhole,congestion,1" },
      { label: "Busy", value: "app-blackhole,busy,1" },
      { label: "Play SIT Tone", value: "app-blackhole,zapateller,1" },
      { label: "Put on Hold Forever", value: "app-blackhole,musiconhold,1" },
      { label: "Play ringtone", value: "app-blackhole,ring,1" }
    ]
  });
  if (timeConditions.length) {
    const tcItems = timeConditions.map((r) => {
      const [id, name] = r.split("	");
      return { label: `${name || id} <${id}>`, value: `timeconditions,${id},1` };
    });
    groups.push({ label: "Time Conditions", type: "timeconditions", items: tcItems });
  }
  if (trunks.length) {
    const tItems = trunks.map((r) => {
      const [id, name, tech] = r.split("	");
      return { label: `${name || `Trunk ${id}`} (${tech})`, value: `ext-trunk,${id},1` };
    });
    groups.push({ label: "Trunks", type: "trunks", items: tItems });
  }
  groups.push({ label: "Voicemail Blasting", type: "vmblast", items: [] });
  return groups.filter((g) => g.items.length > 0);
});

export { destinations_get as default };
//# sourceMappingURL=destinations.get.mjs.map
