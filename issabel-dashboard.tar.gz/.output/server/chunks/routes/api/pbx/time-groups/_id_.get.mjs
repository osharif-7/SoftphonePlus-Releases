import { d as defineEventHandler, g as getRouterParam, F as mysqlQuery, c as createError } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _id__get = defineEventHandler(async (event) => {
  const id = getRouterParam(event, "id");
  const rows = await mysqlQuery(`SELECT id, IFNULL(description,'') FROM timegroups_groups WHERE id=${id}`);
  if (!rows.length) throw createError({ statusCode: 404, statusMessage: "Time group not found" });
  const [gid, description] = rows[0].split("	");
  const details = await mysqlQuery(`SELECT id, IFNULL(time,'') FROM timegroups_details WHERE timegroupid=${id}`);
  const times = details.map((d) => {
    const [did, time] = d.split("	");
    return { id: did, time };
  });
  return { id: gid, description, times };
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
