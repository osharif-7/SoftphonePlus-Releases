import { d as defineEventHandler, g as getRouterParam, a as readBody, D as mysqlExec, W as reloadAsterisk } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _id__put = defineEventHandler(async (event) => {
  var _a, _b, _c;
  const id = getRouterParam(event, "id");
  const b = await readBody(event);
  await mysqlExec(`UPDATE timegroups_groups SET description='${(_a = b.description) != null ? _a : ""}' WHERE id=${id}`);
  await mysqlExec(`DELETE FROM timegroups_details WHERE timegroupid=${id}`);
  for (const t of (_b = b.times) != null ? _b : []) {
    const time = String((_c = t.time) != null ? _c : "").trim();
    if (time) await mysqlExec(`INSERT INTO timegroups_details (timegroupid, time) VALUES (${id},'${time}')`);
  }
  await reloadAsterisk();
  return { ok: true };
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
