import { d as defineEventHandler, a as readBody, c as createError, D as mysqlExec, W as reloadAsterisk } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const cidLookup_post = defineEventHandler(async (event) => {
  var _a, _b;
  const body = await readBody(event);
  const description = String((_a = body.description) != null ? _a : "").trim();
  const sourcetype = String((_b = body.sourcetype) != null ? _b : "http").trim();
  if (!description) throw createError({ statusCode: 400, statusMessage: "Description required" });
  const r = await mysqlExec(
    `INSERT INTO cidlookup (description, sourcetype, cache) VALUES ('${description}','${sourcetype}',0)`
  );
  if (!r.ok) throw createError({ statusCode: 500, statusMessage: r.error });
  await reloadAsterisk();
  return { ok: true };
});

export { cidLookup_post as default };
//# sourceMappingURL=cid-lookup.post.mjs.map
