import { d as defineEventHandler, F as mysqlQuery } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const disa_get = defineEventHandler(async () => {
  const rows = await mysqlQuery("SELECT disa_id, IFNULL(displayname,''), IFNULL(pin,''), IFNULL(cid,''), IFNULL(context,'from-internal'), IFNULL(digittimeout,5), IFNULL(resptimeout,10), IFNULL(hangup,'no'), IFNULL(keepcid,1) FROM disa ORDER BY disa_id").catch(() => []);
  return rows.map((r) => {
    const c = r.split("	");
    return { id: c[0], displayname: c[1], pin: c[2], cid: c[3], context: c[4], digittimeout: Number(c[5]), resptimeout: Number(c[6]), hangup: c[7], keepcid: c[8] === "1" };
  });
});

export { disa_get as default };
//# sourceMappingURL=disa.get.mjs.map
