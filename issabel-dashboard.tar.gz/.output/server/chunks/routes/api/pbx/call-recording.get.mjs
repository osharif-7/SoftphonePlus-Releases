import { d as defineEventHandler, F as mysqlQuery } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const callRecording_get = defineEventHandler(async () => {
  const rows = await mysqlQuery("SELECT callrecording_id, IFNULL(description,''), IFNULL(callrecording_mode,'') FROM callrecording ORDER BY callrecording_id").catch(() => []);
  return rows.map((r) => {
    const [id, description, mode] = r.split("	");
    return { id, description, mode };
  });
});

export { callRecording_get as default };
//# sourceMappingURL=call-recording.get.mjs.map
