import { d as defineEventHandler, F as mysqlQuery } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const timeGroups_get = defineEventHandler(async () => {
  const rows = await mysqlQuery("SELECT g.id, g.description, COUNT(d.id) FROM timegroups_groups g LEFT JOIN timegroups_details d ON d.timegroupid=g.id GROUP BY g.id ORDER BY g.id");
  return rows.map((r) => {
    const [id, description, entryCount] = r.split("	");
    return { id, description, entryCount: Number(entryCount) };
  });
});

export { timeGroups_get as default };
//# sourceMappingURL=time-groups.get.mjs.map
