import { d as defineEventHandler, a as readBody, c as createError, D as mysqlExec, W as reloadAsterisk } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const callRecording_post = defineEventHandler(async (event) => {
  var _a, _b, _c;
  const b = await readBody(event);
  if (!b.description) throw createError({ statusCode: 400, statusMessage: "Description required" });
  await mysqlExec(`INSERT INTO callrecording (description, callrecording_mode, dest) VALUES ('${(_a = b.description) != null ? _a : ""}','${(_b = b.callrecording_mode) != null ? _b : "allow"}','${(_c = b.dest) != null ? _c : ""}')`);
  await reloadAsterisk();
  return { ok: true };
});

export { callRecording_post as default };
//# sourceMappingURL=call-recording.post.mjs.map
