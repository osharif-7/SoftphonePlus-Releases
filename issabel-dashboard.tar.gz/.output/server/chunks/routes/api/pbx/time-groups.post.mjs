import { d as defineEventHandler, a as readBody, c as createError, D as mysqlExec, F as mysqlQuery, W as reloadAsterisk } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const timeGroups_post = defineEventHandler(async (event) => {
  var _a, _b, _c;
  const body = await readBody(event);
  const description = String((_a = body.description) != null ? _a : "").trim();
  if (!description) throw createError({ statusCode: 400, statusMessage: "Description required" });
  const r = await mysqlExec(`INSERT INTO timegroups_groups (description) VALUES ('${description}')`);
  if (!r.ok) throw createError({ statusCode: 500, statusMessage: r.error });
  const timeEntries = (_b = body.times) != null ? _b : [];
  if (timeEntries.length) {
    const idRows = await mysqlQuery(`SELECT id FROM timegroups_groups WHERE description='${description}' ORDER BY id DESC LIMIT 1`);
    const groupId = (_c = idRows[0]) != null ? _c : "0";
    for (const t of timeEntries) {
      await mysqlExec(`INSERT INTO timegroups_details (timegroupid, time) VALUES (${groupId},'${t}')`);
    }
  }
  await reloadAsterisk();
  return { ok: true };
});

export { timeGroups_post as default };
//# sourceMappingURL=time-groups.post.mjs.map
