import { d as defineEventHandler, g as getRouterParam, F as mysqlQuery, c as createError } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _id__get = defineEventHandler(async (event) => {
  const id = getRouterParam(event, "id");
  const rows = await mysqlQuery(`SELECT callrecording_id, IFNULL(description,''), IFNULL(callrecording_mode,'allow'), IFNULL(dest,'') FROM callrecording WHERE callrecording_id=${id}`);
  if (!rows.length) throw createError({ statusCode: 404, statusMessage: "Not found" });
  const c = rows[0].split("	");
  return { id: c[0], description: c[1], callrecording_mode: c[2], dest: c[3] };
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
