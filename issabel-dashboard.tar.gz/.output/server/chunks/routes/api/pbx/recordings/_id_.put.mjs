import { d as defineEventHandler, g as getRouterParam, c as createError, Y as readMultipartFormData, D as mysqlExec, W as reloadAsterisk } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _id__put = defineEventHandler(async (event) => {
  const id = getRouterParam(event, "id");
  if (!id) throw createError({ statusCode: 400, statusMessage: "Recording ID required" });
  const formData = await readMultipartFormData(event);
  if (!formData) throw createError({ statusCode: 400, statusMessage: "Form data required" });
  let displayname = "";
  let description = "";
  let fileData = null;
  let fileName = "";
  for (const field of formData) {
    if (field.name === "displayname") displayname = field.data.toString().trim();
    else if (field.name === "description") description = field.data.toString().trim();
    else if (field.name === "file" && field.data.length > 0) {
      fileData = field.data;
      fileName = field.filename || "recording.wav";
    }
  }
  const dn = displayname.replace(/'/g, "''");
  const desc = description.replace(/'/g, "''");
  let fileUpdate = "";
  if (fileData) {
    const safeName = displayname.replace(/[^a-zA-Z0-9_-]/g, "_").toLowerCase();
    const ext = fileName.split(".").pop() || "wav";
    const destFile = `custom/${safeName}`;
    const fullPath = `/var/lib/asterisk/sounds/${destFile}.${ext}`;
    const { writeFile, chmod } = await import('node:fs/promises');
    await writeFile(fullPath, fileData);
    await chmod(fullPath, 420);
    fileUpdate = `, filename='${destFile}'`;
  }
  await mysqlExec(
    `UPDATE recordings SET displayname='${dn}', description='${desc}'${fileUpdate} WHERE id=${id}`
  );
  await reloadAsterisk();
  return { ok: true };
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
