import { d as defineEventHandler, g as getRouterParam, c as createError, F as mysqlQuery, D as mysqlExec, W as reloadAsterisk } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _id__delete = defineEventHandler(async (event) => {
  const id = getRouterParam(event, "id");
  if (!id) throw createError({ statusCode: 400, statusMessage: "Recording ID required" });
  const rows = await mysqlQuery(`SELECT IFNULL(filename,'') FROM recordings WHERE id=${id}`);
  if (rows.length) {
    const filename = rows[0].trim();
    if (filename) {
      const basePath = "/var/lib/asterisk/sounds/";
      const { unlink } = await import('node:fs/promises');
      const extensions = ["wav", "gsm", "ulaw", "alaw", "sln", "g729", "g722", "mp3", "ogg"];
      for (const ext of extensions) {
        try {
          await unlink(`${basePath}${filename}.${ext}`);
        } catch {
        }
      }
    }
  }
  await mysqlExec(`DELETE FROM recordings WHERE id=${id}`);
  await reloadAsterisk();
  return { ok: true };
});

export { _id__delete as default };
//# sourceMappingURL=_id_.delete.mjs.map
