import { d as defineEventHandler, g as getRouterParam, c as createError, a as readBody, D as mysqlExec, C as runAsterisk, W as reloadAsterisk } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _id__put = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m;
  const id = getRouterParam(event, "id");
  if (!id) throw createError({ statusCode: 400, statusMessage: "Queue required" });
  const body = await readBody(event);
  const fields = [
    `descr='${(_a = body.descr) != null ? _a : ""}'`,
    `grppre='${(_b = body.grppre) != null ? _b : ""}'`,
    `alertinfo='${(_c = body.alertinfo) != null ? _c : ""}'`,
    `ringing=${body.ringing ? 1 : 0}`,
    `maxwait='${(_d = body.maxwait) != null ? _d : ""}'`,
    `password='${(_e = body.password) != null ? _e : ""}'`,
    `dest='${(_f = body.dest) != null ? _f : ""}'`,
    `cwignore=${body.cwignore ? 1 : 0}`,
    `qregex='${(_g = body.qregex) != null ? _g : ""}'`,
    `queuewait=${body.queuewait ? 1 : 0}`,
    `qnoanswer=${body.qnoanswer ? 1 : 0}`,
    `callconfirm=${body.callconfirm ? 1 : 0}`,
    `destcontinue='${(_h = body.destcontinue) != null ? _h : ""}'`
  ];
  if (body.agentannounce_id !== void 0) fields.push(`agentannounce_id=${body.agentannounce_id || "NULL"}`);
  if (body.joinannounce_id !== void 0) fields.push(`joinannounce_id=${body.joinannounce_id || "NULL"}`);
  await mysqlExec(`UPDATE queues_config SET ${fields.join(",")} WHERE extension='${id}'`);
  if (body.details && typeof body.details === "object") {
    for (const [keyword, data] of Object.entries(body.details)) {
      if (typeof data === "string") {
        await mysqlExec(`DELETE FROM queues_details WHERE id='${id}' AND keyword='${keyword}'`);
        await mysqlExec(`INSERT INTO queues_details (id, keyword, data, flags) VALUES ('${id}','${keyword}','${data}',0)`);
      }
    }
  }
  await mysqlExec(`DELETE FROM queues_details WHERE id='${id}' AND keyword='member'`);
  const staticMembers = (_i = body.staticMembers) != null ? _i : [];
  for (let i = 0; i < staticMembers.length; i++) {
    const m = staticMembers[i];
    const memberStr = String(m.member || "").trim();
    if (memberStr) {
      const penalty = Number((_j = m.penalty) != null ? _j : 0);
      const data = `${memberStr},${penalty}`;
      await mysqlExec(`INSERT INTO queues_details (id, keyword, data, flags) VALUES ('${id}','member','${data}',${i})`);
    }
  }
  try {
    await runAsterisk(`database deltree QPENALTY/${id}/agents`);
  } catch {
  }
  const dynMembers = (_k = body.dynMembers) != null ? _k : [];
  for (const m of dynMembers) {
    const member = String(m.member || "").trim();
    if (member) {
      const penalty = Number((_l = m.penalty) != null ? _l : 0);
      await runAsterisk(`database put QPENALTY/${id}/agents ${member} ${penalty}`);
    }
  }
  const dynmemberonly = String((_m = body.dynmemberonly) != null ? _m : "no");
  await runAsterisk(`database put QPENALTY ${id}/dynmemberonly ${dynmemberonly}`);
  await reloadAsterisk();
  return { ok: true };
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
