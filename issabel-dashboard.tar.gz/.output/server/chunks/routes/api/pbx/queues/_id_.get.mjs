import { d as defineEventHandler, g as getRouterParam, c as createError, F as mysqlQuery, C as runAsterisk } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _id__get = defineEventHandler(async (event) => {
  var _a;
  const id = getRouterParam(event, "id");
  if (!id) throw createError({ statusCode: 400, statusMessage: "Queue required" });
  const cfgRows = await mysqlQuery(
    `SELECT extension, IFNULL(descr,''), IFNULL(grppre,''), IFNULL(alertinfo,''), ringing, IFNULL(maxwait,''), IFNULL(password,''), ivr_id, IFNULL(dest,''), cwignore, IFNULL(qregex,''), IFNULL(agentannounce_id,''), IFNULL(joinannounce_id,''), IFNULL(queuewait,0), IFNULL(qnoanswer,0), IFNULL(callconfirm,0), IFNULL(monitor_type,''), IFNULL(callback_id,''), IFNULL(destcontinue,'')
     FROM queues_config WHERE extension='${id}'`
  );
  if (!cfgRows.length) throw createError({ statusCode: 404, statusMessage: "Queue not found" });
  const c = cfgRows[0].split("	");
  const config = {
    extension: c[0],
    descr: c[1],
    grppre: c[2],
    alertinfo: c[3],
    ringing: c[4] === "1",
    maxwait: c[5],
    password: c[6],
    ivr_id: c[7],
    dest: c[8],
    cwignore: c[9] === "1",
    qregex: c[10],
    agentannounce_id: c[11],
    joinannounce_id: c[12],
    queuewait: c[13] === "1",
    qnoanswer: c[14] === "1",
    callconfirm: c[15] === "1",
    monitor_type: c[16],
    callback_id: c[17],
    destcontinue: c[18]
  };
  const detailRows = await mysqlQuery(`SELECT keyword, data, flags FROM queues_details WHERE id='${id}' ORDER BY keyword, flags`);
  const details = {};
  const staticMembers = [];
  for (const r of detailRows) {
    const [kw, data] = r.split("	");
    if (kw === "member") {
      const parts = data.split(",");
      const iface = parts[0] || "";
      const penalty = parseInt(parts[1] || "0");
      staticMembers.push({ member: iface, penalty });
    } else {
      details[kw] = data;
    }
  }
  const dynMembers = [];
  try {
    const astDbOut = await runAsterisk(`database show QPENALTY/${id}/agents`);
    if (astDbOut && !astDbOut.includes("0 results found")) {
      const lines = astDbOut.split("\n");
      for (const line of lines) {
        const match = line.match(/\/QPENALTY\/\d+\/agents\/([^:]+\S+)\s*:\s*(\d+)/);
        if (match) {
          dynMembers.push({ member: match[1].trim(), penalty: parseInt(match[2]) });
        }
      }
    }
  } catch {
  }
  let dynmemberonly = "no";
  try {
    const dmo = await runAsterisk(`database get QPENALTY ${id}/dynmemberonly`);
    if (dmo && dmo.includes("Value:")) {
      dynmemberonly = ((_a = dmo.split("Value:")[1]) == null ? void 0 : _a.trim()) || "no";
    }
  } catch {
  }
  return { ...config, details, staticMembers, dynMembers, dynmemberonly };
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
