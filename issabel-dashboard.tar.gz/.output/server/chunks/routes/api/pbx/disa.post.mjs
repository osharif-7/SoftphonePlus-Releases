import { d as defineEventHandler, a as readBody, c as createError, D as mysqlExec, W as reloadAsterisk } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const disa_post = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e, _f, _g;
  const b = await readBody(event);
  if (!b.displayname) throw createError({ statusCode: 400, statusMessage: "Name required" });
  await mysqlExec(`INSERT INTO disa (displayname, pin, cid, context, digittimeout, resptimeout, hangup, keepcid) VALUES ('${(_a = b.displayname) != null ? _a : ""}','${(_b = b.pin) != null ? _b : ""}','${(_c = b.cid) != null ? _c : ""}','${(_d = b.context) != null ? _d : "from-internal"}',${Number((_e = b.digittimeout) != null ? _e : 5)},${Number((_f = b.resptimeout) != null ? _f : 10)},'${(_g = b.hangup) != null ? _g : "no"}',${b.keepcid ? 1 : 0})`);
  await reloadAsterisk();
  return { ok: true };
});

export { disa_post as default };
//# sourceMappingURL=disa.post.mjs.map
