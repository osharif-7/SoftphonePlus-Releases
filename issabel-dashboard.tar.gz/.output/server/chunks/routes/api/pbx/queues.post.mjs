import { d as defineEventHandler, a as readBody, c as createError, D as mysqlExec, W as reloadAsterisk } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const queues_post = defineEventHandler(async (event) => {
  var _a, _b, _c, _d;
  const body = await readBody(event);
  const ext = String((_a = body.extension) != null ? _a : "").trim();
  const name = String((_b = body.name) != null ? _b : "").trim();
  const strategy = String((_c = body.strategy) != null ? _c : "ringall").trim();
  const timeout = String((_d = body.timeout) != null ? _d : "15").trim();
  if (!ext || !name) {
    throw createError({ statusCode: 400, statusMessage: "Queue extension and name are required" });
  }
  const insertConfig = `INSERT INTO queues_config (extension, descr, grppre, alertinfo, ringing, maxwait, password, ivr_id, dest, cwignore, callback_id, destcontinue) VALUES ('${ext}','${name}','','',0,'','','0','','0','','')`;
  const detailRows = [
    { keyword: "strategy", data: strategy },
    { keyword: "timeout", data: timeout },
    { keyword: "retry", data: "5" },
    { keyword: "wrapuptime", data: "0" },
    { keyword: "maxlen", data: "0" },
    { keyword: "joinempty", data: "yes" },
    { keyword: "leavewhenempty", data: "no" },
    { keyword: "musicclass", data: "default" },
    { keyword: "ringinuse", data: "no" }
  ];
  const detailInserts = detailRows.map((d) => `('${ext}','${d.keyword}','${d.data}',0)`).join(",");
  const insertDetails = `INSERT INTO queues_details (id, keyword, data, flags) VALUES ${detailInserts}`;
  const r1 = await mysqlExec(insertConfig);
  if (!r1.ok) throw createError({ statusCode: 500, statusMessage: `Failed to create queue config: ${r1.error}` });
  const r2 = await mysqlExec(insertDetails);
  if (!r2.ok) throw createError({ statusCode: 500, statusMessage: `Failed to create queue details: ${r2.error}` });
  await reloadAsterisk();
  return { ok: true, extension: ext };
});

export { queues_post as default };
//# sourceMappingURL=queues.post.mjs.map
