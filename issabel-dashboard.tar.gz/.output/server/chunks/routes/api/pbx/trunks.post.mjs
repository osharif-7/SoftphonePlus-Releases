import { d as defineEventHandler, a as readBody, c as createError, F as mysqlQuery, D as mysqlExec, W as reloadAsterisk } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const trunks_post = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n;
  const body = await readBody(event);
  const name = String((_a = body.name) != null ? _a : "").trim();
  const tech = String((_b = body.tech) != null ? _b : "sip").trim().toLowerCase();
  const outcid = String((_c = body.outcid) != null ? _c : "");
  const keepcid = String((_d = body.keepcid) != null ? _d : "off");
  const maxchans = String((_e = body.maxchans) != null ? _e : "");
  const dialoutprefix = String((_f = body.dialoutprefix) != null ? _f : "");
  const disabled = String((_g = body.disabled) != null ? _g : "off");
  const cont = String((_h = body.continue) != null ? _h : "off");
  const channelid = String((_i = body.channelid) != null ? _i : "").trim();
  const usercontext = String((_j = body.usercontext) != null ? _j : "");
  const peerdetails = String((_k = body.peerdetails) != null ? _k : "");
  const userconfig = String((_l = body.userconfig) != null ? _l : "");
  const register = String((_m = body.register) != null ? _m : "");
  if (!name && !channelid) throw createError({ statusCode: 400, statusMessage: "Trunk name or channel ID is required" });
  const maxIdRows = await mysqlQuery("SELECT IFNULL(MAX(trunkid),0) FROM trunks");
  const nextId = (parseInt((_n = maxIdRows[0]) != null ? _n : "0") || 0) + 1;
  const effChannelId = channelid || (tech === "dahdi" ? "g0" : name);
  const effName = name || effChannelId;
  await mysqlExec(`INSERT INTO trunks (trunkid, name, tech, outcid, keepcid, maxchans, failscript, dialoutprefix, channelid, usercontext, provider, disabled, \`continue\`) VALUES (${nextId},'${effName}','${tech}','${outcid}','${keepcid}','${maxchans}','','${dialoutprefix}','${effChannelId}','${usercontext}','','${disabled}','${cont}')`);
  if (tech === "sip" || tech === "iax" || tech === "iax2") {
    const table = tech === "sip" ? "sip" : "iax";
    if (peerdetails.trim()) {
      const lines = peerdetails.trim().split("\n");
      for (let i = 0; i < lines.length; i++) {
        const [kw, ...rest] = lines[i].split("=");
        const data = rest.join("=").trim();
        if (kw == null ? void 0 : kw.trim()) {
          await mysqlExec(`INSERT INTO ${table} (id, keyword, data, flags) VALUES ('tr-peer-${nextId}','${kw.trim()}','${data}',${i})`);
        }
      }
      await mysqlExec(`INSERT INTO ${table} (id, keyword, data, flags) VALUES ('tr-peer-${nextId}','account','tr-peer-${nextId}',0) ON DUPLICATE KEY UPDATE data='tr-peer-${nextId}'`);
    }
    if (userconfig.trim()) {
      const lines = userconfig.trim().split("\n");
      for (let i = 0; i < lines.length; i++) {
        const [kw, ...rest] = lines[i].split("=");
        const data = rest.join("=").trim();
        if (kw == null ? void 0 : kw.trim()) {
          await mysqlExec(`INSERT INTO ${table} (id, keyword, data, flags) VALUES ('tr-user-${nextId}','${kw.trim()}','${data}',${i})`);
        }
      }
      await mysqlExec(`INSERT INTO ${table} (id, keyword, data, flags) VALUES ('tr-user-${nextId}','account','tr-user-${nextId}',0) ON DUPLICATE KEY UPDATE data='tr-user-${nextId}'`);
    }
    if (register.trim()) {
      await mysqlExec(`INSERT INTO ${table} (id, keyword, data, flags) VALUES ('tr-reg-${nextId}','register','${register.trim()}',0)`);
    }
  }
  if (tech === "pjsip") {
    const pjsip = body.pjsip || {};
    const entries = Object.entries(pjsip);
    for (let i = 0; i < entries.length; i++) {
      const [kw, data] = entries[i];
      if (kw && data !== void 0) {
        await mysqlExec(`INSERT INTO sip (id, keyword, data, flags) VALUES ('pjsip-${nextId}','${kw}','${data}',${i})`);
      }
    }
    await mysqlExec(`INSERT INTO sip (id, keyword, data, flags) VALUES ('pjsip-${nextId}','account','pjsip-${nextId}',0) ON DUPLICATE KEY UPDATE data='pjsip-${nextId}'`);
    if (register.trim()) {
      await mysqlExec(`INSERT INTO sip (id, keyword, data, flags) VALUES ('tr-reg-${nextId}','register','${register.trim()}',0)`);
    }
  }
  const patterns = body.dialpatterns || [];
  for (let i = 0; i < patterns.length; i++) {
    const p = patterns[i];
    if (p.prepend || p.prefix || p.pattern) {
      await mysqlExec(`INSERT INTO trunk_dialpatterns (trunkid, match_pattern_prefix, match_pattern_pass, prepend_digits, seq) VALUES (${nextId},'${p.prefix || ""}','${p.pattern || ""}','${p.prepend || ""}',${i})`);
    }
  }
  await reloadAsterisk();
  return { ok: true, trunkId: nextId };
});

export { trunks_post as default };
//# sourceMappingURL=trunks.post.mjs.map
