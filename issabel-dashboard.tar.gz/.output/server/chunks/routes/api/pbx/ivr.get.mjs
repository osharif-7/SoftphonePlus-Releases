import { d as defineEventHandler, F as mysqlQuery } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const ivr_get = defineEventHandler(async () => {
  const rows = await mysqlQuery("SELECT id, IFNULL(name,''), IFNULL(description,''), IFNULL(timeout_time,10) FROM ivr_details ORDER BY id");
  return rows.map((r) => {
    const [id, name, description, timeout] = r.split("	");
    return { id, name, description, timeout: Number(timeout) };
  });
});

export { ivr_get as default };
//# sourceMappingURL=ivr.get.mjs.map
