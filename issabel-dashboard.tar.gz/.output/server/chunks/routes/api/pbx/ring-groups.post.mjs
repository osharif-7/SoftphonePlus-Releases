import { d as defineEventHandler, a as readBody, c as createError, D as mysqlExec, W as reloadAsterisk } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const ringGroups_post = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e, _f;
  const body = await readBody(event);
  const grpnum = String((_a = body.grpnum) != null ? _a : "").trim();
  const description = String((_b = body.description) != null ? _b : "").trim();
  const strategy = String((_c = body.strategy) != null ? _c : "ringall");
  const grptime = Number((_d = body.grptime) != null ? _d : 20);
  const grplist = String((_e = body.grplist) != null ? _e : "").trim();
  const postdest = String((_f = body.postdest) != null ? _f : "").trim();
  if (!grpnum) throw createError({ statusCode: 400, statusMessage: "Group number required" });
  const r = await mysqlExec(`INSERT INTO ringgroups (grpnum, strategy, grptime, grplist, postdest, description, grppre) VALUES ('${grpnum}','${strategy}',${grptime},'${grplist}','${postdest}','${description}','')`);
  if (!r.ok) throw createError({ statusCode: 500, statusMessage: r.error });
  await reloadAsterisk();
  return { ok: true };
});

export { ringGroups_post as default };
//# sourceMappingURL=ring-groups.post.mjs.map
