import { d as defineEventHandler, a as readBody, c as createError, D as mysqlExec, F as mysqlQuery, W as reloadAsterisk } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const outboundRoutes_post = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e;
  const body = await readBody(event);
  const name = String((_a = body.name) != null ? _a : "").trim();
  const outcid = String((_b = body.outcid) != null ? _b : "").trim();
  const pattern = String((_c = body.pattern) != null ? _c : "").trim();
  const trunkId = Number((_d = body.trunkId) != null ? _d : 0);
  if (!name) throw createError({ statusCode: 400, statusMessage: "Route name required" });
  const r = await mysqlExec(
    `INSERT INTO outbound_routes (name, outcid, emergency_route, intracompany_route, mohclass) VALUES ('${name}','${outcid}','off','off','default')`
  );
  if (!r.ok) throw createError({ statusCode: 500, statusMessage: r.error });
  const idRows = await mysqlQuery(`SELECT route_id FROM outbound_routes WHERE name='${name}' ORDER BY route_id DESC LIMIT 1`);
  const routeId = (_e = idRows[0]) != null ? _e : "0";
  if (pattern) {
    await mysqlExec(`INSERT INTO outbound_route_patterns (route_id, match_pattern_prefix, match_pattern_pass, match_cid, prepend_digits) VALUES (${routeId},'','${pattern}','','')`);
  }
  if (trunkId) {
    await mysqlExec(`INSERT INTO outbound_route_trunks (route_id, trunk_id, seq) VALUES (${routeId},${trunkId},0)`);
  }
  await reloadAsterisk();
  return { ok: true };
});

export { outboundRoutes_post as default };
//# sourceMappingURL=outbound-routes.post.mjs.map
