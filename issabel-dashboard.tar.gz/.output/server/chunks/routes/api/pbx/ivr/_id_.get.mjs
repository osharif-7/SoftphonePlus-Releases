import { d as defineEventHandler, g as getRouterParam, c as createError, F as mysqlQuery } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _id__get = defineEventHandler(async (event) => {
  const id = getRouterParam(event, "id");
  if (!id) throw createError({ statusCode: 400, statusMessage: "IVR ID required" });
  const rows = await mysqlQuery(
    `SELECT id, IFNULL(name,''), IFNULL(description,''), IFNULL(announcement,''), IFNULL(directdial,'disabled'),
     IFNULL(invalid_loops,3), IFNULL(invalid_retry_recording,''), IFNULL(invalid_destination,''),
     IFNULL(invalid_recording,''), IFNULL(retvm,'no'), IFNULL(timeout_time,10),
     IFNULL(timeout_recording,''), IFNULL(timeout_retry_recording,''), IFNULL(timeout_destination,''),
     IFNULL(timeout_loops,3), timeout_append_announce, invalid_append_announce,
     timeout_ivr_ret, invalid_ivr_ret
     FROM ivr_details WHERE id=${id}`
  );
  if (!rows.length) throw createError({ statusCode: 404, statusMessage: "IVR not found" });
  const c = rows[0].split("	");
  const detail = {
    id: c[0],
    name: c[1],
    description: c[2],
    announcement: c[3],
    directdial: c[4],
    invalid_loops: c[5],
    invalid_retry_recording: c[6],
    invalid_destination: c[7],
    invalid_recording: c[8],
    retvm: c[9],
    timeout_time: c[10],
    timeout_recording: c[11],
    timeout_retry_recording: c[12],
    timeout_destination: c[13],
    timeout_loops: c[14],
    timeout_append_announce: c[15] === "1",
    invalid_append_announce: c[16] === "1",
    timeout_ivr_ret: c[17] === "1",
    invalid_ivr_ret: c[18] === "1"
  };
  const entryRows = await mysqlQuery(`SELECT selection, IFNULL(dest,''), ivr_ret FROM ivr_entries WHERE ivr_id=${id} ORDER BY selection`);
  const entries = entryRows.map((r) => {
    const [selection, dest, ret] = r.split("	");
    return { selection, dest, ivr_ret: ret === "1" };
  });
  return { ...detail, entries };
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
