import { d as defineEventHandler, g as getRouterParam, c as createError, a as readBody, D as mysqlExec, W as reloadAsterisk } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _id__put = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q;
  const id = getRouterParam(event, "id");
  if (!id) throw createError({ statusCode: 400, statusMessage: "IVR ID required" });
  const body = await readBody(event);
  const fields = [
    `name='${(_a = body.name) != null ? _a : ""}'`,
    `description='${(_b = body.description) != null ? _b : ""}'`,
    `announcement='${(_c = body.announcement) != null ? _c : ""}'`,
    `directdial='${(_d = body.directdial) != null ? _d : "disabled"}'`,
    `timeout_time=${Number((_e = body.timeout_time) != null ? _e : 10)}`,
    `invalid_loops='${(_f = body.invalid_loops) != null ? _f : "3"}'`,
    `invalid_retry_recording='${(_g = body.invalid_retry_recording) != null ? _g : ""}'`,
    `invalid_destination='${(_h = body.invalid_destination) != null ? _h : ""}'`,
    `invalid_recording='${(_i = body.invalid_recording) != null ? _i : ""}'`,
    `retvm='${(_j = body.retvm) != null ? _j : "no"}'`,
    `timeout_recording='${(_k = body.timeout_recording) != null ? _k : ""}'`,
    `timeout_retry_recording='${(_l = body.timeout_retry_recording) != null ? _l : ""}'`,
    `timeout_destination='${(_m = body.timeout_destination) != null ? _m : ""}'`,
    `timeout_loops='${(_n = body.timeout_loops) != null ? _n : "3"}'`,
    `timeout_append_announce=${body.timeout_append_announce ? 1 : 0}`,
    `invalid_append_announce=${body.invalid_append_announce ? 1 : 0}`,
    `timeout_ivr_ret=${body.timeout_ivr_ret ? 1 : 0}`,
    `invalid_ivr_ret=${body.invalid_ivr_ret ? 1 : 0}`
  ];
  await mysqlExec(`UPDATE ivr_details SET ${fields.join(",")} WHERE id=${id}`);
  await mysqlExec(`DELETE FROM ivr_entries WHERE ivr_id=${id}`);
  const entries = (_o = body.entries) != null ? _o : [];
  for (const entry of entries) {
    const sel = String((_p = entry.selection) != null ? _p : "").trim();
    const dest = String((_q = entry.dest) != null ? _q : "").trim();
    const ret = entry.ivr_ret ? 1 : 0;
    if (sel) {
      await mysqlExec(`INSERT INTO ivr_entries (ivr_id, selection, dest, ivr_ret) VALUES (${id},'${sel}','${dest}',${ret})`);
    }
  }
  await reloadAsterisk();
  return { ok: true };
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
