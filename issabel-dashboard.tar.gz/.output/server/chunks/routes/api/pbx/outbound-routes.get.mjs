import { d as defineEventHandler, F as mysqlQuery } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const outboundRoutes_get = defineEventHandler(async () => {
  const rows = await mysqlQuery(
    "SELECT route_id, IFNULL(name,''), IFNULL(outcid,''), IFNULL(emergency_route,'off') FROM outbound_routes ORDER BY route_id"
  );
  return rows.map((r) => {
    const [routeId, name, outcid, emergency] = r.split("	");
    return { routeId, name, outcid, emergency: emergency === "YES" };
  });
});

export { outboundRoutes_get as default };
//# sourceMappingURL=outbound-routes.get.mjs.map
