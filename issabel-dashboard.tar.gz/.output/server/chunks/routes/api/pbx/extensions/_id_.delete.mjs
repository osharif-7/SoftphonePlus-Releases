import { d as defineEventHandler, g as getRouterParam, c as createError, D as mysqlExec, W as reloadAsterisk } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _id__delete = defineEventHandler(async (event) => {
  const id = getRouterParam(event, "id");
  if (!id) throw createError({ statusCode: 400, statusMessage: "Extension ID required" });
  await Promise.all([
    mysqlExec(`DELETE FROM users WHERE extension='${id}'`),
    mysqlExec(`DELETE FROM devices WHERE id='${id}'`),
    mysqlExec(`DELETE FROM sip WHERE id='${id}'`)
  ]);
  await reloadAsterisk();
  return { ok: true, deleted: id };
});

export { _id__delete as default };
//# sourceMappingURL=_id_.delete.mjs.map
