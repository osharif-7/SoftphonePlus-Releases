import { d as defineEventHandler, g as getRouterParam, c as createError, a as readBody, D as mysqlExec, W as reloadAsterisk } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _id__put = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k;
  const id = getRouterParam(event, "id");
  if (!id) throw createError({ statusCode: 400, statusMessage: "Extension required" });
  const body = await readBody(event);
  await mysqlExec(`UPDATE users SET name='${(_a = body.name) != null ? _a : ""}', voicemail='${(_b = body.voicemail) != null ? _b : ""}', ringtimer=${Number((_c = body.ringtimer) != null ? _c : 0)}, outboundcid='${(_d = body.outboundcid) != null ? _d : ""}', recording='${(_e = body.recording) != null ? _e : ""}', noanswer_dest='${(_f = body.noanswer_dest) != null ? _f : ""}', busy_dest='${(_g = body.busy_dest) != null ? _g : ""}', chanunavail_dest='${(_h = body.chanunavail_dest) != null ? _h : ""}', mohclass='${(_i = body.mohclass) != null ? _i : "default"}' WHERE extension='${id}'`);
  if (body.device) {
    await mysqlExec(`UPDATE devices SET description='${(_j = body.device.description) != null ? _j : ""}', emergency_cid='${(_k = body.device.emergency_cid) != null ? _k : ""}' WHERE id='${id}'`);
  }
  if (body.sip && typeof body.sip === "object") {
    for (const [keyword, data] of Object.entries(body.sip)) {
      if (typeof data === "string") {
        await mysqlExec(`DELETE FROM sip WHERE id='${id}' AND keyword='${keyword}'`);
        await mysqlExec(`INSERT INTO sip (id, keyword, data, flags) VALUES ('${id}','${keyword}','${data}',0)`);
      }
    }
  }
  await reloadAsterisk();
  return { ok: true };
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
