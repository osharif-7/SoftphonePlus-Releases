import { d as defineEventHandler, g as getRouterParam, c as createError, F as mysqlQuery } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _id__get = defineEventHandler(async (event) => {
  const id = getRouterParam(event, "id");
  if (!id) throw createError({ statusCode: 400, statusMessage: "Extension required" });
  const userRows = await mysqlQuery(
    `SELECT extension, IFNULL(name,''), IFNULL(voicemail,''), IFNULL(ringtimer,0), IFNULL(outboundcid,''), IFNULL(recording,''), IFNULL(noanswer_dest,''), IFNULL(busy_dest,''), IFNULL(chanunavail_dest,''), IFNULL(mohclass,'default')
     FROM users WHERE extension='${id}'`
  );
  if (!userRows.length) throw createError({ statusCode: 404, statusMessage: "Extension not found" });
  const u = userRows[0].split("	");
  const user = {
    extension: u[0],
    name: u[1],
    voicemail: u[2],
    ringtimer: Number(u[3]),
    outboundcid: u[4],
    recording: u[5],
    noanswer_dest: u[6],
    busy_dest: u[7],
    chanunavail_dest: u[8],
    mohclass: u[9]
  };
  const sipRows = await mysqlQuery(`SELECT keyword, data FROM sip WHERE id='${id}'`);
  const sip = {};
  for (const r of sipRows) {
    const [kw, data] = r.split("	");
    sip[kw] = data;
  }
  const devRows = await mysqlQuery(`SELECT tech, dial, devicetype, IFNULL(description,''), IFNULL(emergency_cid,'') FROM devices WHERE id='${id}'`);
  let device = { tech: "sip", dial: "", devicetype: "fixed", description: "", emergency_cid: "" };
  if (devRows.length) {
    const d = devRows[0].split("	");
    device = { tech: d[0], dial: d[1], devicetype: d[2], description: d[3], emergency_cid: d[4] };
  }
  return { ...user, sip, device };
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
