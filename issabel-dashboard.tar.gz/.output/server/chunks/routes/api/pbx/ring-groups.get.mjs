import { d as defineEventHandler, F as mysqlQuery } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const ringGroups_get = defineEventHandler(async () => {
  const rows = await mysqlQuery("SELECT grpnum, IFNULL(description,''), IFNULL(strategy,'ringall'), grptime, IFNULL(grplist,''), IFNULL(postdest,'') FROM ringgroups ORDER BY grpnum");
  return rows.map((r) => {
    const [grpnum, description, strategy, grptime, grplist, postdest] = r.split("	");
    return { grpnum, description, strategy, grptime: Number(grptime), grplist, postdest };
  });
});

export { ringGroups_get as default };
//# sourceMappingURL=ring-groups.get.mjs.map
