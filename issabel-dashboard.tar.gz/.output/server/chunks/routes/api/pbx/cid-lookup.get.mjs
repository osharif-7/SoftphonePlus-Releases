import { d as defineEventHandler, F as mysqlQuery } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const cidLookup_get = defineEventHandler(async () => {
  const rows = await mysqlQuery(
    "SELECT cidlookup_id, IFNULL(description,''), IFNULL(sourcetype,'') FROM cidlookup ORDER BY cidlookup_id"
  );
  return rows.map((r) => {
    const [id, description, sourcetype] = r.split("	");
    return { id, description, sourcetype };
  });
});

export { cidLookup_get as default };
//# sourceMappingURL=cid-lookup.get.mjs.map
