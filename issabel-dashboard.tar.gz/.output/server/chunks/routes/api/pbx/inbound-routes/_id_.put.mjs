import { d as defineEventHandler, g as getRouterParam, a as readBody, D as mysqlExec, W as reloadAsterisk } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _id__put = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k;
  const id = decodeURIComponent((_a = getRouterParam(event, "id")) != null ? _a : "");
  const b = await readBody(event);
  const fields = [
    `cidnum='${(_b = b.cidnum) != null ? _b : ""}'`,
    `destination='${(_c = b.destination) != null ? _c : ""}'`,
    `faxexten='${(_d = b.faxexten) != null ? _d : ""}'`,
    `faxemail='${(_e = b.faxemail) != null ? _e : ""}'`,
    `privacyman=${b.privacyman ? 1 : 0}`,
    `alertinfo='${(_f = b.alertinfo) != null ? _f : ""}'`,
    `mohclass='${(_g = b.mohclass) != null ? _g : "default"}'`,
    `description='${(_h = b.description) != null ? _h : ""}'`,
    `grppre='${(_i = b.grppre) != null ? _i : ""}'`,
    `delay_answer=${Number((_j = b.delay_answer) != null ? _j : 0)}`,
    `ringing='${(_k = b.ringing) != null ? _k : ""}'`
  ];
  await mysqlExec(`UPDATE incoming SET ${fields.join(",")} WHERE extension='${id}'`);
  await reloadAsterisk();
  return { ok: true };
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
