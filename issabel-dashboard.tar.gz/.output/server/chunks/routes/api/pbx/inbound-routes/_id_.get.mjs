import { d as defineEventHandler, g as getRouterParam, F as mysqlQuery, c as createError } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _id__get = defineEventHandler(async (event) => {
  var _a;
  const id = decodeURIComponent((_a = getRouterParam(event, "id")) != null ? _a : "");
  const rows = await mysqlQuery(`SELECT IFNULL(cidnum,''), extension, IFNULL(destination,''), IFNULL(faxexten,''), IFNULL(faxemail,''), IFNULL(answer,0), IFNULL(wait,0), IFNULL(privacyman,0), IFNULL(alertinfo,''), IFNULL(ringing,''), IFNULL(mohclass,'default'), IFNULL(description,''), IFNULL(grppre,''), IFNULL(delay_answer,0), IFNULL(pricid,''), IFNULL(pmmaxretries,''), IFNULL(pmminlength,'') FROM incoming WHERE extension='${id}'`);
  if (!rows.length) throw createError({ statusCode: 404, statusMessage: "Route not found" });
  const c = rows[0].split("	");
  return { cidnum: c[0], extension: c[1], destination: c[2], faxexten: c[3], faxemail: c[4], answer: c[5] === "1", wait: Number(c[6]), privacyman: c[7] === "1", alertinfo: c[8], ringing: c[9], mohclass: c[10], description: c[11], grppre: c[12], delay_answer: Number(c[13]), pricid: c[14], pmmaxretries: c[15], pmminlength: c[16] };
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
