import { d as defineEventHandler, a as readBody, c as createError, D as mysqlExec, W as reloadAsterisk } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const inboundRoutes_post = defineEventHandler(async (event) => {
  var _a, _b, _c, _d;
  const body = await readBody(event);
  const extension = String((_a = body.extension) != null ? _a : "").trim();
  const cidnum = String((_b = body.cidnum) != null ? _b : "").trim();
  const description = String((_c = body.description) != null ? _c : "").trim();
  const destination = String((_d = body.destination) != null ? _d : "").trim();
  if (!extension) throw createError({ statusCode: 400, statusMessage: "DID number required" });
  const r = await mysqlExec(
    `INSERT INTO incoming (extension, cidnum, description, destination, mohclass) VALUES ('${extension}','${cidnum}','${description}','${destination}','default')`
  );
  if (!r.ok) throw createError({ statusCode: 500, statusMessage: r.error });
  await reloadAsterisk();
  return { ok: true };
});

export { inboundRoutes_post as default };
//# sourceMappingURL=inbound-routes.post.mjs.map
