import { d as defineEventHandler, F as mysqlQuery, C as runAsterisk } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const sipPeerStates = async () => {
  var _a, _b, _c, _d;
  const out = await runAsterisk("sip show peers");
  const lines = out.split("\n");
  const statusMap = /* @__PURE__ */ new Map();
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("Name/username") || trimmed.startsWith("Objects found")) continue;
    const parts = trimmed.split(/\s+/);
    const peer = (_c = (_b = (_a = parts[0]) == null ? void 0 : _a.split("/")) == null ? void 0 : _b[0]) != null ? _c : "";
    const status = (_d = parts.at(-1)) != null ? _d : "unknown";
    if (peer) statusMap.set(peer, status.toLowerCase());
  }
  return statusMap;
};
const extensions_get = defineEventHandler(async () => {
  const rows = await mysqlQuery(
    "SELECT u.extension, IFNULL(u.name,''), IFNULL(d.tech,'SIP'), IFNULL(u.voicemail,'novm') FROM users u LEFT JOIN devices d ON d.id = u.extension ORDER BY u.extension"
  );
  const peers = await sipPeerStates();
  return rows.map((line) => {
    const [ext = "", name = "", tech = "SIP"] = line.split("	");
    const status = peers.get(ext) || "unknown";
    return {
      extension: ext,
      name: name || `Extension ${ext}`,
      tech: tech.toUpperCase(),
      status
    };
  });
});

export { extensions_get as default };
//# sourceMappingURL=extensions.get.mjs.map
