import { d as defineEventHandler, F as mysqlQuery } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const trunks_get = defineEventHandler(async () => {
  const rows = await mysqlQuery(
    "SELECT trunkid, IFNULL(name,''), IFNULL(tech,''), IFNULL(outcid,''), IFNULL(keepcid,'off'), IFNULL(maxchans,''), IFNULL(dialoutprefix,''), IFNULL(channelid,''), IFNULL(disabled,'off') FROM trunks ORDER BY trunkid"
  );
  return rows.map((line) => {
    const [trunkId, name, tech, outcid, keepcid, maxchans, dialoutprefix, channelid, disabled] = line.split("	");
    return {
      trunkId,
      name: name || `Trunk ${trunkId}`,
      tech: tech.toUpperCase(),
      outcid,
      keepcid,
      maxchans,
      dialoutprefix,
      channelid,
      disabled,
      status: disabled === "on" ? "disabled" : "active"
    };
  });
});

export { trunks_get as default };
//# sourceMappingURL=trunks.get.mjs.map
