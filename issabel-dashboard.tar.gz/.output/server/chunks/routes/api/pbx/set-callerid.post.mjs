import { d as defineEventHandler, a as readBody, c as createError, D as mysqlExec, W as reloadAsterisk } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const setCallerid_post = defineEventHandler(async (event) => {
  var _a, _b, _c, _d;
  const b = await readBody(event);
  if (!b.description) throw createError({ statusCode: 400, statusMessage: "Description required" });
  await mysqlExec(`INSERT INTO setcid (description, cid_name, cid_num, dest) VALUES ('${(_a = b.description) != null ? _a : ""}','${(_b = b.cid_name) != null ? _b : ""}','${(_c = b.cid_num) != null ? _c : ""}','${(_d = b.dest) != null ? _d : ""}')`);
  await reloadAsterisk();
  return { ok: true };
});

export { setCallerid_post as default };
//# sourceMappingURL=set-callerid.post.mjs.map
