import { d as defineEventHandler, r as requireAuth, V as getAmiState } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const events_get = defineEventHandler(async (event) => {
  requireAuth(event);
  const res = event.node.res;
  const req = event.node.req;
  res.writeHead(200, {
    "Content-Type": "text/event-stream",
    "Cache-Control": "no-cache",
    "Connection": "keep-alive",
    "X-Accel-Buffering": "no"
  });
  const state = getAmiState();
  let closed = false;
  const write = (data) => {
    if (closed) return;
    try {
      res.write(data);
    } catch {
      closed = true;
    }
  };
  const snap = state.getSnapshot();
  write(`event: snapshot
data: ${JSON.stringify(snap)}

`);
  const onChange = (newSnap) => {
    write(`event: update
data: ${JSON.stringify(newSnap)}

`);
  };
  state.subscribe(onChange);
  const heartbeat = setInterval(() => {
    if (closed) {
      clearInterval(heartbeat);
      return;
    }
    write(`: heartbeat

`);
  }, 3e4);
  const cleanup = () => {
    if (closed) return;
    closed = true;
    clearInterval(heartbeat);
    state.unsubscribe(onChange);
  };
  req.on("close", cleanup);
  req.on("error", cleanup);
  await new Promise((resolve) => {
    req.on("close", resolve);
  });
});

export { events_get as default };
//# sourceMappingURL=events.get.mjs.map
