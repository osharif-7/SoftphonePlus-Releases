import { d as defineEventHandler, C as runAsterisk, F as mysqlQuery, O as getBestQueueAbandoned } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const panel_get = defineEventHandler(async () => {
  var _a, _b, _c, _d, _e, _f, _g;
  const [peerOut, chanOut, queueOut, extRows] = await Promise.all([
    runAsterisk("sip show peers"),
    runAsterisk("core show channels concise"),
    runAsterisk("queue show"),
    mysqlQuery("SELECT u.extension, IFNULL(u.name,''), IFNULL(d.tech,'SIP') FROM users u LEFT JOIN devices d ON d.id=u.extension ORDER BY u.extension")
  ]);
  const extMap = /* @__PURE__ */ new Map();
  for (const r of extRows) {
    const [ext, name, tech] = r.split("	");
    extMap.set(ext, { name: name || `Ext ${ext}`, tech: tech || "SIP" });
  }
  const peerMap = /* @__PURE__ */ new Map();
  if (peerOut) {
    for (const line of peerOut.split("\n")) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith("Name/username") || trimmed.startsWith("Objects found")) continue;
      const parts = trimmed.split(/\s+/);
      const peer = (_c = (_b = (_a = parts[0]) == null ? void 0 : _a.split("/")) == null ? void 0 : _b[0]) != null ? _c : "";
      const host = (_d = parts[1]) != null ? _d : "";
      const [ip = "", port = ""] = host.includes(":") ? host.split(":") : [host, ""];
      const status = (_e = parts.at(-1)) != null ? _e : "unknown";
      if (peer) peerMap.set(peer, { ip, port, status: status.toLowerCase() });
    }
  }
  const channels = [];
  const extInCall = /* @__PURE__ */ new Map();
  if (chanOut && !chanOut.includes("0 active channels")) {
    for (const line of chanOut.split("\n")) {
      if (!line.includes("!")) continue;
      const parts = line.split("!");
      if (parts.length < 7) continue;
      const [channel, ctx, ext, , appState, app, appData, dur] = parts;
      const callerMatch = channel == null ? void 0 : channel.match(/^(SIP|PJSIP|IAX2)\/(\d+)-/i);
      const durSec = parseInt(dur || "0");
      let bridgedTo = "";
      if (appData) {
        const bridgeMatch = appData.match(/(SIP|PJSIP|IAX2)\/(\d+)/i);
        if (bridgeMatch) bridgedTo = bridgeMatch[2];
      }
      const ch = {
        channel: channel || "",
        context: ctx || "",
        extension: ext || "",
        state: appState || "",
        application: app || "",
        duration: durSec,
        callerIdNum: (callerMatch == null ? void 0 : callerMatch[2]) || "",
        callerIdName: "",
        bridgedTo,
        uniqueId: ""
      };
      channels.push(ch);
      if (callerMatch) {
        extInCall.set(callerMatch[2], { channel: channel || "", talkingTo: bridgedTo, duration: durSec });
      }
    }
  }
  const extensions = [];
  for (const [ext, info] of extMap) {
    const peer = peerMap.get(ext);
    const call = extInCall.get(ext);
    extensions.push({
      extension: ext,
      name: info.name,
      tech: info.tech,
      ip: (peer == null ? void 0 : peer.ip) || "",
      port: (peer == null ? void 0 : peer.port) || "",
      status: (peer == null ? void 0 : peer.status) || "unregistered",
      inCall: !!call,
      channel: (call == null ? void 0 : call.channel) || "",
      talkingTo: (call == null ? void 0 : call.talkingTo) || "",
      duration: (call == null ? void 0 : call.duration) || 0
    });
  }
  const queues = [];
  const asteriskAbandonedMap = /* @__PURE__ */ new Map();
  if (queueOut) {
    const qBlocks = queueOut.split(/\n(?=\S+\s+has\s+\d+\s+calls?)/);
    for (const block of qBlocks) {
      const headerMatch = block.match(/^(\S+)\s+has\s+(\d+)\s+calls?\s+\(max\s+(\S+)\)\s+in\s+'(\S+)'\s+strategy\s+\((\d+)s\s+holdtime,\s+(\d+)s\s+talktime\),\s+W:(\d+),\s+C:(\d+),\s+A:(\d+),\s+SL:([^\s]+)/);
      if (!headerMatch) continue;
      const qName = headerMatch[1];
      const cfgRow = await mysqlQuery(`SELECT IFNULL(descr,'') FROM queues_config WHERE extension='${qName}'`);
      const description = cfgRow[0] || qName;
      asteriskAbandonedMap.set(qName, parseInt(headerMatch[9]));
      const q = {
        name: qName,
        description,
        strategy: headerMatch[4],
        calls: parseInt(headerMatch[2]),
        holdtime: parseInt(headerMatch[5]),
        talktime: parseInt(headerMatch[6]),
        completed: parseInt(headerMatch[8]),
        abandoned: parseInt(headerMatch[9]),
        sl: headerMatch[10],
        members: [],
        callers: []
      };
      const memberLines = block.match(/^\s+(SIP|Local|PJSIP|IAX2)\/\S+.*/gm);
      if (memberLines) {
        for (const ml of memberLines) {
          const mMatch = ml.match(/^\s+((SIP|Local|PJSIP|IAX2)\/\S+)\s+.*\((.+)\)\s+(has taken|with)\s+(\d+)\s+calls\s+\(last was (\d+)\s+secs? ago\)/i);
          if (mMatch) {
            const location = mMatch[1];
            const statusStr = mMatch[3] || "";
            const callsTaken = parseInt(mMatch[5] || "0");
            const lastCall = mMatch[6] || "0";
            const paused = ml.includes("(paused)");
            const penMatch = ml.match(/penalty\s+(\d+)/i);
            const penalty = penMatch ? parseInt(penMatch[1]) : 0;
            const inCall = statusStr.toLowerCase().includes("in use") || statusStr.toLowerCase().includes("busy");
            const nameMatch = location.match(/Local\/(\d+)@/);
            const memberName = nameMatch ? ((_f = extMap.get(nameMatch[1])) == null ? void 0 : _f.name) || nameMatch[1] : location;
            q.members.push({
              name: memberName,
              location,
              paused,
              penalty,
              callsTaken,
              lastCall: `${lastCall}s ago`,
              status: statusStr,
              inCall
            });
          }
        }
      }
      const callerLines = block.match(/^\s+\d+\.\s+.*/gm);
      if (callerLines) {
        for (const cl of callerLines) {
          const cMatch = cl.match(/^\s+(\d+)\.\s+(\S+)\s+\((.+)\)\s+\(wait:\s*(\d+):(\d+):(\d+)/);
          if (cMatch) {
            q.callers.push({
              position: parseInt(cMatch[1]),
              callerIdNum: cMatch[2],
              callerIdName: cMatch[3],
              wait: parseInt(cMatch[4]) * 3600 + parseInt(cMatch[5]) * 60 + parseInt(cMatch[6])
            });
          }
        }
      }
      queues.push(q);
    }
  }
  const bestAbandoned = await getBestQueueAbandoned(asteriskAbandonedMap);
  for (const q of queues) {
    q.abandoned = (_g = bestAbandoned.get(q.name)) != null ? _g : q.abandoned;
  }
  const trunkRows = await mysqlQuery("SELECT trunkid, IFNULL(name,''), IFNULL(tech,''), IFNULL(channelid,'') FROM trunks ORDER BY trunkid");
  const trunks = trunkRows.map((r) => {
    const [id, name, tech, channelid] = r.split("	");
    const inUse = channels.some((c) => c.channel.toLowerCase().includes((channelid || "").toLowerCase()));
    return { id, name: name || `Trunk ${id}`, tech, channelid, inUse };
  });
  return {
    extensions,
    channels,
    queues,
    trunks,
    summary: {
      totalExtensions: extensions.length,
      registeredExtensions: extensions.filter((e) => e.status === "ok").length,
      activeChannels: channels.length,
      activeCalls: Math.floor(channels.length / 2),
      totalQueues: queues.length,
      callsWaiting: queues.reduce((sum, q) => sum + q.calls, 0)
    }
  };
});

export { panel_get as default };
//# sourceMappingURL=panel.get.mjs.map
