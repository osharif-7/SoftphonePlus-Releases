import { d as defineEventHandler, r as requireAuth, a as readBody, c as createError, U as getAmiClient } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const action_post = defineEventHandler(async (event) => {
  requireAuth(event);
  const body = await readBody(event);
  const { action, params = {} } = body || {};
  if (!action) throw createError({ statusCode: 400, statusMessage: "Missing action" });
  const ami = getAmiClient();
  if (!ami.isReady()) {
    throw createError({ statusCode: 503, statusMessage: "AMI not connected" });
  }
  try {
    let result;
    switch (action) {
      case "originate": {
        const { extension, callerID, context } = params;
        if (!extension) throw createError({ statusCode: 400, statusMessage: "Missing extension" });
        result = await ami.sendAction("Originate", {
          Channel: `Local/${extension}@from-internal`,
          Exten: params.target || extension,
          Context: context || "from-internal",
          Priority: "1",
          CallerID: callerID || extension,
          Timeout: "30000",
          Async: "true"
        });
        break;
      }
      case "dial": {
        const { from, to } = params;
        if (!from || !to) throw createError({ statusCode: 400, statusMessage: "Missing from/to" });
        result = await ami.sendAction("Originate", {
          Channel: `Local/${from}@from-internal`,
          Exten: to,
          Context: "from-internal",
          Priority: "1",
          CallerID: `${from} <${from}>`,
          Timeout: "30000",
          Async: "true"
        });
        break;
      }
      case "hangup": {
        const { channel } = params;
        if (!channel) throw createError({ statusCode: 400, statusMessage: "Missing channel" });
        result = await ami.sendAction("Hangup", { Channel: channel });
        break;
      }
      case "blindTransfer": {
        const { channel, extension, context } = params;
        if (!channel || !extension) throw createError({ statusCode: 400, statusMessage: "Missing channel/extension" });
        result = await ami.sendAction("Redirect", {
          Channel: channel,
          Exten: extension,
          Context: context || "from-internal",
          Priority: "1"
        });
        break;
      }
      case "attendedTransfer": {
        const { channel, extension, context } = params;
        if (!channel || !extension) throw createError({ statusCode: 400, statusMessage: "Missing channel/extension" });
        result = await ami.sendAction("Atxfer", {
          Channel: channel,
          Exten: extension,
          Context: context || "from-internal"
        });
        break;
      }
      case "spy": {
        const { extension, mode, fromExtension } = params;
        if (!extension) throw createError({ statusCode: 400, statusMessage: "Missing extension" });
        let opts = "q";
        if (mode === "whisper") opts = "qw";
        else if (mode === "barge") opts = "qB";
        const spyFrom = fromExtension || "operator";
        result = await ami.sendAction("Originate", {
          Channel: `Local/${spyFrom}@from-internal`,
          Application: "ChanSpy",
          Data: `SIP/${extension},${opts}`,
          CallerID: `Spy <${spyFrom}>`,
          Timeout: "30000",
          Async: "true"
        });
        break;
      }
      case "record": {
        const { channel, file } = params;
        if (!channel) throw createError({ statusCode: 400, statusMessage: "Missing channel" });
        const fileName = file || `recording-${Date.now()}`;
        result = await ami.sendAction("MixMonitor", {
          Channel: channel,
          File: `/var/spool/asterisk/monitor/${fileName}.wav`,
          Options: ""
        });
        break;
      }
      case "stopRecord": {
        const { channel } = params;
        if (!channel) throw createError({ statusCode: 400, statusMessage: "Missing channel" });
        result = await ami.sendAction("StopMixMonitor", { Channel: channel });
        break;
      }
      case "queuePause": {
        const { interface: iface, queue, reason, paused } = params;
        if (!iface) throw createError({ statusCode: 400, statusMessage: "Missing interface" });
        const p = {
          Interface: iface,
          Paused: paused !== false && paused !== "false" ? "true" : "false"
        };
        if (queue) p.Queue = queue;
        if (reason) p.Reason = reason;
        result = await ami.sendAction("QueuePause", p);
        break;
      }
      case "queueAdd": {
        const { interface: iface, queue, penalty } = params;
        if (!iface || !queue) throw createError({ statusCode: 400, statusMessage: "Missing interface/queue" });
        result = await ami.sendAction("QueueAdd", {
          Interface: iface,
          Queue: queue,
          Penalty: String(penalty || 0)
        });
        break;
      }
      case "queueRemove": {
        const { interface: iface, queue } = params;
        if (!iface || !queue) throw createError({ statusCode: 400, statusMessage: "Missing interface/queue" });
        result = await ami.sendAction("QueueRemove", {
          Interface: iface,
          Queue: queue
        });
        break;
      }
      case "park": {
        const { channel, timeout } = params;
        if (!channel) throw createError({ statusCode: 400, statusMessage: "Missing channel" });
        result = await ami.sendAction("Park", {
          Channel: channel,
          Timeout: String(timeout || 45)
        });
        break;
      }
      case "pickup": {
        const { channel, fromExtension } = params;
        if (!channel) throw createError({ statusCode: 400, statusMessage: "Missing channel" });
        const from = fromExtension || "operator";
        result = await ami.sendAction("Originate", {
          Channel: `Local/${from}@from-internal`,
          Application: "Pickup",
          Data: channel,
          CallerID: `Pickup <${from}>`,
          Timeout: "15000",
          Async: "true"
        });
        break;
      }
      case "dtmf": {
        const { channel, digit } = params;
        if (!channel || !digit) throw createError({ statusCode: 400, statusMessage: "Missing channel/digit" });
        result = await ami.sendAction("PlayDTMF", {
          Channel: channel,
          Digit: digit
        });
        break;
      }
      case "confMute": {
        const { conference, channel } = params;
        if (!conference || !channel) throw createError({ statusCode: 400, statusMessage: "Missing conference/channel" });
        result = await ami.sendAction("ConfbridgeMute", {
          Conference: conference,
          Channel: channel
        });
        break;
      }
      case "confUnmute": {
        const { conference, channel } = params;
        if (!conference || !channel) throw createError({ statusCode: 400, statusMessage: "Missing conference/channel" });
        result = await ami.sendAction("ConfbridgeUnmute", {
          Conference: conference,
          Channel: channel
        });
        break;
      }
      case "confKick": {
        const { conference, channel } = params;
        if (!conference || !channel) throw createError({ statusCode: 400, statusMessage: "Missing conference/channel" });
        result = await ami.sendAction("ConfbridgeKick", {
          Conference: conference,
          Channel: channel
        });
        break;
      }
      case "retrieveParked": {
        const { slot, fromExtension } = params;
        if (!slot) throw createError({ statusCode: 400, statusMessage: "Missing slot" });
        const from = fromExtension || "operator";
        result = await ami.sendAction("Originate", {
          Channel: `Local/${from}@from-internal`,
          Exten: slot,
          Context: "parkedcalls",
          Priority: "1",
          CallerID: `Park-${slot} <${from}>`,
          Timeout: "30000",
          Async: "true"
        });
        break;
      }
      default:
        throw createError({ statusCode: 400, statusMessage: `Unknown action: ${action}` });
    }
    return { success: true, result };
  } catch (err) {
    if (err.statusCode) throw err;
    throw createError({ statusCode: 500, statusMessage: err.message || "AMI action failed" });
  }
});

export { action_post as default };
//# sourceMappingURL=action.post.mjs.map
