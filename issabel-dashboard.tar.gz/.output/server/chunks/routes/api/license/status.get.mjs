import { d as defineEventHandler, S as getLicenseStatus, T as getMachineId } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const status_get = defineEventHandler(() => {
  const status = getLicenseStatus();
  return {
    valid: status.valid,
    customer: status.customer,
    key: status.key || void 0,
    features: status.features,
    expiresAt: status.expiresAt,
    machineId: getMachineId(),
    reason: status.reason || void 0
  };
});

export { status_get as default };
//# sourceMappingURL=status.get.mjs.map
