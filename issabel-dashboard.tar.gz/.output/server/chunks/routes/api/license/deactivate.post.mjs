import { d as defineEventHandler, r as requireAuth, c as createError, R as deactivateLicense } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const deactivate_post = defineEventHandler(async (event) => {
  const session = requireAuth(event);
  if (!session.isAdmin) {
    throw createError({ statusCode: 403, statusMessage: "Admin access required" });
  }
  await deactivateLicense();
  return { ok: true };
});

export { deactivate_post as default };
//# sourceMappingURL=deactivate.post.mjs.map
