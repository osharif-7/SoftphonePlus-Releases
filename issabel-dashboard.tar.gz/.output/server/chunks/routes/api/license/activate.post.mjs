import { d as defineEventHandler, P as isLicenseValid, A as getHeader, x as getCookie, B as getSession, c as createError, a as readBody, Q as activateLicense } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const activate_post = defineEventHandler(async (event) => {
  var _a;
  if (isLicenseValid()) {
    const authHeader = (_a = getHeader(event, "authorization")) != null ? _a : "";
    const token = authHeader.replace(/^Bearer\s+/i, "").trim() || getCookie(event, "issabel_token") || "";
    const session = getSession(token);
    if (!(session == null ? void 0 : session.isAdmin)) {
      throw createError({ statusCode: 403, statusMessage: "Admin access required" });
    }
  }
  const body = await readBody(event);
  const { key } = body;
  if (!key || typeof key !== "string" || key.trim().length === 0) {
    throw createError({ statusCode: 400, statusMessage: "License key is required" });
  }
  const result = await activateLicense(key.trim());
  if (!result.ok) {
    throw createError({ statusCode: 400, statusMessage: result.reason || "Activation failed" });
  }
  return {
    ok: true,
    customer: result.customer,
    features: result.features
  };
});

export { activate_post as default };
//# sourceMappingURL=activate.post.mjs.map
