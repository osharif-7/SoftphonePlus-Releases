import { d as defineEventHandler, A as getHeader, x as getCookie, B as getSession, c as createError } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const me_get = defineEventHandler((event) => {
  var _a;
  const authHeader = (_a = getHeader(event, "authorization")) != null ? _a : "";
  const token = authHeader.replace(/^Bearer\s+/i, "").trim() || getCookie(event, "issabel_token") || "";
  const session = getSession(token);
  if (!session) {
    throw createError({ statusCode: 401, statusMessage: "Not authenticated" });
  }
  return {
    id: session.userId,
    username: session.username,
    groupId: session.groupId,
    groupName: session.groupName,
    extension: session.extension || "",
    isAdmin: session.groupId === 1
  };
});

export { me_get as default };
//# sourceMappingURL=me.get.mjs.map
