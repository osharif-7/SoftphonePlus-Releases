import { d as defineEventHandler, x as getCookie, y as destroySession, z as deleteCookie } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const logout_post = defineEventHandler((event) => {
  const token = getCookie(event, "issabel_token") || "";
  if (token) {
    destroySession(token);
    deleteCookie(event, "issabel_token", { path: "/" });
  }
  return { ok: true };
});

export { logout_post as default };
//# sourceMappingURL=logout.post.mjs.map
