import { d as defineEventHandler, a as readBody, c as createError, v as authenticateUser, w as setCookie } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const login_post = defineEventHandler(async (event) => {
  const { username, password } = await readBody(event);
  if (!username || !password) {
    throw createError({ statusCode: 400, statusMessage: "Username and password are required" });
  }
  const result = await authenticateUser(username, password);
  if (!result) {
    throw createError({ statusCode: 401, statusMessage: "Invalid credentials" });
  }
  setCookie(event, "issabel_token", result.token, {
    httpOnly: true,
    path: "/",
    maxAge: 86400
  });
  return {
    token: result.token,
    user: {
      id: result.userId,
      username: result.username,
      groupId: result.groupId,
      groupName: result.groupName,
      extension: result.extension || "",
      isAdmin: result.groupId === 1
    }
  };
});

export { login_post as default };
//# sourceMappingURL=login.post.mjs.map
