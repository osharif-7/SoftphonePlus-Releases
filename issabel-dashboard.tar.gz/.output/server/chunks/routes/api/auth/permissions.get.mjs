import { d as defineEventHandler, A as getHeader, x as getCookie, B as getSession, c as createError, s as sqliteQuery } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const permissions_get = defineEventHandler(async (event) => {
  var _a;
  const authHeader = (_a = getHeader(event, "authorization")) != null ? _a : "";
  const token = authHeader.replace(/^Bearer\s+/i, "").trim() || getCookie(event, "issabel_token") || "";
  const session = getSession(token);
  if (!session) {
    throw createError({ statusCode: 401, statusMessage: "Unauthorized" });
  }
  if (session.groupId === 1) {
    return { isAdmin: true, resources: [] };
  }
  const rows = await sqliteQuery(
    `SELECT r.name FROM acl_group_permission gp
     JOIN acl_resource r ON gp.id_resource = r.id
     WHERE gp.id_group = ${session.groupId}`
  );
  return {
    isAdmin: false,
    resources: rows.map((r) => r.split("|")[0] || r)
  };
});

export { permissions_get as default };
//# sourceMappingURL=permissions.get.mjs.map
