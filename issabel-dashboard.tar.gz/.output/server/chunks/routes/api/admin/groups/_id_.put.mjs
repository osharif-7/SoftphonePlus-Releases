import { d as defineEventHandler, r as requireAuth, g as getRouterParam, c as createError, a as readBody, u as updateGroup } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _id__put = defineEventHandler(async (event) => {
  var _a, _b, _c;
  requireAuth(event);
  const id = parseInt((_a = getRouterParam(event, "id")) != null ? _a : "0");
  if (!id) throw createError({ statusCode: 400, statusMessage: "Group ID required" });
  if (id === 1) throw createError({ statusCode: 403, statusMessage: "Cannot rename administrator group" });
  const body = await readBody(event);
  const name = String((_b = body.name) != null ? _b : "").trim();
  const description = String((_c = body.description) != null ? _c : "").trim();
  if (!name) throw createError({ statusCode: 400, statusMessage: "Group name is required" });
  const result = await updateGroup(id, name, description);
  if (!result.ok) throw createError({ statusCode: 500, statusMessage: result.error });
  return { ok: true };
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
