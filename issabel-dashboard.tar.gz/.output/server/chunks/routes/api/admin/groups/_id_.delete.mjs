import { d as defineEventHandler, r as requireAuth, g as getRouterParam, c as createError, e as deleteGroup } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _id__delete = defineEventHandler(async (event) => {
  var _a;
  requireAuth(event);
  const id = parseInt((_a = getRouterParam(event, "id")) != null ? _a : "0");
  if (!id) throw createError({ statusCode: 400, statusMessage: "Group ID required" });
  if (id === 1) throw createError({ statusCode: 403, statusMessage: "Cannot delete administrator group" });
  const result = await deleteGroup(id);
  if (!result.ok) throw createError({ statusCode: 400, statusMessage: result.error });
  return { ok: true };
});

export { _id__delete as default };
//# sourceMappingURL=_id_.delete.mjs.map
