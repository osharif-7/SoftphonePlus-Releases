import { d as defineEventHandler, r as requireAuth, l as listGroups, s as sqliteQuery } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const groups_get = defineEventHandler(async (event) => {
  requireAuth(event);
  const groups = await listGroups();
  const memberCounts = await sqliteQuery(
    "SELECT id_group, COUNT(*) FROM acl_membership GROUP BY id_group"
  );
  const countMap = /* @__PURE__ */ new Map();
  for (const row of memberCounts) {
    const [gid, cnt] = row.split("|");
    countMap.set(parseInt(gid), parseInt(cnt));
  }
  return groups.map((g) => ({
    ...g,
    memberCount: countMap.get(g.id) || 0
  }));
});

export { groups_get as default };
//# sourceMappingURL=groups.get.mjs.map
