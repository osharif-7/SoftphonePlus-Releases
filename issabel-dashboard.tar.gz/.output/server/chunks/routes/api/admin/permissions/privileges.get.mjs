import { d as defineEventHandler, r as requireAuth, m as getAllModulePrivileges } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const privileges_get = defineEventHandler(async (event) => {
  requireAuth(event);
  return getAllModulePrivileges();
});

export { privileges_get as default };
//# sourceMappingURL=privileges.get.mjs.map
