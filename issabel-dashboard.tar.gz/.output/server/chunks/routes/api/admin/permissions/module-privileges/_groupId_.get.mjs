import { d as defineEventHandler, r as requireAuth, g as getRouterParam, c as createError, j as getGroupModulePrivileges } from '../../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _groupId__get = defineEventHandler(async (event) => {
  var _a;
  requireAuth(event);
  const groupId = parseInt((_a = getRouterParam(event, "groupId")) != null ? _a : "0");
  if (!groupId) throw createError({ statusCode: 400, statusMessage: "Group ID required" });
  return getGroupModulePrivileges(groupId);
});

export { _groupId__get as default };
//# sourceMappingURL=_groupId_.get.mjs.map
