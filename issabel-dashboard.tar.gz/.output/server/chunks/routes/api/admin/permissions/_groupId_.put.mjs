import { d as defineEventHandler, r as requireAuth, g as getRouterParam, c as createError, a as readBody, i as setGroupPermissions } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _groupId__put = defineEventHandler(async (event) => {
  var _a, _b;
  requireAuth(event);
  const groupId = parseInt((_a = getRouterParam(event, "groupId")) != null ? _a : "0");
  if (!groupId) throw createError({ statusCode: 400, statusMessage: "Group ID required" });
  const body = await readBody(event);
  const resourceIds = (_b = body.resourceIds) != null ? _b : [];
  const result = await setGroupPermissions(groupId, resourceIds);
  if (!result.ok) throw createError({ statusCode: 500, statusMessage: "Failed to save permissions" });
  return { ok: true };
});

export { _groupId__put as default };
//# sourceMappingURL=_groupId_.put.mjs.map
