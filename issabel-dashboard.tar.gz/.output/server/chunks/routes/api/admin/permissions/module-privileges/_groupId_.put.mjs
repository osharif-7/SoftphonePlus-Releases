import { d as defineEventHandler, r as requireAuth, g as getRouterParam, c as createError, a as readBody, k as setGroupModulePrivileges } from '../../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _groupId__put = defineEventHandler(async (event) => {
  var _a, _b;
  requireAuth(event);
  const groupId = parseInt((_a = getRouterParam(event, "groupId")) != null ? _a : "0");
  if (!groupId) throw createError({ statusCode: 400, statusMessage: "Group ID required" });
  const body = await readBody(event);
  const privilegeIds = (_b = body.privilegeIds) != null ? _b : [];
  const result = await setGroupModulePrivileges(groupId, privilegeIds);
  if (!result.ok) throw createError({ statusCode: 500, statusMessage: "Failed to save module privileges" });
  return { ok: true };
});

export { _groupId__put as default };
//# sourceMappingURL=_groupId_.put.mjs.map
