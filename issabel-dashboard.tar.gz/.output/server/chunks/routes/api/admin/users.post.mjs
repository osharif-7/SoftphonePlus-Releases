import { d as defineEventHandler, a as readBody, c as createError, o as createUser } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const users_post = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e;
  const body = await readBody(event);
  const username = String((_a = body.username) != null ? _a : "").trim();
  const password = String((_b = body.password) != null ? _b : "").trim();
  const description = String((_c = body.description) != null ? _c : "").trim();
  const extension = String((_d = body.extension) != null ? _d : "").trim();
  const groupId = Number((_e = body.groupId) != null ? _e : 0);
  if (!username || !password) {
    throw createError({ statusCode: 400, statusMessage: "Username and password are required" });
  }
  const id = await createUser(username, password, description, extension, groupId);
  return { ok: true, id };
});

export { users_post as default };
//# sourceMappingURL=users.post.mjs.map
