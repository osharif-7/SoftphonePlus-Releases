import { d as defineEventHandler, r as requireAuth, a as readBody, c as createError, b as createGroup } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const groups_post = defineEventHandler(async (event) => {
  var _a, _b;
  requireAuth(event);
  const body = await readBody(event);
  const name = String((_a = body.name) != null ? _a : "").trim();
  const description = String((_b = body.description) != null ? _b : "").trim();
  if (!name) throw createError({ statusCode: 400, statusMessage: "Group name is required" });
  const result = await createGroup(name, description);
  if (!result.ok) throw createError({ statusCode: 500, statusMessage: result.error });
  return { ok: true, id: result.id };
});

export { groups_post as default };
//# sourceMappingURL=groups.post.mjs.map
