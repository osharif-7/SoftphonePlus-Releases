import { d as defineEventHandler, g as getRouterParam, c as createError, a as readBody, t as updateUser } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _id__put = defineEventHandler(async (event) => {
  const id = Number(getRouterParam(event, "id"));
  if (!id) throw createError({ statusCode: 400, statusMessage: "User ID required" });
  const body = await readBody(event);
  await updateUser(id, {
    description: body.description,
    extension: body.extension,
    password: body.password,
    groupId: body.groupId !== void 0 ? Number(body.groupId) : void 0
  });
  return { ok: true };
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
