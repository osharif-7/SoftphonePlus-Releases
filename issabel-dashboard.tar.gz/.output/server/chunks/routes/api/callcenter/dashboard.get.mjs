import { d as defineEventHandler, C as runAsterisk, N as getTodayAbandonedStats, O as getBestQueueAbandoned, F as mysqlQuery } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const dashboard_get = defineEventHandler(async () => {
  var _a;
  const [queueOut, chanOut, abandonedStats] = await Promise.all([
    runAsterisk("queue show"),
    runAsterisk("core show channels concise"),
    getTodayAbandonedStats()
  ]);
  let activeChannels = 0;
  let activeCalls = 0;
  if (chanOut && !chanOut.includes("0 active channels")) {
    const chanLines = chanOut.split("\n").filter((l) => l.includes("!"));
    activeChannels = chanLines.length;
    activeCalls = Math.floor(activeChannels / 2);
  }
  const queues = [];
  let totalMembers = 0;
  let totalWaiting = 0;
  const asteriskAbandonedMap = /* @__PURE__ */ new Map();
  if (queueOut) {
    const qBlocks = queueOut.split(/\n(?=\S+\s+has\s+\d+\s+calls?)/);
    for (const block of qBlocks) {
      const m = block.match(/^(\S+)\s+has\s+(\d+)\s+calls?.*?'(\S+)'\s+strategy\s+\((\d+)s\s+holdtime,\s+(\d+)s\s+talktime\),\s+W:(\d+),\s+C:(\d+),\s+A:(\d+),\s+SL:([^\s]+)/);
      if (!m) continue;
      const memberLines = block.match(/^\s+(SIP|Local|PJSIP|IAX2)\/\S+.*/gm) || [];
      const pausedCount = memberLines.filter((l) => l.includes("(paused)")).length;
      const busyCount = memberLines.filter((l) => /In use|Busy|Ringing/i.test(l)).length;
      const availCount = memberLines.length - pausedCount - busyCount;
      totalMembers += memberLines.length;
      totalWaiting += parseInt(m[2]);
      asteriskAbandonedMap.set(m[1], parseInt(m[8]));
      queues.push({
        name: m[1],
        waiting: parseInt(m[2]),
        strategy: m[3],
        holdtime: parseInt(m[4]),
        talktime: parseInt(m[5]),
        completed: parseInt(m[7]),
        asteriskAbandoned: parseInt(m[8]),
        abandoned: 0,
        // will be filled from CDR
        sl: m[9],
        membersTotal: memberLines.length,
        membersAvailable: availCount,
        membersBusy: busyCount,
        membersPaused: pausedCount
      });
    }
  }
  const bestAbandoned = await getBestQueueAbandoned(asteriskAbandonedMap);
  let totalCompleted = 0;
  let totalAbandoned = 0;
  for (const q of queues) {
    q.abandoned = (_a = bestAbandoned.get(q.name)) != null ? _a : q.asteriskAbandoned;
    totalCompleted += q.completed;
    totalAbandoned += q.abandoned;
  }
  const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  const todayStatsRows = await mysqlQuery(
    `SELECT COUNT(*),
            SUM(CASE WHEN disposition='ANSWERED' THEN 1 ELSE 0 END),
            SUM(CASE WHEN disposition='BUSY' THEN 1 ELSE 0 END),
            SUM(billsec),
            AVG(CASE WHEN billsec>0 THEN billsec ELSE NULL END)
     FROM cdr WHERE calldate >= '${today} 00:00:00'`,
    "asteriskcdrdb"
  );
  let todayStats = {
    totalCalls: 0,
    answered: 0,
    abandoned: 0,
    busy: 0,
    totalTalkTime: 0,
    avgTalkTime: 0,
    abandonRate: 0
  };
  if (todayStatsRows.length) {
    const s = todayStatsRows[0].split("	");
    todayStats = {
      totalCalls: parseInt(s[0]) || 0,
      answered: parseInt(s[1]) || 0,
      abandoned: abandonedStats.abandoned,
      busy: parseInt(s[2]) || 0,
      totalTalkTime: parseInt(s[3]) || 0,
      avgTalkTime: Math.round(parseFloat(s[4]) || 0),
      abandonRate: abandonedStats.abandonRate
    };
  }
  const hourlyRows = await mysqlQuery(
    `SELECT HOUR(calldate), COUNT(*), SUM(CASE WHEN disposition='ANSWERED' THEN 1 ELSE 0 END)
     FROM cdr WHERE calldate >= '${today} 00:00:00' GROUP BY HOUR(calldate) ORDER BY HOUR(calldate)`,
    "asteriskcdrdb"
  );
  const hourly = hourlyRows.map((r) => {
    const [h, total, answered] = r.split("	");
    return { hour: parseInt(h), total: parseInt(total), answered: parseInt(answered || "0") };
  });
  const hourlyAbandonedRows = await mysqlQuery(
    `SELECT hr, COUNT(*) FROM (
       SELECT HOUR(MIN(calldate)) AS hr, channel
       FROM cdr
       WHERE calldate >= '${today} 00:00:00'
         AND channel NOT LIKE 'Local/%'
         AND lastapp IN ('Queue', 'Dial')
       GROUP BY channel
       HAVING SUM(CASE WHEN disposition = 'ANSWERED' THEN 1 ELSE 0 END) = 0
     ) t GROUP BY hr ORDER BY hr`,
    "asteriskcdrdb"
  );
  const hourlyAbandonedMap = /* @__PURE__ */ new Map();
  for (const r of hourlyAbandonedRows) {
    const [h, count] = r.split("	");
    hourlyAbandonedMap.set(parseInt(h), parseInt(count));
  }
  const hourlyWithAbandoned = hourly.map((h) => ({
    ...h,
    abandoned: hourlyAbandonedMap.get(h.hour) || 0
  }));
  const answerRate = totalCompleted + totalAbandoned > 0 ? Math.round(totalCompleted / (totalCompleted + totalAbandoned) * 100) : 0;
  return {
    realtime: {
      activeCalls,
      activeChannels,
      callsWaiting: totalWaiting,
      totalAgents: totalMembers,
      agentsOnCall: queues.reduce((s, q) => s + q.membersBusy, 0),
      agentsPaused: queues.reduce((s, q) => s + q.membersPaused, 0),
      agentsAvailable: queues.reduce((s, q) => s + q.membersAvailable, 0)
    },
    queues,
    todayStats,
    hourly: hourlyWithAbandoned,
    queueTotals: {
      completed: totalCompleted,
      abandoned: totalAbandoned,
      answerRate
    }
  };
});

export { dashboard_get as default };
//# sourceMappingURL=dashboard.get.mjs.map
