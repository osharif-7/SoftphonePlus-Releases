import { d as defineEventHandler, r as requireAuth, F as mysqlQuery } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const ccAgents_get = defineEventHandler(async (event) => {
  requireAuth(event);
  const rows = await mysqlQuery(
    `SELECT id, type, number, name, password, estatus, eccp_password FROM agent ORDER BY number`,
    "call_center"
  );
  return rows.map((r) => {
    const parts = r.split("	");
    return {
      id: parseInt(parts[0]),
      type: parts[1] || "SIP",
      number: parts[2] || "",
      name: parts[3] || "",
      password: parts[4] || "",
      status: parts[5] === "A" ? "Active" : "Inactive",
      statusCode: parts[5] || "A",
      eccpPassword: parts[6] || ""
    };
  });
});

export { ccAgents_get as default };
//# sourceMappingURL=cc-agents.get.mjs.map
