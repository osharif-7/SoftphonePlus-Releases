import { d as defineEventHandler, r as requireAuth, F as mysqlQuery, C as runAsterisk } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const agents_get = defineEventHandler(async (event) => {
  var _a, _b, _c, _d;
  const session = requireAuth(event);
  const extRows = await mysqlQuery(
    "SELECT u.extension, IFNULL(u.name,'') FROM users u ORDER BY u.extension"
  );
  const queueOut = await runAsterisk("queue show");
  const agentQueues = /* @__PURE__ */ new Map();
  if (queueOut) {
    const qBlocks = queueOut.split(/\n(?=\S+\s+has\s+\d+\s+calls?)/);
    for (const block of qBlocks) {
      const headerMatch = block.match(/^(\S+)\s+has/);
      if (!headerMatch) continue;
      const qName = headerMatch[1];
      const memberLines = block.match(/^\s+(SIP|Local|PJSIP|IAX2)\/\S+.*/gm);
      if (!memberLines) continue;
      for (const ml of memberLines) {
        const extMatch = ml.match(/Local\/(\d+)@|(?:SIP|PJSIP|IAX2)\/(\d+)/i);
        if (!extMatch) continue;
        const ext = extMatch[1] || extMatch[2];
        const paused = ml.includes("(paused)");
        const takenMatch = ml.match(/(\d+)\s+calls/);
        const callsTaken = takenMatch ? parseInt(takenMatch[1]) : 0;
        const statusMatch = ml.match(/\(([^)]+)\)\s+(has taken|with)/);
        const status = statusMatch ? statusMatch[1] : "Unknown";
        if (!agentQueues.has(ext)) agentQueues.set(ext, []);
        agentQueues.get(ext).push({ queue: qName, paused, callsTaken, status });
      }
    }
  }
  const staticMemberRows = await mysqlQuery(
    "SELECT id, data FROM queues_details WHERE keyword='member' ORDER BY id"
  );
  const assignedQueues = /* @__PURE__ */ new Map();
  for (const row of staticMemberRows) {
    const [queueId, data] = row.split("	");
    const extMatch = data == null ? void 0 : data.match(/Local\/(\d+)@/);
    if (extMatch) {
      const ext = extMatch[1];
      if (!assignedQueues.has(ext)) assignedQueues.set(ext, []);
      assignedQueues.get(ext).push(queueId);
    }
  }
  const allQueueCfg = await mysqlQuery("SELECT extension FROM queues_config ORDER BY extension");
  for (const qRow of allQueueCfg) {
    const qExt = qRow.trim();
    try {
      const dbOut = await runAsterisk(`database show QPENALTY/${qExt}/agents`);
      if (dbOut && !dbOut.includes("0 results found")) {
        for (const line of dbOut.split("\n")) {
          const m = line.match(/\/QPENALTY\/\d+\/agents\/(\d+)/);
          if (m) {
            const ext = m[1];
            if (!assignedQueues.has(ext)) assignedQueues.set(ext, []);
            if (!assignedQueues.get(ext).includes(qExt)) {
              assignedQueues.get(ext).push(qExt);
            }
          }
        }
      }
    } catch {
    }
  }
  const peerOut = await runAsterisk("sip show peers");
  const peerStatus = /* @__PURE__ */ new Map();
  if (peerOut) {
    for (const line of peerOut.split("\n")) {
      const t = line.trim();
      if (!t || t.startsWith("Name/username") || t.startsWith("Objects found")) continue;
      const parts = t.split(/\s+/);
      const peer = (_c = (_b = (_a = parts[0]) == null ? void 0 : _a.split("/")) == null ? void 0 : _b[0]) != null ? _c : "";
      const status = (_d = parts.at(-1)) != null ? _d : "unknown";
      if (peer) peerStatus.set(peer, status.toLowerCase());
    }
  }
  const pauseReasons = /* @__PURE__ */ new Map();
  if (queueOut) {
    for (const line of queueOut.split("\n")) {
      const pauseMatch = line.match(/Local\/(\d+)@.*\(paused.*reason\s+"([^"]+)"/i);
      if (pauseMatch) {
        pauseReasons.set(pauseMatch[1], pauseMatch[2]);
      }
    }
  }
  const agents = extRows.map((r) => {
    const [ext, name] = r.split("	");
    const loggedQueues = agentQueues.get(ext) || [];
    const configuredQueues = assignedQueues.get(ext) || [];
    const sipStatus = peerStatus.get(ext) || "unregistered";
    const isLoggedIn = loggedQueues.length > 0;
    const isPaused = loggedQueues.every((q) => q.paused) && loggedQueues.length > 0;
    const isOnCall = loggedQueues.some((q) => {
      const s = q.status.toLowerCase();
      return s === "in use" || s === "busy" || s === "ringing" || s === "on hold";
    });
    const totalCalls = loggedQueues.reduce((s, q) => s + q.callsTaken, 0);
    let agentStatus;
    if (isOnCall) agentStatus = "on-call";
    else if (isPaused) agentStatus = "paused";
    else if (isLoggedIn) agentStatus = "available";
    else if (sipStatus === "ok") agentStatus = "idle";
    else agentStatus = "offline";
    return {
      extension: ext,
      name: name || `Agent ${ext}`,
      sipStatus,
      agentStatus,
      loggedQueues: loggedQueues.map((q) => q.queue),
      assignedQueues: configuredQueues,
      isPaused,
      isOnCall,
      totalCallsTaken: totalCalls,
      pauseReason: pauseReasons.get(ext) || "",
      queueDetails: loggedQueues.map((q) => ({
        queue: q.queue,
        callsTaken: q.callsTaken,
        paused: q.paused,
        status: q.status
      }))
    };
  });
  let breakCodes = [];
  try {
    const breakRows = await mysqlQuery(
      "SELECT id, name, description FROM break WHERE status='A' AND tipo='B' ORDER BY id",
      "call_center"
    );
    if (breakRows.length) {
      breakCodes = breakRows.map((r) => {
        const parts = r.split("	");
        return { id: parts[0], label: parts[1] || parts[2] || `Break ${parts[0]}` };
      });
    }
  } catch {
  }
  if (!breakCodes.length) {
    breakCodes = [
      { id: "break", label: "Break" },
      { id: "lunch", label: "Lunch" },
      { id: "bathroom", label: "Bathroom" },
      { id: "meeting", label: "Meeting" },
      { id: "training", label: "Training" },
      { id: "other", label: "Other" }
    ];
  }
  return {
    agents,
    currentUser: {
      extension: session.extension,
      isAdmin: session.groupId === 1
    },
    summary: {
      total: agents.length,
      available: agents.filter((a) => a.agentStatus === "available").length,
      onCall: agents.filter((a) => a.agentStatus === "on-call").length,
      paused: agents.filter((a) => a.agentStatus === "paused").length,
      idle: agents.filter((a) => a.agentStatus === "idle").length,
      offline: agents.filter((a) => a.agentStatus === "offline").length
    },
    breakCodes
  };
});

export { agents_get as default };
//# sourceMappingURL=agents.get.mjs.map
