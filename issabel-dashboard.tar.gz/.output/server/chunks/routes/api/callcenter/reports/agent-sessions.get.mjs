import { d as defineEventHandler, r as requireAuth, J as getQuery, F as mysqlQuery } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const agentSessions_get = defineEventHandler(async (event) => {
  requireAuth(event);
  const query = getQuery(event);
  const dateStart = String(query.dateStart || (/* @__PURE__ */ new Date()).toISOString().split("T")[0]);
  const dateEnd = String(query.dateEnd || dateStart);
  const sessionRows = await mysqlQuery(
    `SELECT a.number, a.name,
            au.datetime_init, au.datetime_end, au.duration
     FROM audit au
     JOIN agent a ON a.id=au.id_agent
     WHERE au.id_break IS NULL
       AND au.datetime_init >= '${dateStart} 00:00:00'
       AND au.datetime_init <= '${dateEnd} 23:59:59'
     ORDER BY au.datetime_init DESC`,
    "call_center"
  );
  const sessions = sessionRows.map((r) => {
    const p = r.split("	");
    return {
      agentNumber: p[0],
      agentName: p[1],
      loginTime: p[2] || "",
      logoutTime: p[3] || "",
      duration: p[4] || ""
    };
  });
  const summaryRows = await mysqlQuery(
    `SELECT a.number, a.name,
            COUNT(au.id) AS total_sessions,
            SEC_TO_TIME(SUM(TIME_TO_SEC(IFNULL(au.duration, '00:00:00')))) AS total_time,
            (SELECT COUNT(*) FROM calls c WHERE c.id_agent=a.id AND c.start_time >= '${dateStart} 00:00:00' AND c.start_time <= '${dateEnd} 23:59:59') AS outbound_calls,
            (SELECT COUNT(*) FROM call_entry ce WHERE ce.id_agent=a.id AND ce.datetime_init >= '${dateStart} 00:00:00' AND ce.datetime_init <= '${dateEnd} 23:59:59') AS inbound_calls
     FROM audit au
     JOIN agent a ON a.id=au.id_agent
     WHERE au.id_break IS NULL
       AND au.datetime_init >= '${dateStart} 00:00:00'
       AND au.datetime_init <= '${dateEnd} 23:59:59'
     GROUP BY a.id ORDER BY a.number`,
    "call_center"
  );
  const summary = summaryRows.map((r) => {
    const p = r.split("	");
    return {
      agentNumber: p[0],
      agentName: p[1],
      totalSessions: parseInt(p[2]) || 0,
      totalTime: p[3] || "00:00:00",
      outboundCalls: parseInt(p[4]) || 0,
      inboundCalls: parseInt(p[5]) || 0
    };
  });
  return { sessions, summary, dateStart, dateEnd };
});

export { agentSessions_get as default };
//# sourceMappingURL=agent-sessions.get.mjs.map
