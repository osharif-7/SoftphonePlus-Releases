import { d as defineEventHandler, r as requireAuth, J as getQuery, F as mysqlQuery } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const callsPerAgent_get = defineEventHandler(async (event) => {
  requireAuth(event);
  const query = getQuery(event);
  const dateStart = String(query.dateStart || (/* @__PURE__ */ new Date()).toISOString().split("T")[0]);
  const dateEnd = String(query.dateEnd || dateStart);
  const campaignType = String(query.type || "all");
  const agents = [];
  if (campaignType === "all" || campaignType === "outbound") {
    const outRows = await mysqlQuery(
      `SELECT a.number, a.name,
              COUNT(c.id) AS total,
              SUM(CASE WHEN c.status='Success' THEN 1 ELSE 0 END) AS success,
              SUM(CASE WHEN c.status='Failure' THEN 1 ELSE 0 END) AS failure,
              SUM(CASE WHEN c.status='ShortCall' THEN 1 ELSE 0 END) AS short_call,
              SUM(CASE WHEN c.status='NoAnswer' THEN 1 ELSE 0 END) AS no_answer,
              IFNULL(SUM(c.duration), 0) AS total_duration,
              IFNULL(AVG(c.duration), 0) AS avg_duration
       FROM agent a
       LEFT JOIN calls c ON c.id_agent=a.id AND c.start_time >= '${dateStart} 00:00:00' AND c.start_time <= '${dateEnd} 23:59:59'
       WHERE a.estatus='A'
       GROUP BY a.id ORDER BY a.number`,
      "call_center"
    );
    for (const r of outRows) {
      const p = r.split("	");
      agents.push({
        number: p[0],
        name: p[1],
        direction: "outbound",
        total: parseInt(p[2]) || 0,
        success: parseInt(p[3]) || 0,
        failure: parseInt(p[4]) || 0,
        shortCall: parseInt(p[5]) || 0,
        noAnswer: parseInt(p[6]) || 0,
        totalDuration: parseInt(p[7]) || 0,
        avgDuration: Math.round(parseFloat(p[8]) || 0)
      });
    }
  }
  if (campaignType === "all" || campaignType === "inbound") {
    const inRows = await mysqlQuery(
      `SELECT a.number, a.name,
              COUNT(ce.id) AS total,
              SUM(CASE WHEN ce.status='terminada' THEN 1 ELSE 0 END) AS success,
              SUM(CASE WHEN ce.status='abandonada' THEN 1 ELSE 0 END) AS abandoned,
              IFNULL(SUM(ce.duration), 0) AS total_duration,
              IFNULL(AVG(ce.duration), 0) AS avg_duration,
              IFNULL(AVG(ce.duration_wait), 0) AS avg_wait
       FROM agent a
       LEFT JOIN call_entry ce ON ce.id_agent=a.id AND ce.datetime_init >= '${dateStart} 00:00:00' AND ce.datetime_init <= '${dateEnd} 23:59:59'
       WHERE a.estatus='A'
       GROUP BY a.id ORDER BY a.number`,
      "call_center"
    );
    for (const r of inRows) {
      const p = r.split("	");
      agents.push({
        number: p[0],
        name: p[1],
        direction: "inbound",
        total: parseInt(p[2]) || 0,
        success: parseInt(p[3]) || 0,
        abandoned: parseInt(p[4]) || 0,
        totalDuration: parseInt(p[5]) || 0,
        avgDuration: Math.round(parseFloat(p[6]) || 0),
        avgWait: Math.round(parseFloat(p[7]) || 0)
      });
    }
  }
  return { agents, dateStart, dateEnd };
});

export { callsPerAgent_get as default };
//# sourceMappingURL=calls-per-agent.get.mjs.map
