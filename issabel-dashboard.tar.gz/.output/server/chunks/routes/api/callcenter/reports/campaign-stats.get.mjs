import { d as defineEventHandler, r as requireAuth, J as getQuery, F as mysqlQuery } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const campaignStats_get = defineEventHandler(async (event) => {
  requireAuth(event);
  const query = getQuery(event);
  const dateStart = String(query.dateStart || (/* @__PURE__ */ new Date()).toISOString().split("T")[0]);
  const dateEnd = String(query.dateEnd || dateStart);
  const outRows = await mysqlQuery(
    `SELECT c.id, c.name, c.estatus,
            (SELECT COUNT(*) FROM calls WHERE id_campaign=c.id) AS total_contacts,
            (SELECT COUNT(*) FROM calls WHERE id_campaign=c.id AND status='Success' AND start_time >= '${dateStart} 00:00:00' AND start_time <= '${dateEnd} 23:59:59') AS success_today,
            (SELECT COUNT(*) FROM calls WHERE id_campaign=c.id AND status='Failure' AND start_time >= '${dateStart} 00:00:00' AND start_time <= '${dateEnd} 23:59:59') AS failure_today,
            (SELECT COUNT(*) FROM calls WHERE id_campaign=c.id AND status='NoAnswer' AND start_time >= '${dateStart} 00:00:00' AND start_time <= '${dateEnd} 23:59:59') AS no_answer_today,
            (SELECT COUNT(*) FROM calls WHERE id_campaign=c.id AND status='ShortCall' AND start_time >= '${dateStart} 00:00:00' AND start_time <= '${dateEnd} 23:59:59') AS short_today,
            (SELECT COUNT(*) FROM calls WHERE id_campaign=c.id AND status IS NULL) AS pending,
            (SELECT IFNULL(AVG(duration), 0) FROM calls WHERE id_campaign=c.id AND status='Success' AND start_time >= '${dateStart} 00:00:00' AND start_time <= '${dateEnd} 23:59:59') AS avg_duration
     FROM campaign c ORDER BY c.id DESC`,
    "call_center"
  );
  const outbound = outRows.map((r) => {
    const p = r.split("	");
    return {
      id: parseInt(p[0]),
      name: p[1],
      status: p[2] === "A" ? "Active" : p[2] === "T" ? "Terminated" : "Inactive",
      totalContacts: parseInt(p[3]) || 0,
      success: parseInt(p[4]) || 0,
      failure: parseInt(p[5]) || 0,
      noAnswer: parseInt(p[6]) || 0,
      shortCall: parseInt(p[7]) || 0,
      pending: parseInt(p[8]) || 0,
      avgDuration: Math.round(parseFloat(p[9]) || 0)
    };
  });
  const inRows = await mysqlQuery(
    `SELECT ce.id, ce.name, ce.estatus, qce.queue,
            (SELECT COUNT(*) FROM call_entry WHERE id_campaign=ce.id AND datetime_init >= '${dateStart} 00:00:00' AND datetime_init <= '${dateEnd} 23:59:59') AS total_today,
            (SELECT COUNT(*) FROM call_entry WHERE id_campaign=ce.id AND status='terminada' AND datetime_init >= '${dateStart} 00:00:00' AND datetime_init <= '${dateEnd} 23:59:59') AS answered_today,
            (SELECT COUNT(*) FROM call_entry WHERE id_campaign=ce.id AND status='abandonada' AND datetime_init >= '${dateStart} 00:00:00' AND datetime_init <= '${dateEnd} 23:59:59') AS abandoned_today,
            (SELECT IFNULL(AVG(duration), 0) FROM call_entry WHERE id_campaign=ce.id AND status='terminada' AND datetime_init >= '${dateStart} 00:00:00' AND datetime_init <= '${dateEnd} 23:59:59') AS avg_duration,
            (SELECT IFNULL(AVG(duration_wait), 0) FROM call_entry WHERE id_campaign=ce.id AND datetime_init >= '${dateStart} 00:00:00' AND datetime_init <= '${dateEnd} 23:59:59') AS avg_wait
     FROM campaign_entry ce
     LEFT JOIN queue_call_entry qce ON qce.id=ce.id_queue_call_entry
     ORDER BY ce.id DESC`,
    "call_center"
  );
  const inbound = inRows.map((r) => {
    const p = r.split("	");
    return {
      id: parseInt(p[0]),
      name: p[1],
      status: p[2] === "A" ? "Active" : "Inactive",
      queue: p[3] || "",
      total: parseInt(p[4]) || 0,
      answered: parseInt(p[5]) || 0,
      abandoned: parseInt(p[6]) || 0,
      avgDuration: Math.round(parseFloat(p[7]) || 0),
      avgWait: Math.round(parseFloat(p[8]) || 0)
    };
  });
  return { outbound, inbound, dateStart, dateEnd };
});

export { campaignStats_get as default };
//# sourceMappingURL=campaign-stats.get.mjs.map
