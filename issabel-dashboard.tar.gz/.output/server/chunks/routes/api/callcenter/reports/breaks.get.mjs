import { d as defineEventHandler, r as requireAuth, J as getQuery, F as mysqlQuery } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const breaks_get = defineEventHandler(async (event) => {
  requireAuth(event);
  const query = getQuery(event);
  const dateStart = String(query.dateStart || (/* @__PURE__ */ new Date()).toISOString().split("T")[0]);
  const dateEnd = String(query.dateEnd || dateStart);
  const breakRows = await mysqlQuery(
    `SELECT a.number, a.name, b.name AS break_name,
            au.datetime_init, au.datetime_end, au.duration
     FROM audit au
     JOIN agent a ON a.id=au.id_agent
     LEFT JOIN break b ON b.id=au.id_break
     WHERE au.id_break IS NOT NULL
       AND au.datetime_init >= '${dateStart} 00:00:00'
       AND au.datetime_init <= '${dateEnd} 23:59:59'
     ORDER BY au.datetime_init DESC`,
    "call_center"
  );
  const records = breakRows.map((r) => {
    const p = r.split("	");
    return {
      agentNumber: p[0],
      agentName: p[1],
      breakType: p[2] || "Unknown",
      startTime: p[3] || "",
      endTime: p[4] || "",
      duration: p[5] || ""
    };
  });
  const summaryRows = await mysqlQuery(
    `SELECT a.number, a.name,
            COUNT(au.id) AS total_breaks,
            SEC_TO_TIME(SUM(TIME_TO_SEC(IFNULL(au.duration, '00:00:00')))) AS total_break_time
     FROM audit au
     JOIN agent a ON a.id=au.id_agent
     WHERE au.id_break IS NOT NULL
       AND au.datetime_init >= '${dateStart} 00:00:00'
       AND au.datetime_init <= '${dateEnd} 23:59:59'
     GROUP BY a.id ORDER BY a.number`,
    "call_center"
  );
  const summary = summaryRows.map((r) => {
    const p = r.split("	");
    return {
      agentNumber: p[0],
      agentName: p[1],
      totalBreaks: parseInt(p[2]) || 0,
      totalBreakTime: p[3] || "00:00:00"
    };
  });
  const typeRows = await mysqlQuery(
    `SELECT IFNULL(b.name, 'Unknown') AS break_name,
            COUNT(au.id) AS count,
            SEC_TO_TIME(SUM(TIME_TO_SEC(IFNULL(au.duration, '00:00:00')))) AS total_time
     FROM audit au
     LEFT JOIN break b ON b.id=au.id_break
     WHERE au.id_break IS NOT NULL
       AND au.datetime_init >= '${dateStart} 00:00:00'
       AND au.datetime_init <= '${dateEnd} 23:59:59'
     GROUP BY au.id_break ORDER BY count DESC`,
    "call_center"
  );
  const byType = typeRows.map((r) => {
    const p = r.split("	");
    return { breakType: p[0], count: parseInt(p[1]) || 0, totalTime: p[2] || "00:00:00" };
  });
  return { records, summary, byType, dateStart, dateEnd };
});

export { breaks_get as default };
//# sourceMappingURL=breaks.get.mjs.map
