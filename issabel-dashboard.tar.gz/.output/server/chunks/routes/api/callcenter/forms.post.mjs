import { d as defineEventHandler, r as requireAuth, c as createError, a as readBody, D as mysqlExec, F as mysqlQuery } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const forms_post = defineEventHandler(async (event) => {
  const session = requireAuth(event);
  if (session.groupId !== 1) throw createError({ statusCode: 403, statusMessage: "Admin only" });
  const body = await readBody(event);
  const { name, description, status } = body;
  if (!name) throw createError({ statusCode: 400, statusMessage: "Form name is required" });
  const esc = (s) => (s || "").replace(/'/g, "\\'");
  const result = await mysqlExec(
    `INSERT INTO form (nombre, descripcion, estatus) VALUES ('${esc(name)}','${esc(description || "")}','${status === "I" ? "I" : "A"}')`,
    "call_center"
  );
  if (!result.ok) throw createError({ statusCode: 500, statusMessage: result.error });
  const idRows = await mysqlQuery("SELECT LAST_INSERT_ID()", "call_center");
  return { ok: true, id: parseInt(idRows[0]) || 0 };
});

export { forms_post as default };
//# sourceMappingURL=forms.post.mjs.map
