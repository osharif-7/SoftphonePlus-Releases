import { d as defineEventHandler, r as requireAuth, F as mysqlQuery } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const eccpUsers_get = defineEventHandler(async (event) => {
  requireAuth(event);
  const rows = await mysqlQuery(
    "SELECT id, username, password, company, status FROM eccp_authorized_clients ORDER BY id",
    "call_center"
  );
  return rows.map((r) => {
    const parts = r.split("	");
    return {
      id: parseInt(parts[0]),
      username: parts[1] || "",
      password: parts[2] || "",
      company: parts[3] || "",
      status: parts[4] === "A" ? "Active" : "Inactive",
      statusCode: parts[4] || "A"
    };
  });
});

export { eccpUsers_get as default };
//# sourceMappingURL=eccp-users.get.mjs.map
