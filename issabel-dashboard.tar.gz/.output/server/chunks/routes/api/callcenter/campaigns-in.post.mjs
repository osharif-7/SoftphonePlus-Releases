import { d as defineEventHandler, r as requireAuth, c as createError, a as readBody, D as mysqlExec, F as mysqlQuery } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const campaignsIn_post = defineEventHandler(async (event) => {
  const session = requireAuth(event);
  if (session.groupId !== 1) throw createError({ statusCode: 403, statusMessage: "Admin only" });
  const body = await readBody(event);
  const { name, queue, dateStart, dateEnd, timeStart, timeEnd, script, status } = body;
  if (!name) throw createError({ statusCode: 400, statusMessage: "Campaign name is required" });
  if (!queue) throw createError({ statusCode: 400, statusMessage: "Queue is required" });
  const esc = (s) => (s || "").replace(/'/g, "\\'");
  await mysqlExec(
    `INSERT INTO queue_call_entry (queue, date_init, time_init, date_end, time_end, estatus, script)
     VALUES ('${esc(queue)}','${dateStart || "2025-01-01"}','${timeStart || "00:00:00"}','${dateEnd || "2030-12-31"}','${timeEnd || "23:59:59"}','${status === "I" ? "I" : "A"}','${esc(script || "")}')`,
    "call_center"
  );
  const qceId = await mysqlQuery("SELECT LAST_INSERT_ID()", "call_center");
  const qceIdVal = parseInt(qceId[0]) || 0;
  const result = await mysqlExec(
    `INSERT INTO campaign_entry (name, id_queue_call_entry, datetime_init, datetime_end, daytime_init, daytime_end, estatus, script)
     VALUES ('${esc(name)}',${qceIdVal},'${dateStart || "2025-01-01"}','${dateEnd || "2030-12-31"}','${timeStart || "00:00:00"}','${timeEnd || "23:59:59"}','${status === "I" ? "I" : "A"}','${esc(script || "")}')`,
    "call_center"
  );
  if (!result.ok) throw createError({ statusCode: 500, statusMessage: result.error });
  return { ok: true };
});

export { campaignsIn_post as default };
//# sourceMappingURL=campaigns-in.post.mjs.map
