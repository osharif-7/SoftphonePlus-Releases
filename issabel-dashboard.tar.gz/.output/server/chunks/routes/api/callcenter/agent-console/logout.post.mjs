import { d as defineEventHandler, r as requireAuth, a as readBody, c as createError, D as mysqlExec, I as removeHeartbeat, E as execCmd, F as mysqlQuery } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const MEMBER_INTERFACES = (ext) => [
  `Local/${ext}@from-queue/n`,
  `SIP/${ext}`,
  `PJSIP/${ext}`,
  `IAX2/${ext}`
];
async function getAssignedQueues(ext) {
  const allQueues = await mysqlQuery("SELECT extension FROM queues_config ORDER BY extension");
  const assigned = [];
  for (const qRow of allQueues) {
    const qExt = qRow.trim();
    if (!qExt) continue;
    const staticRows = await mysqlQuery(
      `SELECT id FROM queues_details WHERE keyword='member' AND id='${qExt}' AND (data LIKE '%Local/${ext}@%' OR data LIKE '%SIP/${ext}%' OR data LIKE '%PJSIP/${ext}%' OR data LIKE '%IAX2/${ext}%')`
    );
    if (staticRows.length) {
      assigned.push(qExt);
      continue;
    }
    try {
      const result = await execCmd("asterisk", ["-rx", `database show QPENALTY/${qExt}/agents/${ext}`]);
      const dbOut = `${result.stdout}
${result.stderr}`;
      if (!dbOut.includes("0 results found") && !dbOut.includes("not found") && dbOut.includes(ext)) {
        assigned.push(qExt);
      }
    } catch {
    }
  }
  return assigned;
}
async function pauseInAllQueues(ext, reason) {
  const assigned = await getAssignedQueues(ext);
  let count = 0;
  const esc = (s) => (s || "").replace(/'/g, "\\'");
  for (const q of assigned) {
    for (const iface of MEMBER_INTERFACES(ext)) {
      try {
        await execCmd("asterisk", ["-rx", `queue pause member ${iface} queue ${q} reason "${esc(reason)}"`]);
        count++;
      } catch {
      }
    }
  }
  return count;
}
const logout_post = defineEventHandler(async (event) => {
  try {
    requireAuth(event);
  } catch {
  }
  const body = await readBody(event);
  const { agentId, extension } = body;
  if (!agentId) throw createError({ statusCode: 400, statusMessage: "Agent ID required" });
  const id = parseInt(agentId);
  if (!id || isNaN(id)) throw createError({ statusCode: 400, statusMessage: "Invalid agent ID" });
  let pausedCount = 0;
  if (extension) {
    try {
      pausedCount = await pauseInAllQueues(String(extension), "Session ended");
      console.log(`[Logout] Paused agent ${extension} (id=${id}) in ${pausedCount} queue interfaces`);
    } catch (err) {
      console.error(`[Logout] Failed to pause ${extension} in queues:`, err);
    }
  }
  await mysqlExec(
    `UPDATE audit SET datetime_end=NOW(), duration=TIMEDIFF(NOW(), datetime_init)
     WHERE id_agent=${id} AND id_break IS NOT NULL AND datetime_end IS NULL`,
    "call_center"
  );
  await mysqlExec(
    `UPDATE audit SET datetime_end=NOW(), duration=TIMEDIFF(NOW(), datetime_init)
     WHERE id_agent=${id} AND id_break IS NULL AND datetime_end IS NULL`,
    "call_center"
  );
  removeHeartbeat(id);
  return { ok: true, pausedInQueues: pausedCount };
});

export { logout_post as default };
//# sourceMappingURL=logout.post.mjs.map
