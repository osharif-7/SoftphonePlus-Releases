import { d as defineEventHandler, r as requireAuth, F as mysqlQuery } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const agentsList_get = defineEventHandler(async (event) => {
  requireAuth(event);
  const rows = await mysqlQuery(
    "SELECT id, type, number, name FROM agent WHERE estatus='A' ORDER BY type, number",
    "call_center"
  );
  const agents = rows.map((r) => {
    const [id, type, number, name] = r.split("	");
    return {
      id: parseInt(id),
      type,
      number,
      name: name || "",
      channel: `${type}/${number}`,
      label: `${type}/${number} - ${name || number}`
    };
  });
  const staticAgents = agents.filter((a) => a.type === "Agent");
  const callbackAgents = agents.filter((a) => a.type !== "Agent");
  return { staticAgents, callbackAgents };
});

export { agentsList_get as default };
//# sourceMappingURL=agents-list.get.mjs.map
