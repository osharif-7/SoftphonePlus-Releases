import { d as defineEventHandler, r as requireAuth, a as readBody, c as createError, F as mysqlQuery, G as closeStaleSession, D as mysqlExec, H as recordHeartbeat, E as execCmd } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

async function getAssignedQueues(ext) {
  const allQueues = await mysqlQuery("SELECT extension FROM queues_config ORDER BY extension");
  const assigned = [];
  for (const qRow of allQueues) {
    const qExt = qRow.trim();
    if (!qExt) continue;
    const staticRows = await mysqlQuery(
      `SELECT id FROM queues_details WHERE keyword='member' AND id='${qExt}' AND (data LIKE '%Local/${ext}@%' OR data LIKE '%SIP/${ext}%' OR data LIKE '%PJSIP/${ext}%' OR data LIKE '%IAX2/${ext}%')`
    );
    if (staticRows.length) {
      assigned.push(qExt);
      continue;
    }
    try {
      const result = await execCmd("asterisk", ["-rx", `database show QPENALTY/${qExt}/agents/${ext}`]);
      const dbOut = `${result.stdout}
${result.stderr}`;
      if (!dbOut.includes("0 results found") && !dbOut.includes("not found") && dbOut.includes(ext)) {
        assigned.push(qExt);
      }
    } catch {
    }
  }
  return assigned;
}
const login_post = defineEventHandler(async (event) => {
  requireAuth(event);
  const body = await readBody(event);
  const { agentChannel, password } = body;
  if (!agentChannel || !password) {
    throw createError({ statusCode: 400, statusMessage: "Agent and password are required" });
  }
  const [type, number] = agentChannel.split("/");
  if (!type || !number) {
    throw createError({ statusCode: 400, statusMessage: "Invalid agent format" });
  }
  const esc = (s) => (s || "").replace(/'/g, "\\'");
  const rows = await mysqlQuery(
    `SELECT id, name, eccp_password FROM agent WHERE type='${esc(type)}' AND number='${esc(number)}' AND password='${esc(password)}' AND estatus='A'`,
    "call_center"
  );
  if (!rows.length) {
    throw createError({ statusCode: 401, statusMessage: "Invalid credentials or agent inactive" });
  }
  const parts = rows[0].split("	");
  const agentId = parseInt(parts[0]);
  const agentName = parts[1] || "";
  const assignedQueues = await getAssignedQueues(number);
  await closeStaleSession(agentId);
  await mysqlExec(
    `INSERT INTO audit (id_agent, id_break, datetime_init) VALUES (${agentId}, NULL, NOW())`,
    "call_center"
  );
  recordHeartbeat(agentId, number);
  return {
    ok: true,
    agent: {
      id: agentId,
      type,
      number,
      channel: agentChannel,
      name: agentName,
      assignedQueues
    }
  };
});

export { login_post as default };
//# sourceMappingURL=login.post.mjs.map
