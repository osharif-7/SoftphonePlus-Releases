import { d as defineEventHandler, r as requireAuth, J as getQuery, c as createError, H as recordHeartbeat, K as cleanupStaleSessions, F as mysqlQuery, E as execCmd, C as runAsterisk } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const status_get = defineEventHandler(async (event) => {
  var _a;
  requireAuth(event);
  const query = getQuery(event);
  const ext = String(query.extension || "");
  const type = String(query.type || "SIP");
  const agentId = parseInt(String(query.agentId || "0"));
  if (!ext) throw createError({ statusCode: 400, statusMessage: "Extension required" });
  if (agentId) recordHeartbeat(agentId, ext);
  cleanupStaleSessions().catch(() => {
  });
  let hasActiveSession = false;
  let hasActiveBreak = false;
  let activeBreakName = "";
  if (agentId) {
    const sessionRows = await mysqlQuery(
      `SELECT id FROM audit WHERE id_agent=${agentId} AND id_break IS NULL AND datetime_end IS NULL LIMIT 1`,
      "call_center"
    );
    hasActiveSession = sessionRows.length > 0;
    if (hasActiveSession) {
      const breakRows = await mysqlQuery(
        `SELECT a.id, b.name FROM audit a LEFT JOIN \`break\` b ON a.id_break=b.id WHERE a.id_agent=${agentId} AND a.id_break IS NOT NULL AND a.datetime_end IS NULL ORDER BY a.id DESC LIMIT 1`,
        "call_center"
      );
      if (breakRows.length) {
        hasActiveBreak = true;
        const parts = breakRows[0].split("	");
        activeBreakName = parts[1] || "Break";
      }
    }
  }
  const allQueues = await mysqlQuery("SELECT extension FROM queues_config ORDER BY extension");
  const assignedQueues = [];
  for (const qRow of allQueues) {
    const qExt = qRow.trim();
    if (!qExt) continue;
    const staticRows = await mysqlQuery(
      `SELECT id FROM queues_details WHERE keyword='member' AND id='${qExt}' AND (data LIKE '%Local/${ext}@%' OR data LIKE '%SIP/${ext}%' OR data LIKE '%PJSIP/${ext}%' OR data LIKE '%IAX2/${ext}%')`
    );
    if (staticRows.length) {
      assignedQueues.push(qExt);
      continue;
    }
    try {
      const result = await execCmd("asterisk", ["-rx", `database show QPENALTY/${qExt}/agents/${ext}`]);
      const dbOut = `${result.stdout}
${result.stderr}`;
      if (!dbOut.includes("0 results found") && !dbOut.includes("not found") && dbOut.includes(ext)) {
        assignedQueues.push(qExt);
      }
    } catch {
    }
  }
  const queueOut = await runAsterisk("queue show");
  const loggedQueues = [];
  let isOnCall = false;
  if (queueOut) {
    const blocks = queueOut.split(/\n(?=\S+\s+has\s+\d+\s+calls?)/);
    for (const block of blocks) {
      const hm = block.match(/^(\S+)\s+has/);
      if (!hm) continue;
      const qName = hm[1];
      if (!assignedQueues.includes(qName)) continue;
      const lines = block.split("\n");
      for (const line of lines) {
        const ifaceMatch = line.match(/\((?:Local\/(\d+)@|(?:SIP|PJSIP|IAX2)\/(\d+))/i);
        if (!ifaceMatch) continue;
        const memberExt = ifaceMatch[1] || ifaceMatch[2];
        if (memberExt !== ext) continue;
        const paused = /\(paused\)/i.test(line);
        const takenMatch = line.match(/has taken\s+(\d+)\s+calls?/i);
        const callsTaken = takenMatch ? parseInt(takenMatch[1]) : 0;
        let status = "Not in use";
        const statusMatch = line.match(/\((Not in use|In use|Unavailable|Invalid|Ringing|Unknown|Busy|On Hold)\)/i);
        if (statusMatch) status = statusMatch[1];
        const sl = status.toLowerCase();
        if (sl === "in use" || sl === "busy" || sl === "ringing" || sl === "on hold") {
          isOnCall = true;
        }
        loggedQueues.push({ queue: qName, paused, callsTaken, status });
        break;
      }
    }
  }
  const totalCalls = loggedQueues.reduce((s, q) => s + q.callsTaken, 0);
  const allPaused = loggedQueues.length > 0 && loggedQueues.every((q) => q.paused);
  const isLoggedIn = hasActiveSession && !allPaused;
  const isPaused = hasActiveSession && hasActiveBreak;
  const pauseReason = activeBreakName;
  let agentStatus;
  if (!hasActiveSession) agentStatus = "logged-out";
  else if (isOnCall) agentStatus = "on-call";
  else if (hasActiveBreak) agentStatus = "paused";
  else if (!allPaused) agentStatus = "available";
  else agentStatus = "logged-out";
  let sipStatus = "unknown";
  const peerOut = await runAsterisk("sip show peers");
  if (peerOut) {
    for (const line of peerOut.split("\n")) {
      if (line.trim().startsWith(ext + "/") || line.trim().startsWith(ext + " ")) {
        const parts = line.trim().split(/\s+/);
        sipStatus = ((_a = parts.at(-1)) != null ? _a : "unknown").toLowerCase();
        break;
      }
    }
  }
  if (sipStatus === "unknown") {
    const pjOut = await runAsterisk("pjsip show endpoints");
    if (pjOut && pjOut.includes(ext)) {
      sipStatus = pjOut.includes("Avail") ? "ok" : "unavailable";
    }
  }
  let breakCodes = [];
  try {
    const breakRows = await mysqlQuery(
      "SELECT id, name FROM `break` WHERE status='A' ORDER BY id",
      "call_center"
    );
    breakCodes = breakRows.map((r) => {
      const [id, name] = r.split("	");
      return { id, label: name || `Break ${id}` };
    });
  } catch {
  }
  let currentCall = null;
  try {
    const chanOut = await runAsterisk("core show channels concise");
    if (chanOut) {
      for (const line of chanOut.split("\n")) {
        if (!line.includes(`${type}/${ext}`) && !line.includes(`Local/${ext}@`)) continue;
        const parts = line.split("!");
        if (parts.length >= 7 && parts[6] === "Up") {
          currentCall = {
            channel: parts[0],
            callerID: parts[7] || "",
            duration: parts[11] || ""
          };
          break;
        }
      }
    }
  } catch {
  }
  return {
    extension: ext,
    agentStatus,
    isLoggedIn,
    isPaused,
    isOnCall,
    totalCalls,
    pauseReason,
    sipStatus,
    loggedQueues,
    assignedQueues,
    breakCodes,
    currentCall,
    hasActiveSession
  };
});

export { status_get as default };
//# sourceMappingURL=status.get.mjs.map
