import { d as defineEventHandler, r as requireAuth, a as readBody, c as createError, C as runAsterisk, D as mysqlExec, E as execCmd, F as mysqlQuery } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

async function getAssignedQueues(ext) {
  const allQueues = await mysqlQuery("SELECT extension FROM queues_config ORDER BY extension");
  const assigned = [];
  for (const qRow of allQueues) {
    const qExt = qRow.trim();
    if (!qExt) continue;
    const staticRows = await mysqlQuery(
      `SELECT id FROM queues_details WHERE keyword='member' AND id='${qExt}' AND (data LIKE '%Local/${ext}@%' OR data LIKE '%SIP/${ext}%' OR data LIKE '%PJSIP/${ext}%' OR data LIKE '%IAX2/${ext}%')`
    );
    if (staticRows.length) {
      assigned.push(qExt);
      continue;
    }
    try {
      const result = await execCmd("asterisk", ["-rx", `database show QPENALTY/${qExt}/agents/${ext}`]);
      const dbOut = `${result.stdout}
${result.stderr}`;
      if (!dbOut.includes("0 results found") && !dbOut.includes("not found") && dbOut.includes(ext)) {
        assigned.push(qExt);
      }
    } catch {
    }
  }
  return assigned;
}
async function getAgentId(ext) {
  const rows = await mysqlQuery(
    `SELECT id FROM agent WHERE number='${ext}' AND estatus='A' LIMIT 1`,
    "call_center"
  );
  if (!rows.length) return null;
  return parseInt(rows[0].trim()) || null;
}
const MEMBER_INTERFACES = (ext) => [
  `Local/${ext}@from-queue/n`,
  `SIP/${ext}`,
  `PJSIP/${ext}`,
  `IAX2/${ext}`
];
async function pauseInAllQueues(ext, reason) {
  const assigned = await getAssignedQueues(ext);
  let count = 0;
  const esc = (s) => (s || "").replace(/'/g, "\\'");
  for (const q of assigned) {
    for (const iface of MEMBER_INTERFACES(ext)) {
      try {
        await execCmd("asterisk", ["-rx", `queue pause member ${iface} queue ${q} reason "${esc(reason)}"`]);
        count++;
      } catch {
      }
    }
  }
  return count;
}
async function unpauseInAllQueues(ext) {
  const assigned = await getAssignedQueues(ext);
  let count = 0;
  for (const q of assigned) {
    for (const iface of MEMBER_INTERFACES(ext)) {
      try {
        await execCmd("asterisk", ["-rx", `queue unpause member ${iface} queue ${q}`]);
        count++;
      } catch {
      }
    }
  }
  return count;
}
const action_post = defineEventHandler(async (event) => {
  var _a, _b;
  requireAuth(event);
  const body = await readBody(event);
  const { action, extension, queue, reason, breakId } = body;
  if (!extension) throw createError({ statusCode: 400, statusMessage: "Extension required" });
  switch (action) {
    case "login":
    case "login-all": {
      const count = await unpauseInAllQueues(extension);
      return { ok: true, message: `Available in ${count} queue interface(s)` };
    }
    case "logout-all": {
      const count = await pauseInAllQueues(extension, "Logged out");
      return { ok: true, message: `Paused in ${count} queue interface(s)` };
    }
    case "pause": {
      const pauseReason = reason || "Break";
      await pauseInAllQueues(extension, pauseReason);
      const agentId = await getAgentId(extension);
      if (agentId) {
        const idBreak = breakId ? parseInt(breakId) : null;
        if (idBreak) {
          await mysqlExec(
            `INSERT INTO audit (id_agent, id_break, datetime_init) VALUES (${agentId}, ${idBreak}, NOW())`,
            "call_center"
          );
        }
      }
      return { ok: true, message: `Paused: ${pauseReason}` };
    }
    case "unpause": {
      await unpauseInAllQueues(extension);
      const agentId = await getAgentId(extension);
      if (agentId) {
        await mysqlExec(
          `UPDATE audit SET datetime_end=NOW(), duration=TIMEDIFF(NOW(), datetime_init)
           WHERE id_agent=${agentId} AND id_break IS NOT NULL AND datetime_end IS NULL
           ORDER BY datetime_init DESC LIMIT 1`,
          "call_center"
        );
      }
      return { ok: true, message: "Unpaused" };
    }
    case "hangup": {
      const chanOut = await runAsterisk("core show channels concise");
      if (chanOut) {
        for (const line of chanOut.split("\n")) {
          const parts = line.split("!");
          if ((((_a = parts[0]) == null ? void 0 : _a.includes(`/${extension}`)) || ((_b = parts[0]) == null ? void 0 : _b.includes(`Local/${extension}@`))) && parts.length > 6 && parts[6] === "Up") {
            await runAsterisk(`channel request hangup ${parts[0]}`);
            return { ok: true, message: "Call hung up" };
          }
        }
      }
      return { ok: true, message: "No active call found" };
    }
    default:
      throw createError({ statusCode: 400, statusMessage: `Unknown action: ${action}` });
  }
});

export { action_post as default };
//# sourceMappingURL=action.post.mjs.map
