import { d as defineEventHandler, r as requireAuth, c as createError, a as readBody, D as mysqlExec } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const ccAgents_post = defineEventHandler(async (event) => {
  const session = requireAuth(event);
  if (session.groupId !== 1) throw createError({ statusCode: 403, statusMessage: "Admin only" });
  const body = await readBody(event);
  const { type, number, name, password, status, eccpPassword } = body;
  if (!number) throw createError({ statusCode: 400, statusMessage: "Agent number is required" });
  if (!name) throw createError({ statusCode: 400, statusMessage: "Agent name is required" });
  const esc = (s) => (s || "").replace(/'/g, "\\'");
  const result = await mysqlExec(
    `INSERT INTO agent (type, number, name, password, estatus, eccp_password) VALUES ('${esc(type || "SIP")}','${esc(number)}','${esc(name)}','${esc(password || "")}','${status === "I" ? "I" : "A"}','${esc(eccpPassword || "")}')`,
    "call_center"
  );
  if (!result.ok) throw createError({ statusCode: 500, statusMessage: result.error });
  return { ok: true };
});

export { ccAgents_post as default };
//# sourceMappingURL=cc-agents.post.mjs.map
