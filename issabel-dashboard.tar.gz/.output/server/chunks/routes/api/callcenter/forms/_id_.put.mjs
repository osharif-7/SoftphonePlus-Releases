import { d as defineEventHandler, r as requireAuth, c as createError, g as getRouterParam, a as readBody, D as mysqlExec } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _id__put = defineEventHandler(async (event) => {
  const session = requireAuth(event);
  if (session.groupId !== 1) throw createError({ statusCode: 403, statusMessage: "Admin only" });
  const id = getRouterParam(event, "id");
  const body = await readBody(event);
  const { name, description, status, fields } = body;
  if (!name) throw createError({ statusCode: 400, statusMessage: "Form name is required" });
  const esc = (s) => (s || "").replace(/'/g, "\\'");
  await mysqlExec(
    `UPDATE form SET nombre='${esc(name)}', descripcion='${esc(description || "")}', estatus='${status === "I" ? "I" : "A"}' WHERE id=${id}`,
    "call_center"
  );
  if (Array.isArray(fields)) {
    await mysqlExec(`DELETE FROM form_field WHERE id_form=${id}`, "call_center");
    for (let i = 0; i < fields.length; i++) {
      const f = fields[i];
      await mysqlExec(
        `INSERT INTO form_field (id_form, etiqueta, value, tipo, orden) VALUES (${id},'${esc(f.label || "")}','${esc(f.value || "")}','${esc(f.type || "TEXT")}',${i + 1})`,
        "call_center"
      );
    }
  }
  return { ok: true };
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
