import { d as defineEventHandler, r as requireAuth, g as getRouterParam, F as mysqlQuery, c as createError } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _id__get = defineEventHandler(async (event) => {
  requireAuth(event);
  const id = getRouterParam(event, "id");
  const rows = await mysqlQuery(
    `SELECT id, nombre, descripcion, estatus FROM form WHERE id=${id}`,
    "call_center"
  );
  if (!rows.length) throw createError({ statusCode: 404, statusMessage: "Form not found" });
  const [fid, nombre, descripcion, estatus] = rows[0].split("	");
  const fieldRows = await mysqlQuery(
    `SELECT id, etiqueta, value, tipo, orden FROM form_field WHERE id_form=${id} ORDER BY orden`,
    "call_center"
  );
  const fields = fieldRows.map((r) => {
    const parts = r.split("	");
    return {
      id: parseInt(parts[0]),
      label: parts[1] || "",
      value: parts[2] || "",
      type: parts[3] || "TEXT",
      order: parseInt(parts[4]) || 0
    };
  });
  return {
    id: parseInt(fid),
    name: nombre,
    description: descripcion,
    statusCode: estatus,
    fields
  };
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
