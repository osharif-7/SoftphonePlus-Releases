import { d as defineEventHandler, r as requireAuth, c as createError, a as readBody, F as mysqlQuery, D as mysqlExec } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const queues_post = defineEventHandler(async (event) => {
  const session = requireAuth(event);
  if (session.groupId !== 1) throw createError({ statusCode: 403, statusMessage: "Admin only" });
  const body = await readBody(event);
  const { queue, script } = body;
  if (!queue) throw createError({ statusCode: 400, statusMessage: "Queue is required" });
  const esc = (s) => (s || "").replace(/'/g, "\\'");
  const campCheck = await mysqlQuery(
    `SELECT id FROM campaign WHERE queue='${esc(queue)}' AND estatus='A'`,
    "call_center"
  );
  if (campCheck.length) {
    throw createError({ statusCode: 400, statusMessage: "This queue is already used by an active outbound campaign" });
  }
  const existing = await mysqlQuery(
    `SELECT id, estatus FROM queue_call_entry WHERE queue='${esc(queue)}'`,
    "call_center"
  );
  if (existing.length) {
    const existId = existing[0].split("	")[0];
    await mysqlExec(
      `UPDATE queue_call_entry SET estatus='A', script='${esc(script || "")}' WHERE id=${existId}`,
      "call_center"
    );
    return { ok: true, id: parseInt(existId) };
  }
  const result = await mysqlExec(
    `INSERT INTO queue_call_entry (queue, estatus, script) VALUES ('${esc(queue)}','A','${esc(script || "")}')`,
    "call_center"
  );
  if (!result.ok) throw createError({ statusCode: 500, statusMessage: result.error });
  const idRows = await mysqlQuery("SELECT LAST_INSERT_ID()", "call_center");
  return { ok: true, id: parseInt(idRows[0]) || 0 };
});

export { queues_post as default };
//# sourceMappingURL=queues.post.mjs.map
