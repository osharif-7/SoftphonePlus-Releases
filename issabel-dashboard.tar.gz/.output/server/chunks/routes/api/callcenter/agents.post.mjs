import { d as defineEventHandler, a as readBody, c as createError, C as runAsterisk, F as mysqlQuery } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

async function getAssignedQueues(extension) {
  const staticRows = await mysqlQuery(
    `SELECT DISTINCT id FROM queues_details WHERE keyword='member' AND data LIKE '%${extension}@%'`
  );
  const allQueues = await mysqlQuery("SELECT extension FROM queues_config ORDER BY extension");
  const dynQueues = [];
  for (const row of allQueues) {
    const qExt = row.trim();
    try {
      const dbOut = await runAsterisk(`database get QPENALTY ${qExt}/agents/${extension}`);
      if (dbOut && dbOut.includes("Value:")) {
        dynQueues.push(qExt);
      }
    } catch {
    }
  }
  const all = /* @__PURE__ */ new Set([...staticRows.map((r) => r.trim()), ...dynQueues]);
  if (all.size === 0) {
    return allQueues.map((r) => r.trim());
  }
  return Array.from(all);
}
const agents_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const { action, extension, queue, penalty } = body;
  if (!action || !extension) {
    throw createError({ statusCode: 400, statusMessage: "action and extension required" });
  }
  switch (action) {
    case "login": {
      if (!queue) throw createError({ statusCode: 400, statusMessage: "queue required for login" });
      const pen = Number(penalty != null ? penalty : 0);
      await runAsterisk(`queue add member Local/${extension}@from-queue/n to ${queue} penalty ${pen}`);
      return { ok: true, message: `Agent ${extension} logged into ${queue}` };
    }
    case "login-all": {
      const queues = await getAssignedQueues(extension);
      if (!queues.length) throw createError({ statusCode: 400, statusMessage: "No queues assigned to this extension" });
      const pen = Number(penalty != null ? penalty : 0);
      const results = [];
      for (const q of queues) {
        await runAsterisk(`queue add member Local/${extension}@from-queue/n to ${q} penalty ${pen}`);
        results.push(q);
      }
      return { ok: true, message: `Agent ${extension} logged into ${results.length} queue(s): ${results.join(", ")}`, queues: results };
    }
    case "logout": {
      if (!queue) throw createError({ statusCode: 400, statusMessage: "queue required for logout" });
      await runAsterisk(`queue remove member Local/${extension}@from-queue/n from ${queue}`);
      return { ok: true, message: `Agent ${extension} logged out of ${queue}` };
    }
    case "logout-all": {
      const queueOut = await runAsterisk("queue show");
      const loggedQueues = [];
      if (queueOut) {
        const qBlocks = queueOut.split(/\n(?=\S+\s+has\s+\d+\s+calls?)/);
        for (const block of qBlocks) {
          const headerMatch = block.match(/^(\S+)\s+has/);
          if (!headerMatch) continue;
          const qName = headerMatch[1];
          if (block.includes(`Local/${extension}@from-queue`) || block.includes(`SIP/${extension}`) || block.includes(`PJSIP/${extension}`)) {
            loggedQueues.push(qName);
          }
        }
      }
      for (const q of loggedQueues) {
        await runAsterisk(`queue remove member Local/${extension}@from-queue/n from ${q}`);
      }
      return { ok: true, message: `Agent ${extension} logged out of ${loggedQueues.length} queue(s)`, queues: loggedQueues };
    }
    case "pause": {
      const reason = body.reason || "Admin Pause";
      if (queue) {
        await runAsterisk(`queue pause member Local/${extension}@from-queue/n queue ${queue} reason "${reason}"`);
      } else {
        await runAsterisk(`queue pause member Local/${extension}@from-queue/n reason "${reason}"`);
      }
      return { ok: true, message: `Agent ${extension} paused` };
    }
    case "unpause": {
      if (queue) {
        await runAsterisk(`queue unpause member Local/${extension}@from-queue/n queue ${queue}`);
      } else {
        await runAsterisk(`queue unpause member Local/${extension}@from-queue/n`);
      }
      return { ok: true, message: `Agent ${extension} unpaused` };
    }
    default:
      throw createError({ statusCode: 400, statusMessage: `Unknown action: ${action}` });
  }
});

export { agents_post as default };
//# sourceMappingURL=agents.post.mjs.map
