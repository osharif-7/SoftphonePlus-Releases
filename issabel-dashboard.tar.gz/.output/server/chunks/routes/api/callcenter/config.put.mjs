import { d as defineEventHandler, r as requireAuth, c as createError, a as readBody, D as mysqlExec } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const config_put = defineEventHandler(async (event) => {
  const session = requireAuth(event);
  if (session.groupId !== 1) throw createError({ statusCode: 403, statusMessage: "Admin only" });
  const body = await readBody(event);
  const { config } = body;
  if (!config || typeof config !== "object") {
    throw createError({ statusCode: 400, statusMessage: "Config object is required" });
  }
  const esc = (s) => (s || "").replace(/'/g, "\\'");
  if (config["dialer.qos"] !== void 0) {
    const qos = parseFloat(config["dialer.qos"]);
    if (qos >= 1) config["dialer.qos"] = String(qos / 100);
  }
  const booleanKeys = ["dialer.debug", "dialer.allevents"];
  for (const [key, value] of Object.entries(config)) {
    await mysqlExec(
      `DELETE FROM valor_config WHERE config_key='${esc(key)}'`,
      "call_center"
    );
    if (booleanKeys.includes(key)) {
      if (value && value !== "0" && value !== "off") {
        await mysqlExec(
          `INSERT INTO valor_config (config_key, config_value) VALUES ('${esc(key)}', '1')`,
          "call_center"
        );
      }
    } else {
      await mysqlExec(
        `INSERT INTO valor_config (config_key, config_value) VALUES ('${esc(key)}', '${esc(value)}')`,
        "call_center"
      );
    }
  }
  return { ok: true };
});

export { config_put as default };
//# sourceMappingURL=config.put.mjs.map
