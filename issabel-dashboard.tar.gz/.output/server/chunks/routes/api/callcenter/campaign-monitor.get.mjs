import { d as defineEventHandler, r as requireAuth, F as mysqlQuery, C as runAsterisk, L as eccpIsAvailable } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const campaignMonitor_get = defineEventHandler(async (event) => {
  requireAuth(event);
  const outCampaigns = await mysqlQuery(
    `SELECT c.id, c.name, c.queue, c.max_canales, c.estatus,
            (SELECT COUNT(*) FROM calls WHERE id_campaign=c.id AND status IS NULL) AS pending,
            (SELECT COUNT(*) FROM calls WHERE id_campaign=c.id AND status='Success' AND DATE(start_time)=CURDATE()) AS success_today,
            (SELECT COUNT(*) FROM calls WHERE id_campaign=c.id AND status='Failure' AND DATE(start_time)=CURDATE()) AS fail_today,
            (SELECT COUNT(*) FROM calls WHERE id_campaign=c.id AND DATE(start_time)=CURDATE()) AS total_today
     FROM campaign c WHERE c.estatus='A' ORDER BY c.id`,
    "call_center"
  );
  const outbound = outCampaigns.map((r) => {
    const p = r.split("	");
    return {
      id: parseInt(p[0]),
      name: p[1],
      queue: p[2],
      maxChannels: parseInt(p[3]) || 0,
      status: "Active",
      pending: parseInt(p[4]) || 0,
      successToday: parseInt(p[5]) || 0,
      failToday: parseInt(p[6]) || 0,
      totalToday: parseInt(p[7]) || 0
    };
  });
  const inCampaigns = await mysqlQuery(
    `SELECT ce.id, ce.name, qce.queue, ce.estatus,
            (SELECT COUNT(*) FROM call_entry WHERE id_campaign=ce.id AND DATE(datetime_init)=CURDATE()) AS total_today,
            (SELECT COUNT(*) FROM call_entry WHERE id_campaign=ce.id AND status='terminada' AND DATE(datetime_init)=CURDATE()) AS answered_today,
            (SELECT COUNT(*) FROM call_entry WHERE id_campaign=ce.id AND status='abandonada' AND DATE(datetime_init)=CURDATE()) AS abandoned_today
     FROM campaign_entry ce
     LEFT JOIN queue_call_entry qce ON qce.id=ce.id_queue_call_entry
     WHERE ce.estatus='A' ORDER BY ce.id`,
    "call_center"
  );
  const inbound = inCampaigns.map((r) => {
    const p = r.split("	");
    return {
      id: parseInt(p[0]),
      name: p[1],
      queue: p[2] || "",
      status: "Active",
      totalToday: parseInt(p[3]) || 0,
      answeredToday: parseInt(p[4]) || 0,
      abandonedToday: parseInt(p[5]) || 0
    };
  });
  const activeCalls = await mysqlQuery(
    `SELECT 'outbound' AS dir, cc.agentnum, cc.queue, cc.Channel, cc.ChannelClient
     FROM current_calls cc
     UNION ALL
     SELECT 'inbound', cce.id_agent, qce.queue, cce.ChannelClient, cce.callerid
     FROM current_call_entry cce
     LEFT JOIN queue_call_entry qce ON qce.id=cce.id_queue_call_entry`,
    "call_center"
  );
  const calls = activeCalls.map((r) => {
    const p = r.split("	");
    return { direction: p[0], agent: p[1], queue: p[2], channel: p[3], client: p[4] };
  });
  const queueOut = await runAsterisk("queue show");
  const agentMap = /* @__PURE__ */ new Map();
  if (queueOut) {
    const blocks = queueOut.split(/\n(?=\S+\s+has\s+\d+\s+calls?)/);
    for (const block of blocks) {
      const hm = block.match(/^(\S+)\s+has/);
      if (!hm) continue;
      const qName = hm[1];
      const memberLines = block.match(/^\s+(SIP|Local|PJSIP|IAX2)\/\S+.*/gm);
      if (!memberLines) continue;
      for (const ml of memberLines) {
        const em = ml.match(/Local\/(\d+)@|(?:SIP|PJSIP|IAX2)\/(\d+)/i);
        if (!em) continue;
        const ext = em[1] || em[2];
        if (!agentMap.has(ext)) agentMap.set(ext, { queues: [], paused: false, status: "idle" });
        const a = agentMap.get(ext);
        a.queues.push(qName);
        if (ml.includes("(paused)")) a.paused = true;
        if (ml.toLowerCase().includes("in use") || ml.toLowerCase().includes("busy")) a.status = "on-call";
        else if (ml.includes("(paused)")) a.status = "paused";
        else a.status = "available";
      }
    }
  }
  const agents = Array.from(agentMap.entries()).map(([ext, info]) => ({
    extension: ext,
    ...info
  }));
  let eccpAvailable = false;
  try {
    eccpAvailable = await eccpIsAvailable();
  } catch {
  }
  return { outbound, inbound, activeCalls: calls, agents, eccpAvailable };
});

export { campaignMonitor_get as default };
//# sourceMappingURL=campaign-monitor.get.mjs.map
