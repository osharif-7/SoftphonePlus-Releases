import { d as defineEventHandler, r as requireAuth, c as createError, a as readBody, E as execCmd, M as isDialerRunning } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const dialerService_post = defineEventHandler(async (event) => {
  const session = requireAuth(event);
  if (session.groupId !== 1) throw createError({ statusCode: 403, statusMessage: "Admin only" });
  const body = await readBody(event);
  const { action } = body;
  if (!["start", "stop", "restart"].includes(action)) {
    throw createError({ statusCode: 400, statusMessage: "Action must be start, stop, or restart" });
  }
  const result = await execCmd("service", ["issabeldialer", action]);
  if (result.code !== 0 && !result.stdout.includes("OK")) {
    throw createError({ statusCode: 500, statusMessage: result.stderr || "Service command failed" });
  }
  await new Promise((r) => setTimeout(r, 1e3));
  const status = await isDialerRunning();
  return { ok: true, dialer: status };
});

export { dialerService_post as default };
//# sourceMappingURL=dialer-service.post.mjs.map
