import { d as defineEventHandler, r as requireAuth, c as createError, a as readBody, D as mysqlExec } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const dnc_post = defineEventHandler(async (event) => {
  const session = requireAuth(event);
  if (session.groupId !== 1) throw createError({ statusCode: 403, statusMessage: "Admin only" });
  const body = await readBody(event);
  const { callerIds } = body;
  if (!callerIds) throw createError({ statusCode: 400, statusMessage: "Caller ID(s) required" });
  const esc = (s) => (s || "").replace(/'/g, "\\'");
  const numbers = callerIds.split(/[\n,;]+/).map((s) => s.trim()).filter(Boolean);
  let added = 0;
  for (const num of numbers) {
    const result = await mysqlExec(
      `INSERT IGNORE INTO dont_call (caller_id, date_income, status) VALUES ('${esc(num)}', NOW(), 'A')`,
      "call_center"
    );
    if (result.ok) added++;
  }
  return { ok: true, added, total: numbers.length };
});

export { dnc_post as default };
//# sourceMappingURL=dnc.post.mjs.map
