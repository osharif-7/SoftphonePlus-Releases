import { d as defineEventHandler, r as requireAuth, J as getQuery, F as mysqlQuery } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const dnc_get = defineEventHandler(async (event) => {
  requireAuth(event);
  const query = getQuery(event);
  const page = parseInt(String(query.page)) || 1;
  const limit = parseInt(String(query.limit)) || 50;
  const search = String(query.search || "").trim();
  const offset = (page - 1) * limit;
  let whereClause = "";
  if (search) {
    const esc = search.replace(/'/g, "\\'");
    whereClause = `WHERE caller_id LIKE '%${esc}%'`;
  }
  const countRows = await mysqlQuery(
    `SELECT COUNT(*) FROM dont_call ${whereClause}`,
    "call_center"
  );
  const total = parseInt(countRows[0]) || 0;
  const rows = await mysqlQuery(
    `SELECT id, caller_id, date_income, status FROM dont_call ${whereClause} ORDER BY id DESC LIMIT ${limit} OFFSET ${offset}`,
    "call_center"
  );
  const items = rows.map((r) => {
    const parts = r.split("	");
    return {
      id: parseInt(parts[0]),
      callerId: parts[1] || "",
      dateAdded: parts[2] || "",
      status: parts[3] === "A" ? "Active" : "Inactive",
      statusCode: parts[3] || "A"
    };
  });
  return { items, total, page, limit };
});

export { dnc_get as default };
//# sourceMappingURL=dnc.get.mjs.map
