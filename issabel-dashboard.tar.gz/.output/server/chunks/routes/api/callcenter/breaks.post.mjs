import { d as defineEventHandler, r as requireAuth, c as createError, a as readBody, D as mysqlExec } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const breaks_post = defineEventHandler(async (event) => {
  const session = requireAuth(event);
  if (session.groupId !== 1) throw createError({ statusCode: 403, statusMessage: "Admin only" });
  const body = await readBody(event);
  const { name, description, tipo, status } = body;
  if (!name) throw createError({ statusCode: 400, statusMessage: "Name is required" });
  const esc = (s) => (s || "").replace(/'/g, "\\'");
  const result = await mysqlExec(
    `INSERT INTO break (name, description, tipo, status) VALUES ('${esc(name)}','${esc(description || "")}','${tipo === "H" ? "H" : "B"}','${status === "I" ? "I" : "A"}')`,
    "call_center"
  );
  if (!result.ok) throw createError({ statusCode: 500, statusMessage: result.error });
  return { ok: true };
});

export { breaks_post as default };
//# sourceMappingURL=breaks.post.mjs.map
