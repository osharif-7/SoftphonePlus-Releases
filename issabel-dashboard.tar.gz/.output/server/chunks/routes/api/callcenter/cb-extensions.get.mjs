import { d as defineEventHandler, r as requireAuth, F as mysqlQuery, C as runAsterisk } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const cbExtensions_get = defineEventHandler(async (event) => {
  requireAuth(event);
  const rows = await mysqlQuery(
    "SELECT id, type, number, name, password, estatus, eccp_password FROM agent WHERE type<>'Agent' ORDER BY number",
    "call_center"
  );
  const queueOut = await runAsterisk("queue show");
  const onlineAgents = /* @__PURE__ */ new Set();
  if (queueOut) {
    const memberLines = queueOut.match(/^\s+(SIP|PJSIP|IAX2)\/(\d+).*/gm);
    if (memberLines) {
      for (const ml of memberLines) {
        const m = ml.match(/(SIP|PJSIP|IAX2)\/(\d+)/i);
        if (m) onlineAgents.add(`${m[1]}/${m[2]}`);
      }
    }
  }
  const agents = rows.map((r) => {
    const parts = r.split("	");
    const type = parts[1] || "SIP";
    const number = parts[2] || "";
    const channel = `${type}/${number}`;
    return {
      id: parseInt(parts[0]),
      type,
      number,
      name: parts[3] || "",
      password: parts[4] || "",
      status: parts[5] === "A" ? "Active" : "Inactive",
      statusCode: parts[5] || "A",
      eccpPassword: parts[6] || "",
      channel,
      online: onlineAgents.has(channel)
    };
  });
  return agents;
});

export { cbExtensions_get as default };
//# sourceMappingURL=cb-extensions.get.mjs.map
