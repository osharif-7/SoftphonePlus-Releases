import { d as defineEventHandler, r as requireAuth, F as mysqlQuery } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const breaks_get = defineEventHandler(async (event) => {
  requireAuth(event);
  const rows = await mysqlQuery(
    "SELECT id, name, description, tipo, status FROM break ORDER BY id",
    "call_center"
  );
  return rows.map((r) => {
    const [id, name, description, tipo, status] = r.split("	");
    return {
      id: parseInt(id),
      name: name || "",
      description: description || "",
      type: tipo === "H" ? "Hold" : "Break",
      tipo,
      status: status === "A" ? "Active" : "Inactive",
      statusCode: status
    };
  });
});

export { breaks_get as default };
//# sourceMappingURL=breaks.get.mjs.map
