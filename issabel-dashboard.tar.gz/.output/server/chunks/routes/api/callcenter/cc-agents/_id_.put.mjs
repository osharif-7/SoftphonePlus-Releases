import { d as defineEventHandler, r as requireAuth, c as createError, g as getRouterParam, a as readBody, D as mysqlExec } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _id__put = defineEventHandler(async (event) => {
  const session = requireAuth(event);
  if (session.groupId !== 1) throw createError({ statusCode: 403, statusMessage: "Admin only" });
  const id = getRouterParam(event, "id");
  const body = await readBody(event);
  const { type, number, name, password, status, eccpPassword } = body;
  if (!number) throw createError({ statusCode: 400, statusMessage: "Agent number is required" });
  if (!name) throw createError({ statusCode: 400, statusMessage: "Agent name is required" });
  const esc = (s) => (s || "").replace(/'/g, "\\'");
  const result = await mysqlExec(
    `UPDATE agent SET type='${esc(type || "SIP")}', number='${esc(number)}', name='${esc(name)}', password='${esc(password || "")}', estatus='${status === "I" ? "I" : "A"}', eccp_password='${esc(eccpPassword || "")}' WHERE id=${id}`,
    "call_center"
  );
  if (!result.ok) throw createError({ statusCode: 500, statusMessage: result.error });
  return { ok: true };
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
