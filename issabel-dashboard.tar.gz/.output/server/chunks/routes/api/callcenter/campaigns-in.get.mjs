import { d as defineEventHandler, r as requireAuth, F as mysqlQuery } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const campaignsIn_get = defineEventHandler(async (event) => {
  requireAuth(event);
  const rows = await mysqlQuery(
    `SELECT ce.id, ce.name, ce.datetime_init, ce.datetime_end, ce.daytime_init, ce.daytime_end,
            ce.estatus, ce.script, qce.queue,
            (SELECT COUNT(*) FROM call_entry WHERE id_campaign=ce.id) AS total_calls
     FROM campaign_entry ce
     LEFT JOIN queue_call_entry qce ON qce.id=ce.id_queue_call_entry
     ORDER BY ce.id DESC`,
    "call_center"
  );
  return rows.map((r) => {
    const p = r.split("	");
    return {
      id: parseInt(p[0]),
      name: p[1] || "",
      dateStart: p[2] || "",
      dateEnd: p[3] || "",
      timeStart: p[4] || "",
      timeEnd: p[5] || "",
      status: p[6] === "A" ? "Active" : "Inactive",
      statusCode: p[6] || "A",
      script: p[7] || "",
      queue: p[8] || "",
      totalCalls: parseInt(p[9]) || 0
    };
  });
});

export { campaignsIn_get as default };
//# sourceMappingURL=campaigns-in.get.mjs.map
