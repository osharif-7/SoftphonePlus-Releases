import { d as defineEventHandler, r as requireAuth, F as mysqlQuery } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const queues_get = defineEventHandler(async (event) => {
  requireAuth(event);
  const rows = await mysqlQuery(
    "SELECT id, queue, estatus, script FROM queue_call_entry ORDER BY queue",
    "call_center"
  );
  return rows.map((r) => {
    const parts = r.split("	");
    return {
      id: parseInt(parts[0]),
      queue: parts[1] || "",
      status: parts[2] === "A" ? "Active" : "Inactive",
      statusCode: parts[2] || "A",
      script: parts[3] || ""
    };
  });
});

export { queues_get as default };
//# sourceMappingURL=queues.get.mjs.map
