import { d as defineEventHandler, r as requireAuth, F as mysqlQuery } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const forms_get = defineEventHandler(async (event) => {
  requireAuth(event);
  const rows = await mysqlQuery(
    "SELECT id, nombre, descripcion, estatus FROM form ORDER BY id",
    "call_center"
  );
  const forms = rows.map((r) => {
    const [id, nombre, descripcion, estatus] = r.split("	");
    return {
      id: parseInt(id),
      name: nombre || "",
      description: descripcion || "",
      status: estatus === "A" ? "Active" : "Inactive",
      statusCode: estatus || "A"
    };
  });
  for (const form of forms) {
    const countRows = await mysqlQuery(
      `SELECT COUNT(*) FROM form_field WHERE id_form=${form.id}`,
      "call_center"
    );
    form.fieldCount = parseInt(countRows[0]) || 0;
  }
  return forms;
});

export { forms_get as default };
//# sourceMappingURL=forms.get.mjs.map
