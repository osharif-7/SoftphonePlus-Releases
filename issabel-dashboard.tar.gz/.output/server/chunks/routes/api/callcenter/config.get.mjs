import { d as defineEventHandler, r as requireAuth, F as mysqlQuery, M as isDialerRunning } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const DEFAULTS = {
  "asterisk.asthost": "127.0.0.1",
  "asterisk.astuser": "",
  "asterisk.astpass": "",
  "asterisk.duracion_sesion": "0",
  "dialer.llamada_corta": "10",
  "dialer.tiempo_contestar": "8",
  "dialer.debug": "0",
  "dialer.allevents": "0",
  "dialer.overcommit": "0",
  "dialer.qos": "0.97",
  "dialer.predictivo": "1",
  "dialer.timeout_originate": "0",
  "dialer.timeout_inactivity": "15",
  "dialer.forzar_sobrecolocar": "0"
};
const config_get = defineEventHandler(async (event) => {
  requireAuth(event);
  const rows = await mysqlQuery(
    "SELECT config_key, config_value FROM valor_config",
    "call_center"
  );
  const config = { ...DEFAULTS };
  for (const r of rows) {
    const [key, ...rest] = r.split("	");
    if (key) config[key] = rest.join("	");
  }
  if (config["dialer.qos"]) {
    const qosNum = parseFloat(config["dialer.qos"]);
    if (qosNum <= 1) config["dialer.qos"] = String(Math.round(qosNum * 100));
  }
  const dialerStatus = await isDialerRunning();
  return { config, dialer: dialerStatus };
});

export { config_get as default };
//# sourceMappingURL=config.get.mjs.map
