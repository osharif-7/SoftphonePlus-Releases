import { d as defineEventHandler, r as requireAuth, c as createError, g as getRouterParam, F as mysqlQuery, D as mysqlExec } from '../../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const toggleStatus_post = defineEventHandler(async (event) => {
  const session = requireAuth(event);
  if (session.groupId !== 1) throw createError({ statusCode: 403, statusMessage: "Admin only" });
  const id = getRouterParam(event, "id");
  const rows = await mysqlQuery(
    `SELECT estatus FROM queue_call_entry WHERE id=${id}`,
    "call_center"
  );
  if (!rows.length) throw createError({ statusCode: 404, statusMessage: "Queue not found" });
  const currentStatus = rows[0].trim();
  const newStatus = currentStatus === "A" ? "I" : "A";
  const result = await mysqlExec(
    `UPDATE queue_call_entry SET estatus='${newStatus}' WHERE id=${id}`,
    "call_center"
  );
  if (!result.ok) throw createError({ statusCode: 500, statusMessage: result.error });
  return { ok: true, newStatus: newStatus === "A" ? "Active" : "Inactive" };
});

export { toggleStatus_post as default };
//# sourceMappingURL=toggle-status.post.mjs.map
