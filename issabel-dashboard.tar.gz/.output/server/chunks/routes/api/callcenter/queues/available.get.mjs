import { d as defineEventHandler, r as requireAuth, F as mysqlQuery } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const available_get = defineEventHandler(async (event) => {
  requireAuth(event);
  const asteriskQueues = await mysqlQuery(
    "SELECT extension, descr FROM queues_config ORDER BY extension"
  );
  const registeredRows = await mysqlQuery(
    "SELECT queue FROM queue_call_entry WHERE estatus='A'",
    "call_center"
  );
  const registeredSet = new Set(registeredRows.map((r) => r.trim()));
  const outboundRows = await mysqlQuery(
    "SELECT queue FROM campaign WHERE estatus='A'",
    "call_center"
  );
  const outboundSet = new Set(outboundRows.map((r) => r.trim()));
  const available = asteriskQueues.map((r) => {
    const [ext, descr] = r.split("	");
    return { extension: ext, description: descr || ext };
  }).filter((q) => !registeredSet.has(q.extension) && !outboundSet.has(q.extension));
  return available;
});

export { available_get as default };
//# sourceMappingURL=available.get.mjs.map
