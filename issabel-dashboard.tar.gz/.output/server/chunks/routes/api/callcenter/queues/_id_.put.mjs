import { d as defineEventHandler, r as requireAuth, c as createError, g as getRouterParam, a as readBody, D as mysqlExec } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _id__put = defineEventHandler(async (event) => {
  const session = requireAuth(event);
  if (session.groupId !== 1) throw createError({ statusCode: 403, statusMessage: "Admin only" });
  const id = getRouterParam(event, "id");
  const body = await readBody(event);
  const { script, status } = body;
  const esc = (s) => (s || "").replace(/'/g, "\\'");
  let sql = `UPDATE queue_call_entry SET script='${esc(script || "")}'`;
  if (status) sql += `, estatus='${status === "I" ? "I" : "A"}'`;
  sql += ` WHERE id=${id}`;
  const result = await mysqlExec(sql, "call_center");
  if (!result.ok) throw createError({ statusCode: 500, statusMessage: result.error });
  return { ok: true };
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
