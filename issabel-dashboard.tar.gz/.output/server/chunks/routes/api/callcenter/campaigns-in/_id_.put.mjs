import { d as defineEventHandler, r as requireAuth, c as createError, g as getRouterParam, a as readBody, F as mysqlQuery, D as mysqlExec } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _id__put = defineEventHandler(async (event) => {
  const session = requireAuth(event);
  if (session.groupId !== 1) throw createError({ statusCode: 403, statusMessage: "Admin only" });
  const id = getRouterParam(event, "id");
  const body = await readBody(event);
  const { name, queue, dateStart, dateEnd, timeStart, timeEnd, script, status } = body;
  if (!name) throw createError({ statusCode: 400, statusMessage: "Campaign name is required" });
  const esc = (s) => (s || "").replace(/'/g, "\\'");
  const ceRows = await mysqlQuery(
    `SELECT id_queue_call_entry FROM campaign_entry WHERE id=${id}`,
    "call_center"
  );
  const qceId = ceRows.length ? parseInt(ceRows[0]) : 0;
  if (qceId) {
    await mysqlExec(
      `UPDATE queue_call_entry SET queue='${esc(queue || "")}', date_init='${dateStart}', time_init='${timeStart}',
       date_end='${dateEnd}', time_end='${timeEnd}', estatus='${status === "I" ? "I" : "A"}', script='${esc(script || "")}'
       WHERE id=${qceId}`,
      "call_center"
    );
  }
  const result = await mysqlExec(
    `UPDATE campaign_entry SET name='${esc(name)}', datetime_init='${dateStart}', datetime_end='${dateEnd}',
     daytime_init='${timeStart}', daytime_end='${timeEnd}', estatus='${status === "I" ? "I" : "A"}', script='${esc(script || "")}'
     WHERE id=${id}`,
    "call_center"
  );
  if (!result.ok) throw createError({ statusCode: 500, statusMessage: result.error });
  return { ok: true };
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
