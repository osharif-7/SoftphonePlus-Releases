import { d as defineEventHandler, r as requireAuth, c as createError, g as getRouterParam, F as mysqlQuery, D as mysqlExec } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _id__delete = defineEventHandler(async (event) => {
  const session = requireAuth(event);
  if (session.groupId !== 1) throw createError({ statusCode: 403, statusMessage: "Admin only" });
  const id = getRouterParam(event, "id");
  const ceRows = await mysqlQuery(
    `SELECT id_queue_call_entry FROM campaign_entry WHERE id=${id}`,
    "call_center"
  );
  const qceId = ceRows.length ? parseInt(ceRows[0]) : 0;
  await mysqlExec(`DELETE FROM call_entry WHERE id_campaign=${id}`, "call_center");
  await mysqlExec(`DELETE FROM campaign_entry WHERE id=${id}`, "call_center");
  if (qceId) {
    await mysqlExec(`DELETE FROM queue_call_entry WHERE id=${qceId}`, "call_center");
  }
  return { ok: true };
});

export { _id__delete as default };
//# sourceMappingURL=_id_.delete.mjs.map
