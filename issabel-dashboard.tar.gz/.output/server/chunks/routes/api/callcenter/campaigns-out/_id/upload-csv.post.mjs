import { d as defineEventHandler, r as requireAuth, c as createError, g as getRouterParam, a as readBody, F as mysqlQuery, D as mysqlExec } from '../../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const uploadCsv_post = defineEventHandler(async (event) => {
  const session = requireAuth(event);
  if (session.groupId !== 1) throw createError({ statusCode: 403, statusMessage: "Admin only" });
  const id = getRouterParam(event, "id");
  const body = await readBody(event);
  const { csvData } = body;
  if (!csvData) throw createError({ statusCode: 400, statusMessage: "CSV data is required" });
  const lines = csvData.trim().split("\n").filter(Boolean);
  let inserted = 0;
  let skipped = 0;
  const esc = (s) => (s || "").replace(/'/g, "\\'");
  for (const line of lines) {
    const parts = line.split(",").map((s) => s.trim().replace(/^["']|["']$/g, ""));
    const phone = parts[0];
    if (!phone || !/^\d+$/.test(phone.replace(/[\s\-\+\(\)]/g, ""))) {
      skipped++;
      continue;
    }
    const existing = await mysqlQuery(
      `SELECT id FROM calls WHERE id_campaign=${id} AND phone='${esc(phone)}' AND status IS NULL`,
      "call_center"
    );
    if (existing.length) {
      skipped++;
      continue;
    }
    await mysqlExec(
      `INSERT INTO calls (id_campaign, phone, status, retries, dnc, scheduled) VALUES (${id},'${esc(phone)}',NULL,0,0,0)`,
      "call_center"
    );
    inserted++;
  }
  return { ok: true, inserted, skipped, total: lines.length };
});

export { uploadCsv_post as default };
//# sourceMappingURL=upload-csv.post.mjs.map
