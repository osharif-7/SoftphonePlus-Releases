import { d as defineEventHandler, r as requireAuth, c as createError, g as getRouterParam, a as readBody, D as mysqlExec } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _id__put = defineEventHandler(async (event) => {
  const session = requireAuth(event);
  if (session.groupId !== 1) throw createError({ statusCode: 403, statusMessage: "Admin only" });
  const id = getRouterParam(event, "id");
  const body = await readBody(event);
  const { name, dateStart, dateEnd, timeStart, timeEnd, retries, trunk, context, queue, maxChannels, script, status } = body;
  if (!name) throw createError({ statusCode: 400, statusMessage: "Campaign name is required" });
  const esc = (s) => (s || "").replace(/'/g, "\\'");
  const result = await mysqlExec(
    `UPDATE campaign SET name='${esc(name)}', datetime_init='${dateStart}', datetime_end='${dateEnd}',
     daytime_init='${timeStart}', daytime_end='${timeEnd}', retries=${parseInt(retries) || 1},
     trunk='${esc(trunk || "")}', context='${esc(context || "from-internal")}', queue='${esc(queue)}',
     max_canales=${parseInt(maxChannels) || 0}, script='${esc(script || "")}', estatus='${esc(status || "A")}'
     WHERE id=${id}`,
    "call_center"
  );
  if (!result.ok) throw createError({ statusCode: 500, statusMessage: result.error });
  return { ok: true };
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
