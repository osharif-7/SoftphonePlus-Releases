import { d as defineEventHandler, r as requireAuth, g as getRouterParam, F as mysqlQuery, c as createError } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _id__get = defineEventHandler(async (event) => {
  requireAuth(event);
  const id = getRouterParam(event, "id");
  const rows = await mysqlQuery(
    `SELECT c.id, c.name, c.datetime_init, c.datetime_end, c.daytime_init, c.daytime_end,
            c.retries, c.trunk, c.context, c.queue, c.max_canales, c.script, c.estatus, c.id_url
     FROM campaign c WHERE c.id=${id}`,
    "call_center"
  );
  if (!rows.length) throw createError({ statusCode: 404, statusMessage: "Campaign not found" });
  const p = rows[0].split("	");
  const formRows = await mysqlQuery(
    `SELECT cf.id_form, f.nombre FROM campaign_form cf JOIN form f ON f.id=cf.id_form WHERE cf.id_campaign=${id}`,
    "call_center"
  );
  const forms = formRows.map((r) => {
    const [fid, fname] = r.split("	");
    return { id: parseInt(fid), name: fname };
  });
  const callStats = await mysqlQuery(
    `SELECT status, COUNT(*) FROM calls WHERE id_campaign=${id} GROUP BY status`,
    "call_center"
  );
  const stats = {};
  for (const row of callStats) {
    const [s, c] = row.split("	");
    stats[s || "Unknown"] = parseInt(c) || 0;
  }
  return {
    id: parseInt(p[0]),
    name: p[1],
    dateStart: p[2],
    dateEnd: p[3],
    timeStart: p[4],
    timeEnd: p[5],
    retries: parseInt(p[6]) || 1,
    trunk: p[7] || "",
    context: p[8] || "",
    queue: p[9] || "",
    maxChannels: parseInt(p[10]) || 0,
    script: p[11] || "",
    statusCode: p[12] || "A",
    urlId: p[13] ? parseInt(p[13]) : null,
    forms,
    callStats: stats
  };
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
