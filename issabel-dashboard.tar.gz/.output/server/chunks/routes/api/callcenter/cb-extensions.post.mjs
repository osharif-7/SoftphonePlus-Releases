import { d as defineEventHandler, r as requireAuth, c as createError, a as readBody, F as mysqlQuery, D as mysqlExec } from '../../../nitro/nitro.mjs';
import { createHash } from 'node:crypto';
import 'node:fs/promises';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const cbExtensions_post = defineEventHandler(async (event) => {
  const session = requireAuth(event);
  if (session.groupId !== 1) throw createError({ statusCode: 403, statusMessage: "Admin only" });
  const body = await readBody(event);
  const { type, number, name, password, eccpPassword } = body;
  if (!number) throw createError({ statusCode: 400, statusMessage: "Extension is required" });
  if (!name) throw createError({ statusCode: 400, statusMessage: "Name is required" });
  if (!password) throw createError({ statusCode: 400, statusMessage: "Password is required" });
  const existing = await mysqlQuery(
    `SELECT id FROM agent WHERE type<>'Agent' AND CONCAT(type,'/',number)='${type || "SIP"}/${number}'`,
    "call_center"
  );
  if (existing.length) {
    throw createError({ statusCode: 400, statusMessage: "This extension is already registered as a callback agent" });
  }
  const esc = (s) => (s || "").replace(/'/g, "\\'");
  const finalEccp = eccpPassword || createHash("sha1").update(`${number}-${Date.now()}-${Math.random()}`).digest("hex").substring(0, 16);
  const result = await mysqlExec(
    `INSERT INTO agent (type, number, name, password, estatus, eccp_password)
     VALUES ('${type === "IAX2" ? "IAX2" : "SIP"}','${esc(number)}','${esc(name)}','${esc(password)}','A','${esc(finalEccp)}')`,
    "call_center"
  );
  if (!result.ok) throw createError({ statusCode: 500, statusMessage: result.error });
  return { ok: true };
});

export { cbExtensions_post as default };
//# sourceMappingURL=cb-extensions.post.mjs.map
