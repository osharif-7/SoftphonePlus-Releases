import { d as defineEventHandler, r as requireAuth, F as mysqlQuery } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const campaignsOut_get = defineEventHandler(async (event) => {
  requireAuth(event);
  const rows = await mysqlQuery(
    `SELECT c.id, c.name, c.datetime_init, c.datetime_end, c.daytime_init, c.daytime_end,
            c.retries, c.trunk, c.context, c.queue, c.max_canales, c.script, c.estatus,
            c.id_url,
            (SELECT COUNT(*) FROM calls WHERE id_campaign=c.id) AS total_calls,
            (SELECT COUNT(*) FROM calls WHERE id_campaign=c.id AND status='Success') AS success_calls
     FROM campaign c ORDER BY c.id DESC`,
    "call_center"
  );
  return rows.map((r) => {
    const p = r.split("	");
    return {
      id: parseInt(p[0]),
      name: p[1] || "",
      dateStart: p[2] || "",
      dateEnd: p[3] || "",
      timeStart: p[4] || "",
      timeEnd: p[5] || "",
      retries: parseInt(p[6]) || 1,
      trunk: p[7] || "",
      context: p[8] || "",
      queue: p[9] || "",
      maxChannels: parseInt(p[10]) || 0,
      script: p[11] || "",
      status: p[12] === "A" ? "Active" : p[12] === "T" ? "Terminated" : "Inactive",
      statusCode: p[12] || "A",
      urlId: p[13] ? parseInt(p[13]) : null,
      totalCalls: parseInt(p[14]) || 0,
      successCalls: parseInt(p[15]) || 0
    };
  });
});

export { campaignsOut_get as default };
//# sourceMappingURL=campaigns-out.get.mjs.map
