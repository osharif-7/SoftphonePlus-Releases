import { d as defineEventHandler, r as requireAuth, c as createError, a as readBody, D as mysqlExec, F as mysqlQuery } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const campaignsOut_post = defineEventHandler(async (event) => {
  const session = requireAuth(event);
  if (session.groupId !== 1) throw createError({ statusCode: 403, statusMessage: "Admin only" });
  const body = await readBody(event);
  const { name, dateStart, dateEnd, timeStart, timeEnd, retries, trunk, context, queue, maxChannels, script, status } = body;
  if (!name) throw createError({ statusCode: 400, statusMessage: "Campaign name is required" });
  if (!queue) throw createError({ statusCode: 400, statusMessage: "Queue is required" });
  const esc = (s) => (s || "").replace(/'/g, "\\'");
  const result = await mysqlExec(
    `INSERT INTO campaign (name, datetime_init, datetime_end, daytime_init, daytime_end, retries, trunk, context, queue, max_canales, script, estatus)
     VALUES ('${esc(name)}','${dateStart || "2025-01-01"}','${dateEnd || "2030-12-31"}','${timeStart || "08:00:00"}','${timeEnd || "22:00:00"}',${parseInt(retries) || 1},'${esc(trunk || "")}','${esc(context || "from-internal")}','${esc(queue)}',${parseInt(maxChannels) || 0},'${esc(script || "")}','${status === "I" ? "I" : "A"}')`,
    "call_center"
  );
  if (!result.ok) throw createError({ statusCode: 500, statusMessage: result.error });
  const idRows = await mysqlQuery("SELECT LAST_INSERT_ID()", "call_center");
  return { ok: true, id: parseInt(idRows[0]) || 0 };
});

export { campaignsOut_post as default };
//# sourceMappingURL=campaigns-out.post.mjs.map
