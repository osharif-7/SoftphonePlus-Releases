import { d as defineEventHandler, r as requireAuth, c as createError, g as getRouterParam, F as mysqlQuery, C as runAsterisk } from '../../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const disconnect_post = defineEventHandler(async (event) => {
  const session = requireAuth(event);
  if (session.groupId !== 1) throw createError({ statusCode: 403, statusMessage: "Admin only" });
  const id = getRouterParam(event, "id");
  const rows = await mysqlQuery(
    `SELECT type, number FROM agent WHERE id=${id} AND type<>'Agent'`,
    "call_center"
  );
  if (!rows.length) throw createError({ statusCode: 404, statusMessage: "Agent not found" });
  const [type, number] = rows[0].split("	");
  const channel = `Local/${number}@from-queue/n`;
  const queueOut = await runAsterisk("queue show");
  if (queueOut) {
    const qBlocks = queueOut.split(/\n(?=\S+\s+has\s+\d+\s+calls?)/);
    for (const block of qBlocks) {
      const hm = block.match(/^(\S+)\s+has/);
      if (!hm) continue;
      const qName = hm[1];
      if (block.includes(`Local/${number}@`) || block.includes(`${type}/${number}`)) {
        await runAsterisk(`queue remove member ${channel} from ${qName}`);
        await runAsterisk(`queue remove member ${type}/${number} from ${qName}`);
      }
    }
  }
  return { ok: true };
});

export { disconnect_post as default };
//# sourceMappingURL=disconnect.post.mjs.map
