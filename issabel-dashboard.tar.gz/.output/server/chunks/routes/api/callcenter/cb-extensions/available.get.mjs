import { d as defineEventHandler, r as requireAuth, F as mysqlQuery } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const available_get = defineEventHandler(async (event) => {
  requireAuth(event);
  const sipRows = await mysqlQuery(
    "SELECT data FROM sip WHERE keyword='dial' ORDER BY data"
  );
  const iaxRows = await mysqlQuery(
    "SELECT data FROM iax WHERE keyword='dial' ORDER BY data"
  );
  const allExtensions = [];
  for (const r of sipRows) {
    const data = r.trim();
    const m = data.match(/^(SIP|PJSIP)\/(\d+)/i);
    if (m) allExtensions.push({ channel: data, type: m[1].toUpperCase() === "PJSIP" ? "SIP" : m[1], number: m[2] });
  }
  for (const r of iaxRows) {
    const data = r.trim();
    const m = data.match(/^(IAX2)\/(\d+)/i);
    if (m) allExtensions.push({ channel: data, type: m[1], number: m[2] });
  }
  const usedRows = await mysqlQuery(
    "SELECT CONCAT(type,'/',number) AS channel FROM agent WHERE type<>'Agent' AND estatus='A'",
    "call_center"
  );
  const usedSet = new Set(usedRows.map((r) => r.trim()));
  const available = allExtensions.filter((e) => !usedSet.has(e.channel));
  return available;
});

export { available_get as default };
//# sourceMappingURL=available.get.mjs.map
