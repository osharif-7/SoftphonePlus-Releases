import { d as defineEventHandler, r as requireAuth, c as createError, g as getRouterParam, a as readBody, D as mysqlExec } from '../../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _id__put = defineEventHandler(async (event) => {
  const session = requireAuth(event);
  if (session.groupId !== 1) throw createError({ statusCode: 403, statusMessage: "Admin only" });
  const id = getRouterParam(event, "id");
  const body = await readBody(event);
  const { name, password, eccpPassword } = body;
  if (!name) throw createError({ statusCode: 400, statusMessage: "Name is required" });
  const esc = (s) => (s || "").replace(/'/g, "\\'");
  let sql = `UPDATE agent SET name='${esc(name)}'`;
  if (password) sql += `, password='${esc(password)}'`;
  if (eccpPassword) sql += `, eccp_password='${esc(eccpPassword)}'`;
  sql += ` WHERE id=${id} AND type<>'Agent'`;
  const result = await mysqlExec(sql, "call_center");
  if (!result.ok) throw createError({ statusCode: 500, statusMessage: result.error });
  return { ok: true };
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
