import { d as defineEventHandler, J as getQuery, F as mysqlQuery } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const channelUsage_get = defineEventHandler(async (event) => {
  const query = getQuery(event);
  const dateFrom = String(query.dateFrom || "");
  const dateTo = String(query.dateTo || "");
  const conditions = [];
  if (dateFrom) conditions.push(`calldate >= '${dateFrom} 00:00:00'`);
  if (dateTo) conditions.push(`calldate <= '${dateTo} 23:59:59'`);
  const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "WHERE 1=1";
  const hourlyRows = await mysqlQuery(
    `SELECT HOUR(calldate) as h, COUNT(*), SUM(CASE WHEN disposition='ANSWERED' THEN 1 ELSE 0 END)
     FROM cdr ${where} GROUP BY HOUR(calldate) ORDER BY h`,
    "asteriskcdrdb"
  );
  const hourly = hourlyRows.map((r) => {
    const [hour, total, answered] = r.split("	");
    return { hour: parseInt(hour), total: parseInt(total), answered: parseInt(answered || "0") };
  });
  const dailyRows = await mysqlQuery(
    `SELECT DATE(calldate) as d, COUNT(*), SUM(CASE WHEN disposition='ANSWERED' THEN 1 ELSE 0 END), SUM(billsec)
     FROM cdr ${where} GROUP BY DATE(calldate) ORDER BY d DESC LIMIT 30`,
    "asteriskcdrdb"
  );
  const daily = dailyRows.map((r) => {
    const [date, total, answered, billsec] = r.split("	");
    return { date, total: parseInt(total), answered: parseInt(answered || "0"), billsec: parseInt(billsec || "0") };
  }).reverse();
  const topSrcRows = await mysqlQuery(
    `SELECT src, COUNT(*) as cnt, SUM(billsec) FROM cdr ${where} AND src != '' GROUP BY src ORDER BY cnt DESC LIMIT 15`,
    "asteriskcdrdb"
  );
  const topSources = topSrcRows.map((r) => {
    const [src, count, billsec] = r.split("	");
    return { src, count: parseInt(count), billsec: parseInt(billsec || "0") };
  });
  const topDstRows = await mysqlQuery(
    `SELECT dst, COUNT(*) as cnt, SUM(billsec) FROM cdr ${where} AND dst != '' GROUP BY dst ORDER BY cnt DESC LIMIT 15`,
    "asteriskcdrdb"
  );
  const topDestinations = topDstRows.map((r) => {
    const [dst, count, billsec] = r.split("	");
    return { dst, count: parseInt(count), billsec: parseInt(billsec || "0") };
  });
  const dispRows = await mysqlQuery(
    `SELECT disposition, COUNT(*) as cnt FROM cdr ${where} GROUP BY disposition ORDER BY cnt DESC`,
    "asteriskcdrdb"
  );
  const dispositions = dispRows.map((r) => {
    const [disposition, count] = r.split("	");
    return { disposition, count: parseInt(count) };
  });
  return { hourly, daily, topSources, topDestinations, dispositions };
});

export { channelUsage_get as default };
//# sourceMappingURL=channel-usage.get.mjs.map
