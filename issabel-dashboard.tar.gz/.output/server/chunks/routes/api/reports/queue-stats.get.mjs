import { d as defineEventHandler, C as runAsterisk, F as mysqlQuery, O as getBestQueueAbandoned } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const queueStats_get = defineEventHandler(async () => {
  var _a;
  const queueOut = await runAsterisk("queue show");
  const queueCfgRows = await mysqlQuery("SELECT extension, IFNULL(descr,'') FROM queues_config ORDER BY extension");
  const queueMap = /* @__PURE__ */ new Map();
  for (const r of queueCfgRows) {
    const [ext, desc] = r.split("	");
    queueMap.set(ext, desc || ext);
  }
  const queues = [];
  const asteriskAbandonedMap = /* @__PURE__ */ new Map();
  if (queueOut) {
    const qBlocks = queueOut.split(/\n(?=\S+\s+has\s+\d+\s+calls?)/);
    for (const block of qBlocks) {
      const m = block.match(/^(\S+)\s+has\s+(\d+)\s+calls?\s+\(max\s+(\S+)\)\s+in\s+'(\S+)'\s+strategy\s+\((\d+)s\s+holdtime,\s+(\d+)s\s+talktime\),\s+W:(\d+),\s+C:(\d+),\s+A:(\d+),\s+SL:([^\s]+)/);
      if (!m) continue;
      const memberCount = (block.match(/^\s+(SIP|Local|PJSIP|IAX2)\/\S+.*/gm) || []).length;
      const callerCount = (block.match(/^\s+\d+\.\s+.*/gm) || []).length;
      const qName = m[1];
      asteriskAbandonedMap.set(qName, parseInt(m[9]));
      queues.push({
        name: qName,
        description: queueMap.get(qName) || qName,
        calls: parseInt(m[2]),
        maxCalls: m[3],
        strategy: m[4],
        holdtime: parseInt(m[5]),
        talktime: parseInt(m[6]),
        weight: parseInt(m[7]),
        completed: parseInt(m[8]),
        asteriskAbandoned: parseInt(m[9]),
        abandoned: 0,
        sl: m[10],
        memberCount,
        callerCount,
        answerRate: 0
      });
    }
  }
  const bestAbandoned = await getBestQueueAbandoned(asteriskAbandonedMap);
  for (const q of queues) {
    q.abandoned = (_a = bestAbandoned.get(q.name)) != null ? _a : q.asteriskAbandoned;
    q.answerRate = q.completed + q.abandoned > 0 ? Math.round(q.completed / (q.completed + q.abandoned) * 100) : 0;
  }
  return {
    queues,
    summary: {
      totalQueues: queues.length,
      totalCallsWaiting: queues.reduce((s, q) => s + q.calls, 0),
      totalCompleted: queues.reduce((s, q) => s + q.completed, 0),
      totalAbandoned: queues.reduce((s, q) => s + q.abandoned, 0),
      avgHoldtime: queues.length ? Math.round(queues.reduce((s, q) => s + q.holdtime, 0) / queues.length) : 0,
      avgTalktime: queues.length ? Math.round(queues.reduce((s, q) => s + q.talktime, 0) / queues.length) : 0
    }
  };
});

export { queueStats_get as default };
//# sourceMappingURL=queue-stats.get.mjs.map
