import { d as defineEventHandler, J as getQuery, F as mysqlQuery, Z as getAbandonedStatsForRange } from '../../../nitro/nitro.mjs';
import 'node:fs/promises';
import 'node:crypto';
import 'node:fs';
import 'node:net';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:path';
import 'child_process';
import 'fs';
import 'path';
import 'url';
import 'module';
import 'node:child_process';
import 'node:url';
import '@iconify/utils';
import 'consola';

const cdr_get = defineEventHandler(async (event) => {
  const query = getQuery(event);
  const page = Math.max(1, parseInt(String(query.page || "1")));
  const limit = Math.min(200, Math.max(10, parseInt(String(query.limit || "50"))));
  const offset = (page - 1) * limit;
  const dateFrom = String(query.dateFrom || "");
  const dateTo = String(query.dateTo || "");
  const src = String(query.src || "");
  const dst = String(query.dst || "");
  const disposition = String(query.disposition || "");
  const search = String(query.search || "");
  const conditions = [];
  if (dateFrom) conditions.push(`calldate >= '${dateFrom} 00:00:00'`);
  if (dateTo) conditions.push(`calldate <= '${dateTo} 23:59:59'`);
  if (src) conditions.push(`src LIKE '%${src}%'`);
  if (dst) conditions.push(`dst LIKE '%${dst}%'`);
  if (disposition && disposition !== "ALL") conditions.push(`disposition = '${disposition}'`);
  if (search) conditions.push(`(src LIKE '%${search}%' OR dst LIKE '%${search}%' OR clid LIKE '%${search}%' OR channel LIKE '%${search}%')`);
  const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
  const countRows = await mysqlQuery(`SELECT COUNT(*) FROM cdr ${where}`, "asteriskcdrdb");
  const total = parseInt(countRows[0] || "0");
  const rows = await mysqlQuery(
    `SELECT calldate, clid, src, dst, dcontext, channel, dstchannel, lastapp, duration, billsec, disposition, accountcode, uniqueid, recordingfile, cnum, cnam, did
     FROM cdr ${where} ORDER BY calldate DESC LIMIT ${limit} OFFSET ${offset}`,
    "asteriskcdrdb"
  );
  const records = rows.map((r) => {
    const f = r.split("	");
    return {
      calldate: f[0],
      clid: f[1],
      src: f[2],
      dst: f[3],
      dcontext: f[4],
      channel: f[5],
      dstchannel: f[6],
      lastapp: f[7],
      duration: parseInt(f[8] || "0"),
      billsec: parseInt(f[9] || "0"),
      disposition: f[10],
      accountcode: f[11],
      uniqueid: f[12],
      recordingfile: f[13],
      cnum: f[14],
      cnam: f[15],
      did: f[16]
    };
  });
  const statsRows = await mysqlQuery(
    `SELECT COUNT(*) as total,
            SUM(CASE WHEN disposition='ANSWERED' THEN 1 ELSE 0 END),
            SUM(CASE WHEN disposition='NO ANSWER' THEN 1 ELSE 0 END),
            SUM(CASE WHEN disposition='BUSY' THEN 1 ELSE 0 END),
            SUM(CASE WHEN disposition='FAILED' THEN 1 ELSE 0 END),
            SUM(duration), SUM(billsec),
            AVG(CASE WHEN billsec>0 THEN billsec ELSE NULL END)
     FROM cdr ${where}`,
    "asteriskcdrdb"
  );
  let stats = { total: 0, answered: 0, noAnswer: 0, abandoned: 0, busy: 0, failed: 0, totalDuration: 0, totalBillsec: 0, avgDuration: 0 };
  if (statsRows.length) {
    const s = statsRows[0].split("	");
    stats = {
      total: parseInt(s[0]) || 0,
      answered: parseInt(s[1]) || 0,
      noAnswer: parseInt(s[2]) || 0,
      abandoned: 0,
      busy: parseInt(s[3]) || 0,
      failed: parseInt(s[4]) || 0,
      totalDuration: parseInt(s[5]) || 0,
      totalBillsec: parseInt(s[6]) || 0,
      avgDuration: Math.round(parseFloat(s[7]) || 0)
    };
  }
  const rangeStart = dateFrom ? `${dateFrom} 00:00:00` : (/* @__PURE__ */ new Date()).toISOString().split("T")[0] + " 00:00:00";
  const rangeEnd = dateTo ? `${dateTo} 23:59:59` : (/* @__PURE__ */ new Date()).toISOString().split("T")[0] + " 23:59:59";
  const abandonedData = await getAbandonedStatsForRange(rangeStart, rangeEnd);
  stats.abandoned = abandonedData.abandoned;
  return { records, total, page, limit, pages: Math.ceil(total / limit), stats };
});

export { cdr_get as default };
//# sourceMappingURL=cdr.get.mjs.map
