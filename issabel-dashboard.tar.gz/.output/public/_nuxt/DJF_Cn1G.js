import"./DcugBjJO.js";const s=globalThis.setInterval;export{s};
