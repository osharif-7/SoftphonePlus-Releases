import{aa as r}from"./DcugBjJO.js";function i(a,t="reka"){let e;return e=r?.(),t?`${t}-${e}`:e}export{i as u};
