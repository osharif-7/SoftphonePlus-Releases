import{y as e,aL as r,ah as t}from"./CmJfFmyd.js";function u(o){return e(()=>r(o)?!!t(o)?.closest("form"):!0)}export{u};
