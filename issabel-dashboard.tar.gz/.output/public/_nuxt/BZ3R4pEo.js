import{a9 as r}from"./CmJfFmyd.js";function s(d,t="reka"){let e;return e=r?.(),t?`${t}-${e}`:e}export{s as u};
