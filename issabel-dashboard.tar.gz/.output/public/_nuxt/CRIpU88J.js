import{z as e,aM as r,ai as t}from"./DcugBjJO.js";function u(o){return e(()=>r(o)?!!t(o)?.closest("form"):!0)}export{u};
